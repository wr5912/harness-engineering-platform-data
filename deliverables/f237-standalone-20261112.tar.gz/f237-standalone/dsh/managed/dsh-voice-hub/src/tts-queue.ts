/**
 * 逐会话 TTS 队列：串行合成 + SSE 广播。
 *
 * 合成引擎抽象为 TtsEngine 接口——EdgeTtsEngine（微软云端 Edge TTS）与本地
 * VITS/Kokoro（tts-local.ts）都实现同一接口，队列/分句/打断/退避逻辑完全复用。
 *
 * 流式引擎逐块下发 PCM，其他引擎保留整句 MP3/WAV。取消代次贯穿
 * 队列与客户端；流中失败不整句重试，避免重复发声。
 */
import type { TtsChunkFrame } from './voice-remote.ts'
export type { TtsChunkFrame } from './voice-remote.ts'

export interface TtsPcmChunk { audio: Buffer; encoding: 'pcm-s16le'; sampleRate: number }
export interface TtsSynthesisOptions { voice?: string; rate?: number; signal?: AbortSignal }

import { MsEdgeTTS, OUTPUT_FORMAT, type ProsodyOptions } from './msedge-tts-compat.ts'

/** 合成引擎统一接口（云端/本地实现互替）。 */
export interface TtsEngine {
  /** 产出音频的 MIME（audio/mpeg = Edge；audio/wav = 本地 VITS/Kokoro）。 */
  readonly mime: string
  /** 热更新音色/语速（设置变更即时生效）。 */
  updateVoice(voice: string, rate?: number): void
  /** 合成一段文本为音频字节；失败抛错（上层退避重试）。 */
  synthesize(text: string, options?: TtsSynthesisOptions): Promise<Buffer>
  synthesizeStream?(text: string, options?: TtsSynthesisOptions): AsyncIterable<TtsPcmChunk>
  /** 打断：立刻中止在途合成并释放计算资源（本地引擎杀子进程；下一句自动重建）。 */
  interrupt?(): void
  /** 释放引擎资源（插件卸载/热重载）。 */
  close(): Promise<void>
  /** 引擎/模型现状（设置面板状态区轮询；可选）。 */
  status?(): TtsEngineStatus
  /** 预热/下载本地模型并初始化（设置面板「下载」按钮；Edge 无操作，缺省不实现）。 */
  prepare?(): Promise<void>
}

/** 单个模型文件的存在状态（用于设置面板现状展示）。 */
export interface TtsFileStatus {
  name: string
  exists: boolean
  size: number
}

/** 本地引擎某模型的组状态（仓库内文件 + 就绪/加载/失败）。 */
export interface TtsModelGroup {
  repo: string
  /** 组内全部必需文件已就绪（校验通过）。 */
  ready: boolean
  /** 正在初始化/加载（下载/子进程 init）。 */
  loading: boolean
  /** 最近一次加载/下载错误（可读字符串）。 */
  error?: string
  files: TtsFileStatus[]
}

/** 引擎/模型现状（设置面板轮询）。 */
export interface TtsEngineStatus {
  /** 当前生效引擎。 */
  engine: 'edge' | 'vits' | 'kokoro' | 'remote'
  /** 当前引擎是否就绪（本地：模型校验 + 子进程 init；edge：恒 true）。 */
  ready: boolean
  /** 当前引擎正在初始化/加载。 */
  loading: boolean
  /** 当前引擎最近一次错误。 */
  error?: string
  /** 当前模型下载进度（本地引擎下载时；edge 无）。 */
  progress?: { file: string; percent: number }
  /** 当前引擎的模型组（edge 无 local）。 */
  local?: TtsModelGroup
}

export type FrameListener = (frame: TtsChunkFrame) => void

const MP3_MAGIC = 0xff

/** setMetadata 的统一选项：句子/词边界回调都不需要（帧内无字幕元数据）。 */
const TTS_METADATA = { wordBoundaryEnabled: false, sentenceBoundaryEnabled: false } as const

function prosodyFromRate(rate?: number): ProsodyOptions | undefined {
  if (rate !== undefined && rate > 0 && rate !== 1) return { rate }
  return undefined
}

/** 合法 MP3 帧以同步字开头；空音频（如英文音色读不了中文）视同无效。 */
function isValidMp3(buf: Buffer): boolean {
  return buf.length > 0 && buf[0] === MP3_MAGIC
}

/** Edge TTS 引擎（微软语音服务，云端；被朗读文本发送到微软）。 */
export class EdgeTtsEngine implements TtsEngine {
  private voice: string
  private rate?: number

  constructor(voice = 'zh-CN-XiaoxiaoNeural', rate?: number) {
    this.voice = voice
    this.rate = rate
  }

  readonly mime = 'audio/mpeg'

  updateVoice(voice: string, rate?: number): void {
    this.voice = voice
    if (rate !== undefined && Number.isFinite(rate)) this.rate = rate
  }

  async synthesize(text: string, options: { voice?: string; rate?: number } = {}): Promise<Buffer> {
    // Edge 直传云端，SSML 未启用，strip 另开批。
    const tts = new MsEdgeTTS()
    try {
      await tts.setMetadata(
        options.voice ?? this.voice,
        OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3,
        TTS_METADATA,
      )
      const { audioStream } = tts.toStream(text, prosodyFromRate(options.rate ?? this.rate))
      const chunks: Buffer[] = []
      for await (const chunk of audioStream) chunks.push(chunk as Buffer)
      const buf = Buffer.concat(chunks)
      if (!isValidMp3(buf)) throw new Error('empty or invalid audio')
      return buf
    } finally {
      try {
        await tts.close()
      } catch {
        // ignore
      }
    }
  }

  async close(): Promise<void> {
    // 无持久连接（每句独立连接），无需清理。
  }
}

/** Edge 音色列表（重命名缓存；/voice-mode/voices 用；失败抛错由调用方处理）。 */
let edgeVoicesCache: Array<{ ShortName: string; Locale: string; Gender: string; FriendlyName: string }> | null = null
export async function listEdgeVoices(force = false): Promise<Array<{ ShortName: string; Locale: string; Gender: string; FriendlyName: string }>> {
  if (edgeVoicesCache && !force) return edgeVoicesCache
  const tts = new MsEdgeTTS()
  try {
    const voices = await tts.getVoices()
    edgeVoicesCache = voices.map((v) => ({
      ShortName: v.ShortName,
      Locale: v.Locale,
      Gender: v.Gender,
      FriendlyName: v.FriendlyName,
    }))
    return edgeVoicesCache
  } finally {
    try {
      await tts.close()
    } catch {
      // ignore
    }
  }
}

interface QueuedSentence {
  sourceMessageId?: string
  queuedAt: number
  text: string
  epoch: number
  onSettled?: () => void
}

interface SessionQueue {
  abort?: AbortController
  pending: QueuedSentence[]
  busy: boolean
  seq: number
  /** cancel() 时提升；携带旧 epoch 的句子被丢弃。 */
  epoch: number
  /** TTS 不可达已通知过（去重，直到下一帧成功才复位）。 */
  errorNotified: boolean
}

export class TtsQueue {
  private nextEpoch = 0
  private readonly queues = new Map<string, SessionQueue>()
  private readonly listeners = new Set<FrameListener>()
  private engine: TtsEngine
  /** TTS 全体不可达通知（每会话去重，成功后复位）。 */
  private readonly onError?: (sessionId: string) => void
  /** 单句合成重试耗尽被跳过通知（每句一次；此前是静默丢句——真机「回复偶尔不朗读」根因之一）。 */
  private readonly onSkip?: (sessionId: string, text: string) => void

  constructor(options: {
    engine: TtsEngine
    onError?: (sessionId: string) => void
    onSkip?: (sessionId: string, text: string) => void
  }) {
    this.engine = options.engine
    this.onError = options.onError
    this.onSkip = options.onSkip
  }

  /** 当前引擎音频 MIME（/preview 的 Content-Type 也用它）。 */
  get mime(): string {
    return this.engine.mime
  }

  /**
   * 运行时切换引擎（设置面板「朗读引擎」即时生效）：
   * 关闭旧引擎、清空所有会话队列；新句子用新引擎合成。
   */
  setEngine(engine: TtsEngine): void {
    const old = this.engine
    this.engine = engine
    for (const q of this.queues.values()) {
      q.epoch = ++this.nextEpoch
      q.pending.length = 0
      q.abort?.abort()
    }
    this.queues.clear()
    void old.close().catch(() => {})
  }

  /** 动态更换音色/语速（设置即时生效；正在合成的句子不受影响）。 */
  updateVoice(voice: string, rate?: number): void {
    this.engine.updateVoice(voice, rate)
  }

  /** 当前引擎/模型现状（设置面板状态区轮询）。 */
  status(): TtsEngineStatus {
    const s = this.engine.status?.()
    if (s) return s
    // Edge 云端引擎：无本地模型，视为恒就绪。
    return { engine: 'edge', ready: true, loading: false }
  }

  /** 触发当前引擎预热/下载模型并初始化（设置面板「下载」按钮；Edge 为无操作）。 */
  async prepare(): Promise<void> {
    await this.engine.prepare?.()
  }

  /**
   * 一次性合成（设置卡「试听」用）：委托当前引擎；不干扰朗读队列的在途合成。
   * 失败（含非法音色）抛错。
   */
  async synthesize(text: string, options: { voice?: string; rate?: number } = {}): Promise<Buffer> {
    return this.engine.synthesize(text, options)
  }

  subscribe(listener: FrameListener): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  /** 为某会话入队一句；若泵空闲则启动。 */
  enqueue(sessionId: string, text: string, onSettled?: () => void, sourceMessageId?: string): void {
    let q = this.queues.get(sessionId)
    if (!q) {
      q = { pending: [], busy: false, seq: 0, epoch: ++this.nextEpoch, errorNotified: false }
      this.queues.set(sessionId, q)
    }
    // 队列上限（防病理性积压失控）。20 → 500：长回复流式文本比 Edge 合成快时，
    // 积压超 20 就会静默丢最旧句子——「长话跳句」的另一来源。500 覆盖任意正常回复
    // 长度（每句仅几十字，内存无忧），仍留病理性护栏；超限告警而非静默。
    if (q.pending.length >= 500) {
      console.warn('[dsh-voice-hub] TTS（语音合成）队列已满，最早一句未播报')
      q.pending.shift()
    }
    q.pending.push({ text, epoch: q.epoch, onSettled, sourceMessageId, queuedAt: performance.now() })
    void this.pump(sessionId, q)
  }

  /**
   * 弃掉某会话的所有积压并作废正在合成的句子（打断）。之后入队的句子
   * 获得新 epoch 正常播放。同时立刻中止在途合成（本地引擎杀子进程释放 CPU）。
   */
  cancel(sessionId: string): number {
    const epoch = ++this.nextEpoch
    const q = this.queues.get(sessionId)
    if (q) {
      q.epoch = epoch
      q.pending.length = 0
      q.abort?.abort()
      if (q.abort && !this.engine.synthesizeStream) this.engine.interrupt?.()
    }
    return epoch
  }

  /** 会话退出/被抢占时彻底清理其队列（防止 Map 长期累积）。 */
  prune(sessionId: string): void {
    const q = this.queues.get(sessionId)
    if (q) {
      // 双重奏根治：孤儿泵不死——prune 只 delete queue 不提升 epoch 时，旧 q 的 pump
      // 继续合成并广播旧回合句子（item.epoch === q.epoch 对旧 q 永真），与新泵并行 →
      // 客户端同时收到旧/新两套句子（双重奏）。提升 epoch 让孤儿泵在下一句检查时
      // break，停止广播；重入的新回合用新 queue（seq/epoch 从头）。
      q.epoch = ++this.nextEpoch
      q.pending.length = 0
    }
    q?.abort?.abort()
    this.queues.delete(sessionId)
  }

  private async pump(sessionId: string, q: SessionQueue): Promise<void> {
    if (q.busy) return
    q.busy = true
    try {
      while (q.pending.length > 0) {
        const item = q.pending.shift()!
        const startedAt = performance.now()
        const sentenceId = q.seq++
        let chunkId = 0
        let sent = false
        const base = { sessionId, sentenceId, epoch: item.epoch, text: item.text,
          ...(item.sourceMessageId ? { sourceMessageId: item.sourceMessageId } : {}) }
        const send = (frame: TtsChunkFrame): void => {
          if (item.epoch !== q.epoch) return
          if (frame.chunkId === 0 && !frame.final) {
            frame.queueWaitMs = startedAt - item.queuedAt
            frame.firstAudioMs = performance.now() - startedAt
          }
          for (const fn of this.listeners) { try { fn(frame) } catch { /* 消费者不阻塞合成。 */ } }
        }
        const abort = new AbortController()
        q.abort = abort
        let timer: ReturnType<typeof setTimeout> | undefined
        let onAbort: () => void = () => {}
        try {
          const attempts = item.sourceMessageId ? 1 : 3
          for (let attempt = 0; attempt < attempts; attempt++) {
            abort.signal.throwIfAborted()
            try {
              if (this.engine.synthesizeStream) {
                for await (const chunk of this.engine.synthesizeStream(item.text, { signal: abort.signal })) {
                  abort.signal.throwIfAborted()
                  if (item.epoch !== q.epoch) break
                  send({ ...base, ...chunk, audio: chunk.audio.toString('base64'), chunkId: chunkId++, final: false })
                  sent = true
                }
              } else {
                const synthesized = this.engine.synthesize(item.text, { signal: abort.signal })
                const cancelled = new Promise<never>((_, reject) => {
                  onAbort = () => reject(abort.signal.reason)
                  abort.signal.addEventListener('abort', onAbort, { once: true })
                })
                if (item.sourceMessageId) timer = setTimeout(() => abort.abort(new Error('语音合成超时')), 10000)
                const buf = await Promise.race([synthesized, cancelled])
                send({ ...base, chunkId: chunkId++, final: false, audio: buf.toString('base64'), mime: this.engine.mime })
                sent = true
              }
              if (!sent) throw new Error('语音合成没有返回音频')
              send({ ...base, chunkId, final: true, audio: '', mime: this.engine.mime })
              q.errorNotified = false
              break
            } catch (error) {
              if (abort.signal.aborted || item.epoch !== q.epoch) throw error
              // 已经发送的流不能整句重试，否则用户会听到重复片段。
              if (sent || attempt === attempts - 1) throw error
              await new Promise(resolve => setTimeout(resolve, 400 * (attempt + 1)))
            } finally {
              clearTimeout(timer)
              abort.signal.removeEventListener('abort', onAbort)
            }
          }
        } catch {
          if (item.epoch === q.epoch) {
            if (sent) send({ ...base, chunkId, final: true, failed: true, audio: '' })
            this.onSkip?.(sessionId, item.text)
          }
        } finally {
          clearTimeout(timer)
          abort.signal.removeEventListener('abort', onAbort)
          q.abort = undefined
          try { item.onSettled?.() } catch { /* 通知失败不阻塞后续句子。 */ }
        }
      }
    } catch {
      if (!q.errorNotified) {
        q.errorNotified = true
        this.onError?.(sessionId)
      }
    } finally {
      q.busy = false
      if (this.queues.get(sessionId) === q && q.pending.length) void this.pump(sessionId, q)
    }
  }

  async close(): Promise<void> {
    for (const sid of this.queues.keys()) this.cancel(sid)
    await this.engine.close()
  }
}
