/**
 * dsh-voice-mode ASR engine（浏览器半）：持续聆听 + VAD 自动分段。
 *
 * 与参照 dsh-voice 的关键差异：
 *  - 不是 tap/hold，而是「进入语音模式后持续收音」：静音 1500ms 自动断句（P1-3，端点优先由 host Silero VAD 判定），
 *    段定稿后提交；按住 Ctrl（≥250ms 语音）强制立即发送兜底；
 *  - partial 轮询（100ms，P1-4 增量上行）走 host 流式识别增量，实时字幕只在状态条预览，
 *    定稿文本才作为结果（Q6/Q13：可编辑草稿 + 自动提交）；服务端 Silero VAD 帧级
 *    isSpeech 随 partial / 播放期 vadOnly 检测响应下行，驱动打断（阶段二，取代 RMS
 *    能量快路径；朗读期常规 partial 因自聊防护断流，检测通道补齐这条链路）；
 *  - v0.2：hold 模式（按住说话、松手发送，绕过 VAD）；
 *  - v0.3（P1-5）：延迟埋点链的客户端三枚时间戳——utterance-end（说完最后一个字）、
 *    endpoint-fired（端点判句到点）、submitted（定稿上传发起），经 onTelemetry 上抛，
 *    由 client.tsx 与 host 下行的 first-llm-token/first-sentence-text/first-tts-chunk/
 *    first-audio-played 拼接成「说完→首音」全链路（开发模式状态条展示）。
 */

import { resampleLinear } from './resample.ts'
import { matchWakeWord, stripWakePrefix } from './wakeword.ts'
import { fixtureRecorder } from './fixture-recorder.ts'

// AudioWorklet 源码字符串（build.mjs 经 esbuild define 注入）：运行时转 Blob URL 供 addModule。
declare const __AUDIO_WORKLET__: string
let workletBlobUrl: string | null = null

export type AsrState = 'idle' | 'listening' | 'wake' | 'speech' | 'transcribing' | 'loading-model'

/**
 * Backchannel 词表（批 5 / ADR-0008 Phase 1）。
 * 「朗读期用户说『嗯/对』等短应答 → 让位」语义：用户其实没真正要说，只是回应/确认；
 * 让位 = 跳过当前 TTS 句，1.5s 内用户真要说则走 hardBreak 取消回合。
 *
 * 与 wakeWord 的本质区别：
 *   - wakeWord：前缀匹配（候选以唤醒词开头）
 *   - backchannel：**整段**匹配（候选归一化后必须等于词表某一元素）
 *
 * 边界（plan §10 R4b）：≤4 归一化字符；不复用 normalizeWake（其会剥前置语气词，
 *   把「嗯」剥成空串，与本场景语义相反）；独立归一化只去空白/标点/小写。
 */
const BACKCHANNEL_WORDS: ReadonlySet<string> = new Set([
  '嗯', '哎', '呃', '哦', '噢', '对', '好', '行', '是',
  '嗯嗯', '好好',
  'so', 'um', 'uh', 'yeah', 'right', 'ok',
])

/** Backchannel 独立归一化：去空白/标点/小写（不剥前置语气词——词表本身就是语气词）。 */
function normalizeBackchannel(text: string): string {
  return String(text ?? '')
    .replace(/[\s\u3000]+/g, '')
    .toLowerCase()
    .replace(/[，。！？!?；;、,.]/g, '')
}

/**
 * 整段匹配 backchannel 词表。
 * @param partial host 返回的段内累计识别文本
 * @returns 是否命中词表且长度 ≤4 归一化字符
 */
export function matchBackchannel(partial: string): boolean {
  const p = normalizeBackchannel(partial)
  if (!p || p.length > 4) return false
  return BACKCHANNEL_WORDS.has(p)
}

/**
 * P3-2 回声消除参考源（由 client.tsx 组装注入）：采集每帧以 windowAt(墙钟, 长度)
 * 取回对应时刻的 TTS 播放参考，process 用 NLMS 减去回声。缺失（null）时原样透传。
 */
export interface EchoRefSource {
  process(mic: Float32Array, ref: Float32Array): Float32Array
  windowAt(tWallMs: number, n: number): Float32Array
  /** A2.5 双讲冻结：用户说话时暂停 NLMS 自适应（防滤波器带偏）。 */
  setFrozen(frozen: boolean): void
}

/** 延迟埋点链的客户端阶段（P1-5；host 侧阶段与全链顺序见 client.tsx TELEMETRY_VIEW）。 */
export type TelemetryStage = 'utterance-end' | 'endpoint-fired' | 'submitted'

export interface TelemetryEvent {
  stage: TelemetryStage
  /** 客户端时钟毫秒（同一浏览器内各阶段可比；SSE 下行阶段由接收时刻计）。 */
  at: number
}

export interface AsrConfig {
  /** 静音多少 ms 判句结束（Q5，默认 1500；端点优先由 host Silero VAD 判定）。 */
  silenceMs: number
  /** host 路由前缀。 */
  basePath: string
  /** 本地唤醒命中后移交的麦克风流；ASR 接管并负责释放。 */
  microphone?: MediaStream
  /** 交互模式：hold 按住说话（未按住不持续聆听）；toggle 持续聆听（默认）。 */
  mode?: 'hold' | 'toggle'
  /** 回声门控阈值（dB，默认 6）：残差高于回声地板此值才判用户人声。 */
  echoGateDb?: number
  /** P3-2：回声参考（TTS 播放经 NLMS 消除后，信号再用于打断/VAD/上行）。 */
  echo?: EchoRefSource
  /** AI 朗读中（TTS 在播）：根治「TTS→回声→ASR→自聊」。为 true 时只走打断快路径、不入段。 */
  isPlaying?: () => boolean
  /** 服务端 Silero VAD 帧级语音检测（partial 与播放期 vadOnly 检测响应下行；打断根治：客户端据此驱动打断，替代 RMS 能量快路径）。 */
  onIsSpeech?: (speech: boolean | undefined) => void
  /** 403 会话过期回调：host 端活跃会话已变更（如被抢占/让出），返回 true 表示已恢复。 */
  onSessionExpired?: () => Promise<boolean>
  /** A1：原生 AEC 生效状态回调（getUserMedia 后 track.getSettings().echoCancellation）。 */
  onAecState?: (on: boolean) => void
  /** 批 5 / ADR-0008 Phase 1：backchannel 命中回调（朗读期用户说「嗯/对」等短应答）。 */
  onBackchannel?: () => void
  /** 批 F：backchannelYield=false 时短路 matchBackchannel（CPU 浪费修复；默认 true，I10 豁免）。 */
  backchannelYield?: boolean
  /** 唤醒词（空 = 关）：进入后先在 wake 待机态，说出唤醒词才正式开口。 */
  wakeWord?: string
  /** 已有待发送草稿时，待唤醒态也定稿短句，由调用方只放行完整的发送命令。 */
  hasPendingDraft?: () => boolean
  /** 批 7N（ADR-0006）：打断方式。manual = 播放期间仅按住才能打断，闲时仍持续收音。
   *  缺省视为 'auto'——保持原行为不变（向后兼容，未传此字段的旧调用方不被影响）。
   *  批 7O（ADR-0006）：detect = 第一级自动探测（getUserMedia 后读 echoCancellation），
   *  false → 运行时落 manual、true → auto。 */
  bargeInMode?: 'auto' | 'manual' | 'detect'
}

export interface SegmentMeta {
  /** true = 由强制发送触发（按住 Ctrl / hold 松手；autoSend=false 时仍提交）。 */
  force?: boolean
  /** 这句话未包含唤醒词，只允许客户端用作完整发送命令。 */
  wakeStandby?: boolean
}

export interface AsrEngine {
  readonly state: AsrState
  start(): Promise<void>
  stop(): Promise<void>
  /** 按住 Ctrl 强制立即发送当前段（Q5 兜底）。 */
  forceSend(): void
  /** hold 模式：按下开始录制（绕过 VAD 门控，忽略静音切句）。 */
  beginHeld(): void
  /** hold 模式：松手定稿发送（cancel=true 放弃本段）。 */
  endHeld(cancel?: boolean): void
  /** hold 按压中（含 toggle 模式按住 Ctrl）：打断时不丢弃本段（明确说话意图）。 */
  readonly holding: boolean
  /** A2.5 回声门控：当前残差是否明显高于回声地板（默认 6dB）——判用户人声而非回声。 */
  aboveEchoFloor(marginDb?: number): boolean
  /** 回声诊断读数（真机标定数据）：{ 地板 RMS, 当前残差 RMS, 残差峰值 RMS }。 */
  echoLevels(): { floorRms: number; residualRms: number; peakRms: number }
  /** 丢弃当前已录段（打断后防幽灵消息），host 流重置。返回 Promise 供调用方等待。 */
  discardSegment(): Promise<void>
  /** 定稿文本（段结束/强制发送后）。 */
  readonly onSegment: (fn: (text: string, meta?: SegmentMeta) => void) => () => void
  /** 实时字幕（partial，仅预览）。 */
  readonly onPartial: (fn: (text: string) => void) => () => void
  readonly onState: (fn: (s: AsrState) => void) => () => void
  readonly onError: (fn: (msg: string) => void) => () => void
  /** 归一化电平 0..1（波形条）。 */
  readonly onLevel: (fn: (level: number) => void) => () => void
  /** 延迟埋点链客户端事件（P1-5：utterance-end / endpoint-fired / submitted）。 */
  readonly onTelemetry: (fn: (e: TelemetryEvent) => void) => () => void
}

const SAMPLE_RATE = 16000
/** 识别门（VAD 开段阈值，低门槛——安静语音也要分段）。 */
const SPEECH_RMS = 0.015
/** RMS 映射满格波形的电平。 */
const LEVEL_CEILING = 0.25
const MAX_SEGMENT_MS = 30000
/** 最小语音时长（P1-3）：不足视为短促噪声，静音到点后放弃本段不发送。 */
const MIN_SPEECH_MS = 250
const PRE_PAD_MS = 250
/** P1-4：partial / 检测通道轮询节拍 100ms（墙钟衡量，帧长无关；阶段二降低 isSpeech 帧级检测延迟）。 */
const PARTIAL_INTERVAL_MS = 100
/** partial 预览下限/上限（流式模型代价低，上限放宽）。 */
const PARTIAL_MIN_S = 0.4
const PARTIAL_MAX_S = 30
/** ScriptProcessor 缓冲必须为 2 的幂（已知坑）。 */
const BUFFER_SIZE = 1024

export function createAsrEngine(config: AsrConfig, sessionId: string): AsrEngine {
  /** 归一化后的唤醒词（空 = 关）。 */
  const wakeWord = (config.wakeWord ?? '').trim().toLowerCase().replace(/[\s\u3000]+/g, '')
  /** 唤醒词门仅在 toggle 模式生效（hold 模式按住即说，无需唤醒词门，避免状态条误显「说唤醒词」）。 */
  const wakeEnabled = wakeWord !== '' && config.mode !== 'hold'
  /** 批 7O（ADR-0006）：运行时打断方式。detect 模式下经第一级探测（echoCancellation）在
   *  startRecorder 内落为 'auto'/'manual'；auto/manual 显式取值保持原样。 */
  let runtimeBargeInMode: 'auto' | 'manual' | 'detect' = config.bargeInMode ?? 'auto'
  let state: AsrState = 'idle'
  const stateListeners = new Set<(s: AsrState) => void>()
  const errorListeners = new Set<(msg: string) => void>()
  const emitError = (msg: string): void => {
    for (const fn of errorListeners) {
      try { fn(msg) } catch { /* ignore */ }
    }
  }
  const transcriptListeners = new Set<(text: string, meta?: SegmentMeta) => void>()
  const partialListeners = new Set<(text: string) => void>()
  const levelListeners = new Set<(level: number) => void>()
  const telemetryListeners = new Set<(e: TelemetryEvent) => void>()
  /** 本段「说完」时刻是否已上报（每段至多一次；无静音过渡路径在 finalize 补报）。 */
  let utteranceEndAt: number | null = null
  const emitTelemetry = (stage: TelemetryStage): void => {
    const ev: TelemetryEvent = { stage, at: Date.now() }
    for (const fn of telemetryListeners) {
      try {
        fn(ev)
      } catch {
        // ignore
      }
    }
  }

  // --- 录音器 ---
  let audioCtx: AudioContext | null = null
  let stream: MediaStream | null = null
  let processor: ScriptProcessorNode | null = null
  let workletNode: AudioWorkletNode | null = null
  let active = false
  /** 麦克风取消请求（Fix8 修正：授权返回时若已被 stop 抢占则释放，防止无人能停的常开泄漏）。 */
  let stopRequested = false
  /** 启动序号（防授权窗口内快速 start→stop→start 双路开麦：旧启动因序号落后而放弃）。 */
  let startSeq = 0
  let inFlush = false
  /** AudioContext 实际采样率（可能 ≠ 16k，用于重采样守卫）。 */
  let ctxRate: number = SAMPLE_RATE

  // --- 分段状态 ---
  let speechActive = false
  let segment: Float32Array[] = []
  let segmentMs = 0
  /** 纯语音时长（P1-3 最小语音时长门；静音尾巴不计入）。 */
  let speechMs = 0
  let silenceMs = 0
  let prePad: Float32Array[] = []
  /** hold 模式：按住录制中（绕过 VAD 门控与静音切句，整段按压区间保留）。 */
  let holdActive = false
  /** P3-2 回声参考（可选；缺失时原信号透传）。 */
  const echo = config.echo

  // --- partial / 检测通道轮询（墙钟节拍：帧长随设备采样率 21-64ms 波动，
  // 帧驱动的 durationMs 累加会把名义 100ms 节拍量化到 107/128ms；墙钟版本与帧长无关，
  // 确认帧时长口径（约 0.3/0.2/0.1s）得以精确成立） ---
  let lastPollAt = 0
  let partialInFlight = false
  /** reset 门（issue #10 问题 3）：host 清场与 partial 上行的顺序约束（见 resetHostStream）。 */
  let resetGate: Promise<void> = Promise.resolve()
  /** 段纪元：finalize/stop 后迟到的 partial 丢弃。 */
  let segmentEpoch = 0
  /** wake 待机段静音累计（issue #10：待机段静音弃段用；有语音即清零）。 */
  let wakeSilenceMs = 0
  /** 本段已消费唤醒词（命中后置位；定稿时从文本头部剥掉词头，防唤醒词进消息）。 */
  let wakeConsumed = false
  /** Ctrl 强制发送标记（随本段定稿的 meta 传递）。 */
  let forcePending = false
  /** P1-4：本段已上传的样本数（增量水位；partial/定稿只传新增部分）。 */
  let uploadedSamples = 0
  // --- 打断根治：播放期检测通道（AI 朗读中 AEC 后帧持续上行 vadOnly，供 host
  // 检测 VAD 判打断；朗读期常规 partial 因自聊防护断流，无此通道 isSpeech 恒 false） ---
  let detectChunks: Float32Array[] = []
  let detectSent = 0
  let detectInFlight = false
  /** 检测通道代际：每次重置（弃段/退出/进入/新段开始）递增，作废在途 vadOnly 响应，
   *  防「重置后旧响应推进 detectSent 水位」的毒化竞态（对抗审查 Important#1）。 */
  let detectGeneration = 0

  const asrUrl = (final: boolean, offset?: number, epoch?: number, flag?: 'vadOnly' | 'reset'): string => {
    const url = new URL(`${config.basePath.slice(1).replace(/\/+$/, '')}/asr`, document.baseURI)
    url.searchParams.set('sessionId', sessionId)
    url.searchParams.set('final', final ? '1' : '0')
    if (offset !== undefined) url.searchParams.set('offset', String(offset))
    if (epoch !== undefined) url.searchParams.set('epoch', String(epoch))
    // 批 7N（ADR-0006）：manual 模式下上传带 &manual=1，host 服务端据此放行（防御性守卫）。
    // 播放期间 manual + !holdActive 会在 handleAudio 入口丢弃；闲时仍连续收音。
    // 带 manual=1 让 host 放行该模式的普通语音帧。
    // 批 7O：detect 经探测落 manual 时同样带 manual=1（runtimeBargeInMode 已解析）。
    if (runtimeBargeInMode === 'manual') url.searchParams.set('manual', '1')
    if (flag) url.searchParams.set(flag, '1')
    return url.href
  }

  const setState = (s: AsrState): void => {
    state = s
    for (const fn of stateListeners) {
      try {
        fn(s)
      } catch {
        // listener errors must not kill the recorder
      }
    }
  }

  const emit = (listeners: Set<(t: string, meta?: SegmentMeta) => void>, text: string, meta?: SegmentMeta): void => {
    const t = text.trim()
    if (!t) return
    for (const fn of listeners) {
      try {
        fn(t, meta)
      } catch {
        // ignore
      }
    }
  }

  /** 从分块缓冲的 from 样本起切片（增量上传；不做全量 concat）。 */
  const sliceChunks = (chunks: Float32Array[], from: number): Float32Array => {
    let total = 0
    for (const c of chunks) total += c.length
    const out = new Float32Array(Math.max(0, total - from))
    if (out.length === 0) return out
    let off = 0
    let acc = 0
    for (const c of chunks) {
      if (off >= out.length) break
      const sub = c.subarray(Math.max(0, from - acc))
      const n = Math.min(sub.length, out.length - off)
      out.set(sub.subarray(0, n), off)
      off += n
      acc += c.length
    }
    return out
  }

  /** P1-4：从段内 from 样本起切片（增量上传；不做全量 concat）。 */
  const sliceSince = (from: number): Float32Array => sliceChunks(segment, from)

  /**
   * partial 轮询：P1-4 只 POST 上次末帧后的新增 PCM（host 按 offset 只喂增量），
   * 预览字幕。202 = 模型下载中；重试。失败静默（预览非结果）。
   */
  const requestPartial = async (): Promise<void> => {
    if (partialInFlight || segment.length === 0) return
    // reset 门（issue #10 问题 3）：等在途 host 清场先落地再上行——hardBreak 会并发
    // 两个清场（/cancel 的 asr.reset + 本引擎 reset=1），任一晚于新 partial 到达都会
    // 把已喂样本抹掉而客户端水位已推进，后续增量对空流只发尾部（段丢头根因）。
    await resetGate
    // 等待期间段可能已被清（静音弃段/打断弃段）：重查守卫。
    if (partialInFlight || segment.length === 0) return
    const total = segment.reduce((n, c) => n + c.length, 0)
    const seconds = total / SAMPLE_RATE
    if (seconds < PARTIAL_MIN_S || seconds > PARTIAL_MAX_S) return
    // P1-4：只传增量；已上传水位 uploadedSamples 在成功后推进。
    const from = uploadedSamples
    if (total - from <= 0) return
    const samples = sliceSince(from)
    const epoch = segmentEpoch
    partialInFlight = true
    try {
      let res = await fetch(asrUrl(false, from, epoch), {
        method: 'POST',
        headers: { 'content-type': 'application/octet-stream' },
        body: samples.buffer as ArrayBuffer,
      })
      if (res.status === 202) {
        // 模型下载中：5s 后重试同一载荷（Q16 重试提示在状态条展示）
        setState('loading-model')
        const retry = await new Promise<Response>((resolve) => {
          setTimeout(async () => {
            try {
              const r2 = await fetch(asrUrl(false, from, epoch), {
                method: 'POST',
                headers: { 'content-type': 'application/octet-stream' },
                body: samples.buffer as ArrayBuffer,
              })
              resolve(r2)
            } catch {
              resolve(new Response(null, { status: 503 }))
            }
          }, 5000)
        })
        res = retry
      }
      // 403 会话过期：host 端活跃会话已变更（如被抢占/让出），尝试恢复后重试一次。
      if (res.status === 403 && config.onSessionExpired) {
        const recovered = await config.onSessionExpired()
        if (recovered && epoch === segmentEpoch) {
          // I2 修复：re-enter 已 asr.reset 清空 host 流（fed=0），旧增量水位作废——
          // 从 0 全量重发本段（段仍在本地内存），否则 host 只收到尾巴、定稿缺前半句。
          uploadedSamples = 0
          try {
            res = await fetch(asrUrl(false, 0, epoch), {
              method: 'POST',
              headers: { 'content-type': 'application/octet-stream' },
              body: sliceSince(0).buffer as ArrayBuffer,
            })
          } catch {
            // 重试失败：静默（下轮 partial 自动覆盖）
          }
        }
      }
      if (epoch !== segmentEpoch) return
      if (!res.ok) return
      const out = (await res.json()) as { text?: string; endpoint?: boolean; isSpeech?: boolean }
      if (epoch !== segmentEpoch) return
      // 唤醒词门：wake 待机态下 partial 只用于匹配，命中 → 转入聆听（**不丢段**）。
      if (state === 'wake' && wakeEnabled) {
        uploadedSamples = Math.max(uploadedSamples, from + samples.length)
        // 待机态也显示实时转写（issue #10 问题 2）：用户看见「它听到了什么」，唤醒
        // 成败可自查；命中瞬间本条 partial 同时充当「已听到唤醒词」的确认反馈。
        emit(partialListeners, out.text ?? '')
        if (matchWakeWord(out.text ?? '', wakeWord)) {
          // 真机实证（2026-09-18）：**不得清段/清 host 流**。用户常把命令与唤醒词连说
          // （「你好小李你给我说100个字的中文」），命中时命令前半句已在同一段里；
          // 整段丢弃会把它一起吃掉、只剩尾部几个字（「完全无法使用」根因）。
          // 改为保留音频继续识别，由定稿时的 stripWakePrefix 从文本头部剥掉唤醒词。
          wakeConsumed = true
          // 待机段本身就是真实用户语音：置位 speechActive，让正常路径的静音/端点判据接管。
          // 否则「唤醒词直到用户停口后才被识别」时尾随静音落进 prePad 分支 → 永不定稿
          // → 命令悬挂到下一句才发出（真机台架 LAG=3000ms 实证 0 条定稿）。
          speechActive = true
          // 待机期已积累的尾随静音计入 silenceMs：命令在命中前就说完时，端点不必再从 0
          // 等满一个 silenceMs（最多省一个静音窗才把命令发出去）。
          silenceMs = wakeSilenceMs
          if (active) setState('listening')
        } else if (out.endpoint && active && config.hasPendingDraft?.() && speechMs >= MIN_SPEECH_MS) {
          // 已有草稿时，待唤醒短句可能是独立的「确认发送」。先定稿，
          // 再由客户端严格匹配完整命令；partial 不能直接触发发送。
          finalizeSegment()
        }
        return
      }
      // 打断根治：服务端 Silero VAD 帧级检测结果下行，客户端据此驱动打断
      // （替代 RMS 能量快路径）；仅非 final 响应携带，undefined 表示本次无 VAD 信息。
      if (out.isSpeech !== undefined) config.onIsSpeech?.(out.isSpeech)
      if (state === 'loading-model') setState('speech')
      // P1-4：上传成功后才推进已传水位（失败/重试不推进，下一拍补传）。
      uploadedSamples = Math.max(uploadedSamples, from + samples.length)
      // 唤醒后（wakeConsumed）实时字幕同样剥掉词头：字幕与「实际会发出的内容」保持一致
      // （待机期的字幕不剥——那正是「它听到了什么」的诊断反馈）。
      emit(partialListeners, wakeConsumed ? stripWakePrefix(out.text ?? '', wakeWord) : (out.text ?? ''))
      // 批 5 / ADR-0008 Phase 1：backchannel 软让位。I2 保护：仅在「朗读期 + 已开口」下才判——
      //   朗读期（config.isPlaying()）= TTS 在播；speechActive = 本地检测已开口（避免用户自言自语被误让位）。
      //   partial 文本归一化后整段匹配词表，命中 → 触发 onBackchannel（client 侧 skipAudio + 1.5s hold 丢帧）。
      //   I3 保护：分支结构不动，只加 if，不动 emit / endpoint / finalizeSegment 等任何现有逻辑。
      // 批 F：backchannelYield=false 时不调 matchBackchannel（CPU 浪费修复；
      // matchBackchannel 含归一化 + Set 查找，partial 100ms 节拍下 1% CPU/朗读期）
      if (
        config.backchannelYield !== false &&  // 默认 true（I10 豁免）；显式 false 时跳过
        speechActive &&
        (config.isPlaying?.() ?? false) &&
        matchBackchannel(out.text ?? '')
      ) {
        config.onBackchannel?.()
      }
      // P2-1：host Silero VAD 端点提示（静音 ≥0.5s 判句完成）→ 立即定稿。
      // 客户端静音计时（silenceMs）保留为 VAD 模型缺失/超时兜底。
      // I3：hold 按住期间不判端点（松手才发，防思考停顿被拆句）。
      if (out.endpoint && active && speechActive && !holdActive) finalizeSegment()
    } catch {
      // 预览失败静默（Q16：识别重试由定时轮询自然覆盖）
    } finally {
      partialInFlight = false
    }
  }

  /**
   * 打断根治：播放期检测上行（vadOnly=1）。AI 朗读中段内无语音帧（自聊防护），
   * 常规 partial 断流 → host VAD 看不到用户语音 → isSpeech 恒 false → 打断失效。
   * 此通道把 AEC 后 mic 帧持续送 host 独立检测 VAD（不进 ASR 流、不碰端点 VAD），
   * 使「开口打断」在朗读中真实可用。失败静默（下一拍自动补传未发送部分）。
   */
  const requestDetect = async (): Promise<void> => {
    if (detectInFlight) return
    // 积压上界：网络失败或宿主卡顿时丢弃最旧帧——检测只关心「当前是否在说话」，
    // 陈旧音频无价值；防无界增长与超 64s（4MB）后每包必被 host 413 的死锁。
    // A 档修复：30s → 1s。停顿后补传整段积压会让下一次往返更慢（正反馈），
    // 而对「此刻是否在说话」而言 1s 之前的音频已无意义。
    let total = detectChunks.reduce((n, c) => n + c.length, 0)
    const MAX_DETECT_PENDING = 1 * SAMPLE_RATE
    if (total - detectSent > MAX_DETECT_PENDING) {
      detectSent = Math.max(0, total - MAX_DETECT_PENDING)
    }
    while (detectChunks.length > 0 && detectSent >= detectChunks[0].length) {
      detectSent -= detectChunks[0].length
      detectChunks.shift()
    }
    total = detectChunks.reduce((n, c) => n + c.length, 0)
    if (total - detectSent <= 0) return
    const samples = sliceChunks(detectChunks, detectSent)
    const epoch = segmentEpoch
    const gen = detectGeneration
    detectInFlight = true
    // fixture 录制：分离「往返耗时」与「客户端没排上」——停顿归因的唯一依据。
    const sentAt = Date.now()
    let rttMs = -1
    try {
      const res = await fetch(asrUrl(false, detectSent, epoch, 'vadOnly'), {
        method: 'POST',
        headers: { 'content-type': 'application/octet-stream' },
        body: samples.buffer as ArrayBuffer,
        signal: AbortSignal.timeout(5000), // 防服务端挂起长期锁死 detectInFlight（Important#2）
      })
      rttMs = Date.now() - sentAt
      if (epoch !== segmentEpoch || gen !== detectGeneration) return // 弃段/重置后迟到响应作废
      if (!res.ok) return
      const out = (await res.json()) as { isSpeech?: boolean }
      if (epoch !== segmentEpoch || gen !== detectGeneration) return
      if (out.isSpeech !== undefined) config.onIsSpeech?.(out.isSpeech)
      detectSent += samples.length
      // 释放已消费帧（长朗读下防缓冲无界增长）。
      while (detectChunks.length > 0 && detectSent >= detectChunks[0].length) {
        detectSent -= detectChunks[0].length
        detectChunks.shift()
      }
    } catch {
      // 超时/网络波动静默：未推进水位，下一拍重传
    } finally {
      detectInFlight = false
      if (fixtureRecorder.isActive) {
        fixtureRecorder.noteDetect(sentAt, rttMs < 0 ? Date.now() - sentAt : rttMs, rttMs >= 0, samples.length)
      }
    }
  }

  /** 清 host 识别流（弃段 / 滚窗清场）。
   *  issue #10 问题 3：经 resetGate 串行排队，且 requestPartial 上行前等门开
   *  （reset 先落地、partial 后上行）——防清场晚到把已喂样本抹掉（host 流丢头）。
   *  返回的 Promise 在本轮 reset 落地（或超时兜底）后 resolve。 */
  const resetHostStream = (): Promise<void> => {
    const prev = resetGate
    let release!: () => void
    resetGate = new Promise<void>((r) => {
      release = r
    })
    return (async () => {
      await prev // 多次 reset FIFO 串行
      try {
        // 超时防挂起：reset 是 fire-and-forget 语义，挂起不得阻塞 discardSegment/hardBreak。
        await fetch(asrUrl(false, undefined, undefined, 'reset'), { method: 'POST', signal: AbortSignal.timeout(5000) })
      } catch {
        // 重置失败：下次 partial 走增量仍可续（host 流健壮）
      }
      release()
    })()
  }

  /** prePad 环裁剪：只保留最近 PRE_PAD_MS 的帧（起始音补齐用，wake 与正常聆听共用）。 */
  const trimPrePad = (): void => {
    let total = 0
    let cut = 0
    for (let i = prePad.length - 1; i >= 0; i--) {
      total += (prePad[i].length / SAMPLE_RATE) * 1000
      if (total > PRE_PAD_MS) {
        cut = i + 1
        break
      }
    }
    if (cut > 0) prePad = prePad.slice(cut)
  }

  /** 清空 wake 待机段（本地缓冲 + 段纪元 + host 流），三处触发共用：
   *  朗读开始（自聊防护）/ 静音到点（停口重开）/ 30s 滚窗（上限兜底）。
   *  `segmentEpoch++` 作废在途 partial 响应——否则其会把已归零的 uploadedSamples
   *  水位写回旧值，后续增量对重置后的空 host 流只发尾部（段丢头）。 */
  const clearWakeSegment = (): void => {
    segmentEpoch++
    segment = []
    segmentMs = 0
    speechMs = 0
    silenceMs = 0
    wakeSilenceMs = 0
    wakeConsumed = false
    prePad = []
    uploadedSamples = 0
    void resetHostStream()
  }

  /** 定稿当前段：POST final=1（含 0.5s 尾垫由 host 补齐协议侧不需要）。
   *  force=true：绕过播放门（仅用于「播放前开着的真人声段在播放开始后收口」——
   *  段内全是播放前语音，无回声风险；见 handleAudio 播放门分支）。 */
  const finalizeSegment = (force = false): void => {
    if (segment.length === 0) return
    // 根治自聊：AI 朗读中的 finalize（由 VAD/上限/强制非 hold 触发）一律丢弃，
    // 防「TTS→回声→入段→autoSend」路径下的绕后发送。hold 松手（forcePending）明确
    // 发送意图放行；wake 分支本就不调用 finalize（滚窗重置），无需额外判。
    if (config.isPlaying?.() && !forcePending && !force) return
    // P1-5：强制发送 / 段长上限 / hold 松手等无静音过渡的端点路径，
    // 端点判句到点即「说完」时刻（无静音等待段）。
    if (utteranceEndAt === null) {
      utteranceEndAt = Date.now()
      emitTelemetry('utterance-end')
    }
    emitTelemetry('endpoint-fired')
    // P1-4：定稿 = 最后一个增量包打 final 标记（只传尚未上传的部分；可为空包）。
    const from = uploadedSamples
    const samples = sliceSince(from)
    // I2 修复：清段前保留段引用（chunk 数组不可变，零额外内存）——
    // 403 恢复时 host 流已被 reset，需从 0 全量重发，否则定稿缺前半句。
    const recoverySegment = segment
    // 对抗性审查 Fix：epoch 用「本段」世代快照（递增前），响应校验仍按当前世代比。
    const epochSnapshot = segmentEpoch
    segmentEpoch++
    const meta: SegmentMeta = { force: forcePending, wakeStandby: state === 'wake' && wakeEnabled }
    // 本段若消费过唤醒词（连说「你好小李+命令」），定稿时剥掉文本头部唤醒词再进草稿。
    const consumedWake = wakeConsumed
    wakeConsumed = false
    forcePending = false
    speechMs = 0 // P1-3：新段重新起算纯语音时长
    uploadedSamples = 0
    segment = []
    speechActive = false
    silenceMs = 0
    segmentMs = 0
    prePad = []
    setState('transcribing')
    void (async () => {
      emitTelemetry('submitted') // P1-5：定稿上传发起
      // 有界重试：host 已幂等（重复 final 返回缓存文本），瞬时失败（网络异常/5xx/非 JSON）
      // 重试最多 3 次；期间段被弃（世代变化）即停止。根治「单次瞬时失败丢整句」。
      const MAX_FINAL_ATTEMPTS = 3
      const restoreState = (): void => setState(active ? (speechActive || holdActive ? 'speech' : (wakeEnabled ? 'wake' : 'listening')) : 'idle')
      for (let attempt = 0; attempt < MAX_FINAL_ATTEMPTS; attempt++) {
        if (attempt > 0) {
          if (segmentEpoch !== epochSnapshot + 1) return // 段已弃，停止重试
          await new Promise((r) => setTimeout(r, 500 * attempt))
        }
        // 首次用增量尾巴（正常路径）；重试改用全量：host 按 seg.fed 去重幂等，且覆盖
        // 「403 恢复已 reset host 流，但恢复后的全量重发又失败」→ 尾巴重试会缺前半句。
        const useFull = attempt > 0
        const off = useFull ? 0 : from
        const body = useFull ? (sliceChunks(recoverySegment, 0).buffer as ArrayBuffer) : (samples.buffer as ArrayBuffer)
        let res: Response
        try {
          res = await fetch(asrUrl(true, off, epochSnapshot), { signal: AbortSignal.timeout(10000),
            method: 'POST',
            headers: { 'content-type': 'application/octet-stream' },
            body,
          })
        } catch {
          restoreState()
          if (attempt === MAX_FINAL_ATTEMPTS - 1) console.warn('[dsh-voice-hub] finalize fetch 异常（重试耗尽）')
          continue
        }
        if (res.status === 202) {
          setState('loading-model')
          res = await new Promise<Response>((resolve) => {
            setTimeout(async () => {
              try {
                resolve(
                  await fetch(asrUrl(true, off, epochSnapshot), { signal: AbortSignal.timeout(10000),
                    method: 'POST',
                    headers: { 'content-type': 'application/octet-stream' },
                    body,
                  }),
                )
              } catch {
                resolve(new Response(null, { status: 503 }))
              }
            }, 5000)
          })
        }
        // 5s 重试后模型仍加载（202 持久）：外层继续重试（有界 3 次），而非 return 静默丢句。
        if (res.status === 202) {
          if (attempt === MAX_FINAL_ATTEMPTS - 1) console.warn('[dsh-voice-hub] finalize 模型加载超时（重试耗尽）')
          continue
        }
        // 403 会话过期：host 端活跃会话已变更（如被抢占/让出），尝试恢复后重试一次。
        if (res.status === 403 && config.onSessionExpired) {
          const recovered = await config.onSessionExpired()
          if (recovered && segmentEpoch === epochSnapshot + 1) {
            // I2 修复：re-enter 已 asr.reset 清空 host 流，从 0 全量重发（恢复段引用），
            // 否则 host 只收到尾巴、定稿缺前半句（确定性丢首段）。
            try {
              res = await fetch(asrUrl(true, 0, epochSnapshot), { signal: AbortSignal.timeout(10000),
                method: 'POST',
                headers: { 'content-type': 'application/octet-stream' },
                body: sliceChunks(recoverySegment, 0).buffer as ArrayBuffer,
              })
            } catch {
              // 重试失败：静默（本循环下一轮重试）
            }
          }
        }
        // 段已被清（stop/新段）时世代变化，结果作废。
        restoreState()
        if (!res.ok) {
          if (attempt === MAX_FINAL_ATTEMPTS - 1) console.warn('[dsh-voice-hub] finalize 5xx（重试耗尽）')
          continue
        }
        // 容错：网关/宿主偶发 5xx 或响应非 JSON 时，不打断状态机也不误报——重试。
        let out: { text?: string }
        try {
          out = (await res.json()) as { text?: string }
        } catch {
          if (attempt === MAX_FINAL_ATTEMPTS - 1) console.warn('[dsh-voice-hub] finalize 响应非 JSON（重试耗尽）')
          continue
        }
        // 校验本段世代（快照+1）：仅当定稿期间又推进（新段/打断/stop）时作废；
        // 历史 bug：比较快照本身（snap!==now）必然不等 → 定稿恒被丢弃 → onSegment 永不触发。
        if (segmentEpoch !== epochSnapshot + 1) return
        // 唤醒词头剥离（content-preserving）：连说场景下词头仍在段首，剥掉后再进草稿；
        // 找不到唤醒词时 stripWakePrefix 原样返回——宁可不剥也不丢命令内容。
        const rawText = out.text ?? ''
        const finalText = consumedWake ? stripWakePrefix(rawText, wakeWord) : rawText
        if (finalText) {
          emit(transcriptListeners, finalText, meta)
        } else if (consumedWake && active && !speechActive && !holdActive) {
          // D5：本段只说了唤醒词（剥完为空）→ **不关命令窗口**，保持聆听等用户补命令。
          // 「唤醒词…停顿（> silenceMs）…命令」是高频交互；若回待机态，后面的命令会被当
          // 待机音频丢弃（真机台架实证 0 条定稿）。restoreState 刚置的 'wake' 在此覆盖。
          setState('listening')
        }
        return
      }
      // 3 次重试耗尽仍失败：触发 onError → 状态条「识别失败，请重试」（防静默丢句）。
      emitError('recognitionFail')
    })()
  }

  /** A2.5 回声门控：播放期残差 RMS 与回声地板（纯回声残差水平），自动打断区分人声与回声。 */
  let latestResidualRms = 0
  let echoFloorRms = 0
  /** 残差峰值（慢衰减）——门控用它而非瞬时值：用户话音断断续续，瞬时值会在
   *  音节间隙掉回回声水平被误拒；峰值保持住「刚才确实有语音」的证据。 */
  let echoPeak = 0

  const handleAudio = (raw: Float32Array): void => {
    if (!active || inFlush) return
    // 手动打断只在播放期间挡住未经按压的音频；否则 detect 探测到浏览器 AEC 不可用时，
    // 会把普通持续聆听一并关闭，表现为按钮已激活、波形和文字却始终不动。
    const playingNow = config.isPlaying?.() ?? false
    if (runtimeBargeInMode === 'manual' && playingNow && !holdActive) return
    // 跨平台守卫：Safari 等浏览器会忽略 AudioContext({sampleRate}) 选项，
    // 实际按 44.1k/48k 输出。非 16k 时先线性重采样，保证 host zipformer2
    // 始终收到 16k PCM（避免识别错乱）。
    let data = ctxRate !== SAMPLE_RATE ? resampleLinear(raw, ctxRate, SAMPLE_RATE) : raw
    // fixture 录制（ADR-0004，默认关闭）：留住 AEC 前的 mic 与参考窗，供离线重放。
    const recMicPre = data
    let recRef: Float32Array | null = null
    // P3-2：回声参考（TTS 播放 → NLMS 消除回声）后再做打断/VAD/上行判定。
    if (echo) {
      const ref = echo.windowAt(performance.now(), data.length)
      recRef = ref
      data = echo.process(data, ref)
    }
    let sum = 0
    for (let i = 0; i < data.length; i++) sum += data[i] * data[i]
    const rms = Math.sqrt(sum / data.length)
    const durationMs = (data.length / SAMPLE_RATE) * 1000

    for (const fn of levelListeners) {
      try {
        fn(Math.min(1, rms / LEVEL_CEILING))
      } catch {
        // ignore
      }
    }

    // 打断前沿：已由服务端 Silero VAD 帧级 isSpeech 驱动（阶段二，取代原 RMS 能量
    // 快路径 + P0 瞬态抑制 + P1 噪声自适应）；此处不再做能量域打断判定。

    // 打断根治：播放窗口（含尾音宽限）内，AEC 后帧同时进入检测通道（vadOnly 上行）。
    // hold 有明确意图路径（segment 正常累积、partial 上行）。
    // 回声地板：慢均值跟踪，仅在「纯回声期」更新（playingNow 且残差未明显高于地板）。
    // 关键：句间停顿（playingNow=false）不更新也不清空——地板保持在上一次回声水平，
    // 避免塌到 0（实测 floor=0.0000 自打断的根因，是 min-tracking + 非播放清空的回归）。
    // 双讲（用户说话，残差突增）时冻结地板，防用户语音抬升地板。
    const gateRatio = Math.pow(10, (config.echoGateDb ?? 6) / 20)
    // 墙钟归一化（帧长随 ctxRate 21ms@48k / 64ms@16k 波动）：以 64ms 为基准帧，把峰值
    // 衰减与地板 alpha 折算到本帧时长，跨浏览器口径一致（Safari 48k 不再衰减过快）。
    const peakDecay = Math.pow(0.9, durationMs / 64)
    const floorAlpha = 1 - Math.pow(0.98, durationMs / 64)
    if (playingNow) {
      latestResidualRms = rms
      // 峰值保持（慢衰减 ~0.4s，跨音节间隙保持语音证据）。
      echoPeak = Math.max(echoPeak * peakDecay, rms)
    }
    // 双讲冻结用瞬时 rms（保守：稳定回声期地板仍能跟踪）；门控用 echoPeak（激进：跨音节间隙
    // 保持语音证据）。两者口径本应不同——用峰值判冻结会让地板永久锁死在低值，回声变响时全过门
    // 致自打断（对抗审查 Open#9）。
    const doubleTalk = playingNow && echoFloorRms > 0 && rms > echoFloorRms * gateRatio
    if (playingNow) {
      if (echoFloorRms === 0) echoFloorRms = rms
      else if (!doubleTalk) echoFloorRms = echoFloorRms * (1 - floorAlpha) + rms * floorAlpha
    } else {
      echoPeak = 0
    }
    if (echo) {
      echo.setFrozen(doubleTalk)
    }
    // fixture 录制（默认关闭；开关见 fixture-recorder.ts）：门控统计已算完，此处落一帧。
    if (fixtureRecorder.isActive) {
      fixtureRecorder.frame(recMicPre, recRef, data, {
        rms,
        floorRms: echoFloorRms,
        peakRms: echoPeak,
        doubleTalk,
        playingTail: playingNow,
      })
    }
    // hold 模式打断走显式手势（按住），不走 VAD 检测通道；toggle 模式保留检测通道。
    if (playingNow && !holdActive && config.mode !== 'hold') detectChunks.push(data)

    if (holdActive) {
      // hold：按压区间全部保留（绕过 VAD 门控与静音切句），仅段长上限兜底。
      if (!speechActive) {
        speechActive = true
        if (state !== 'speech') setState('speech')
      }
      segmentMs += durationMs
      silenceMs = 0
      segment.push(data)
      if (segmentMs > MAX_SEGMENT_MS) finalizeSegment()
    } else if (config.mode === 'hold') {
      // hold 模式且未按住：不持续聆听（不建段、不 auto-send），底部 ticker 照跑（无数据自然跳过）。
    } else if (state === 'wake') {
      // wake 待机段：音频组装与正常聆听路径**同构**（prePad 补起始音 + 开口后连续帧含
      // 尾随静音），但不置 speechActive、不 finalize——唤醒词匹配在 partial 响应上做。
      // 三条真机实证不变量（唤醒词「几乎无法触发」的两个流程根因，见 test/wake-flow）：
      // 1) 朗读期不入段并清残留（自聊防护，对齐下方 rms>SPEECH_RMS 分支的 isPlaying 守卫）：
      //    否则 TTS 回声进待机段，朗读结束后第一次 partial 把「AI 的话 + 唤醒词」整段上传，
      //    host 累计文本以 AI 的话开头 → 唤醒词头部锚定（startsWith/lead 窗口）永远失配。
      // 2) 开口后静音帧照常入段上传：流式解码器要尾随音频才 flush 得出尾字；只发超门限帧
      //    会让用户一停口就没有新帧、不再发 partial，文本停在半截（4 字唤醒词只剩 2 字 →
      //    编辑距离 2 → 失配）。
      // 3) 起始音补齐（prePad）：唤醒词首字常是弱起音，直接上门限会被切掉。
      if (config.isPlaying?.()) {
        if (segment.length > 0) clearWakeSegment()
        prePad = [] // 朗读期不积累起始音环（防朗读前残留帧混进下一次唤醒）
      } else if (rms > SPEECH_RMS) {
        if (segment.length === 0) {
          for (const p of prePad) segment.push(p) // 起始音补齐（对齐正常路径）
        }
        prePad = []
        segmentMs += durationMs
        speechMs += durationMs // 待机段同样是纯语音：计入时长，命中定稿时过 MIN_SPEECH_MS
        segment.push(data)
        wakeSilenceMs = 0
        // 上限兜底：滚窗重置（防无唤醒词时无界累积）。
        if (segmentMs > MAX_SEGMENT_MS) clearWakeSegment()
      } else if (segment.length > 0) {
        // 已开口：尾随静音照常入段上传（保音频连续 + 让 host flush 尾字）。
        // 停满一个断句静音即清窗重开（下一句从段首起算），兼自愈任何 host 流丢头。
        segmentMs += durationMs
        segment.push(data)
        wakeSilenceMs += durationMs
        if (wakeSilenceMs >= config.silenceMs) {
          if (config.hasPendingDraft?.() && speechMs >= MIN_SPEECH_MS) finalizeSegment()
          else clearWakeSegment()
        }
      } else {
        // 尚未开口：维护 prePad 环（只留最近 PRE_PAD_MS）。
        prePad.push(data)
        trimPrePad()
      }
    } else if (rms > SPEECH_RMS) {
      // 根治自聊：AI 朗读期间 VAD 入段丢弃（回声经 AEC 残留仍超 threshold 会被误识为语音）。
      // 此分支已天然排除 hold（前 if(holdActive)），故无需再判——hold 是明确意图。
      if (config.isPlaying?.()) {
        // 播放已开始：若播放前开着的段仍在（用户边说 AI 边开播），立即强制收口——
        // 段内全是播放前真人声（播放期语音帧不进段）；释放 speechActive 后本帧起
        // 检测通道接管打断，防「陈旧 speechActive 饿死检测通道」致整段回复无法打断。
        if (speechActive) finalizeSegment(true)
        // 此处**不得 return**（历史 bug，真机实测定位）：return 会连带跳过函数末尾的
        // 轮询块，于是「播放中且 rms 超门限」的帧一律不发检测请求——而这正是用户开口
        // 打断的那些帧。用户说得越响越连续，检测通道发得越少，请求只在音节间隙漏出去。
        // 实测：6s 打断窗口内本应发 47 次，实际只发 10 次，确认耗时被拉到 753~951ms。
        // 本帧不入段（自聊防护，语义不变），但轮询照常。
      } else {
        if (!speechActive) {
          speechActive = true
          // 打断根治：新一轮人声开始，清残留检测帧（上一播放窗口未发送的尾部已无意义）；
          // 代际递增作废跨边界在途响应（防 detectSent 水位毒化）。
          detectChunks = []
          detectSent = 0
          detectGeneration++
          // P1-5：新一轮语音开始，复位「说完」标记（下一轮 chain 重新起算）。
          utteranceEndAt = null
          setState('speech')
          for (const p of prePad) segment.push(p)
          prePad = []
        }
        speechMs += durationMs
        segmentMs += durationMs
        silenceMs = 0
        segment.push(data)
        if (segmentMs > MAX_SEGMENT_MS) finalizeSegment()
      }
    } else if (speechActive) {
      // P1-5：说完最后一个字 = 语音→静音过渡的首帧（每段只报一次）。
      if (utteranceEndAt === null) {
        utteranceEndAt = Date.now()
        emitTelemetry('utterance-end')
      }
      segmentMs += durationMs
      silenceMs += durationMs
      segment.push(data)
      if (silenceMs > config.silenceMs) {
        if (speechMs >= MIN_SPEECH_MS) {
          finalizeSegment()
        } else {
          // P1-3：语音不足 250ms（短促噪声/误触）：放弃本段，不发送。
          segmentEpoch++ // I4：作废在途 partial 响应（防其推进 uploadedSamples 水位错乱）
          segment = []
          speechActive = false
          speechMs = 0
          silenceMs = 0
          segmentMs = 0
          prePad = []
          utteranceEndAt = null
          uploadedSamples = 0 // P1-4：弃段后 host 流重新起算
          void resetHostStream()
          setState('listening')
        }
      }
    } else {
      prePad.push(data)
      trimPrePad()
    }

    // partial / 检测通道轮询：墙钟节拍（名义 100ms；条件不满足时不清节拍，
    // 条件转为满足的下一帧立即补发，语义与原「帧时长累加」一致）。
    const nowMs = Date.now()
    if (nowMs - lastPollAt >= PARTIAL_INTERVAL_MS) {
      // A 档修复：只有「真的发出去了」才推进节拍。
      // 此前无论请求是否被在途标志挡下都推进 lastPollAt——一次超过 128ms 的往返会连着
      // 吃掉后续整拍，把观测栅格量化到 RTT 向上取整的 128ms 倍数（实测停顿 449/758ms）。
      // 改后：在途期间不推进，请求一回来，下一帧（≤64ms）立即补发。
      if (playingNow && !speechActive && !holdActive) {
        // 打断根治：朗读中优先检测通道。
        if (!detectInFlight) {
          lastPollAt = nowMs
          void requestDetect()
        }
      } else if (speechActive || holdActive || state === 'wake') {
        if (!partialInFlight) {
          lastPollAt = nowMs
          void requestPartial()
        }
      }
    }
  }



const startRecorder = async (): Promise<void> => {
    // 捕获本启动序号：getUserMedia 异步授权返回期间若发生 stop→start（或再次 start），
    // startSeq 被推进，据此放弃本启动。此前用模块级 curStartSeq 比较——新 start() 会覆盖
    // curStartSeq，旧启动返回时 curStartSeq===startSeq 恒真、守卫失效（对抗审查 Blocker）。
    const mySeq = startSeq
    stream = config.microphone?.getAudioTracks().some((track) => track.readyState === 'live')
      ? config.microphone
      : await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        // 与 talk-sdk demo 的采集链一致。弱音量真机语音若不经浏览器增益处理，
        // 可能始终低于本地开段门槛，唤醒词连 ASR 请求都发不出去。
        noiseSuppression: true,
        autoGainControl: true,
      },
    })
    // Fix8 修正：授权返回时若已被 stop() 抢占（stopRequested）或已被更新的启动取代
    // （序号落后 → 双路开麦防呆）则立即释放麦克风。注意不能用 active 判断——
    // 它在函数末尾才置 true。
    if (stopRequested || mySeq !== startSeq) {
      stream.getTracks().forEach((t) => t.stop())
      stream = null
      return
    }
    // A1：验证浏览器原生 AEC 是否真正生效。约束在首次 getUserMedia 建立处理链时生效，
    // track.getSettings() 是唯一可见信号；false 时外放回声几乎必然漏进 → 自打断。
    const aecOn = stream.getAudioTracks()[0]?.getSettings().echoCancellation === true
    if (!aecOn) {
      console.warn('[dsh-voice-hub] 浏览器原生 echoCancellation 未生效（外放可能自打断），建议用耳机或「手动打断」')
    }
    // 批 7O（ADR-0006）第一级自动探测：detect 模式根据原生 AEC 实际状态落运行时打断方式。
    //   false → manual（不自打断，配合状态条提示）；true → auto。auto/manual 显式取值不探测。
    if (config.bargeInMode === 'detect') {
      runtimeBargeInMode = aecOn ? 'auto' : 'manual'
    }
    config.onAecState?.(aecOn)
    const AC: typeof AudioContext =
      window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    audioCtx = new AC({ sampleRate: SAMPLE_RATE })
    // iOS Safari：非手势栈创建的上下文初始为 suspended，不恢复则 onaudioprocess
    // 永不触发（进入语音模式后静默无反应）——在 getUserMedia 手势栈内尝试恢复。
    try {
      await audioCtx.resume?.()
    } catch {
      // 恢复失败不阻塞（部分场景仍可用；状态条会提示收音异常）
    }
    // 浏览器可能忽略 sampleRate 选项（Safari 等）：记录真实采样率供重采样。
    ctxRate = audioCtx.sampleRate
    const source = audioCtx.createMediaStreamSource(stream)
    // 优先 AudioWorklet（专用音频线程，摆脱 ScriptProcessor 主线程卡顿/glitch）；
    // 不支持或 addModule 失败时回退 ScriptProcessor（跨浏览器兜底，行为与旧版一致）。
    if (audioCtx.audioWorklet) {
      try {
        if (!workletBlobUrl) {
          workletBlobUrl = URL.createObjectURL(new Blob([__AUDIO_WORKLET__], { type: 'text/javascript' }))
        }
        await audioCtx.audioWorklet.addModule(workletBlobUrl)
        workletNode = new AudioWorkletNode(audioCtx, 'voice-capture', { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1] })
        workletNode.port.onmessage = (e: MessageEvent<Float32Array>) => {
          handleAudio(e.data)
        }
        source.connect(workletNode)
        workletNode.connect(audioCtx.destination) // 保持图活跃；worklet 不写输出 = 静音，无反馈
        ctxRate = SAMPLE_RATE // worklet 已重采样到 16k，handleAudio 跳过重采样
        active = true
        return
      } catch {
        try {
          workletNode?.disconnect()
        } catch {
          // ignore
        }
        workletNode = null
      }
    }
    processor = audioCtx.createScriptProcessor(BUFFER_SIZE, 1, 1)
    processor.onaudioprocess = (e) => {
      handleAudio(new Float32Array(e.inputBuffer.getChannelData(0)))
    }
    source.connect(processor)
    processor.connect(audioCtx.destination)
    active = true
  }

  const stopRecorder = async (): Promise<void> => {
    // 根治 403：active 已在 stop() 中置 false，此处不再检查（否则清理逻辑被跳过）。
    inFlush = true
    segmentEpoch++ // 迟到的请求结果全部作废
    forcePending = false
    holdActive = false
    segment = []
    speechActive = false
    silenceMs = 0
    segmentMs = 0
    speechMs = 0
    wakeSilenceMs = 0 // issue #10：待机静音计时随会话清场
    wakeConsumed = false // 会话清场即作废词头消费标记
    uploadedSamples = 0 // P1-4：会话结束清除已传水位
    prePad = []
    detectChunks = [] // 打断根治：退出清检测通道
    detectSent = 0
    detectGeneration++
    utteranceEndAt = null // P1-5：会话结束清除说完标记
    try {
      processor?.disconnect()
    } catch {
      // ignore
    }
    processor = null
    try {
      workletNode?.disconnect()
    } catch {
      // ignore
    }
    workletNode = null
    try {
      stream?.getTracks().forEach((t) => t.stop())
    } catch {
      // ignore
    }
    stream = null
    try {
      await audioCtx?.close()
    } catch {
      // ignore
    }
    audioCtx = null
    ctxRate = SAMPLE_RATE
    inFlush = false
  }

  return {
    get state() {
      return state
    },
    get holding() {
      return holdActive
    },
    /** A2.5 回声门控：当前残差是否明显高于回声地板（marginDb 默认 6dB）——判用户人声而非回声。 */
    aboveEchoFloor(marginDb = 6) {
      // 无地板（刚开播）→ 保守拒绝打断：放行会让外放回声在首播秒内误触发自打断
      // （实测外放 auto 根因之一）；代价是首播前 ~2s 无法自动打断（真机可接受）。
      if (echoFloorRms === 0) return false
      // 用峰值（跨音节间隙）而非瞬时值：瞬时值在音节停顿处掉回回声水平被误拒。
      return echoPeak > echoFloorRms * Math.pow(10, marginDb / 20)
    },
    echoLevels() {
      return { floorRms: echoFloorRms, residualRms: latestResidualRms, peakRms: echoPeak }
    },
    async start() {
      if (active) return
      stopRequested = false // Fix8：新一次启动清除取消标记
      startSeq++ // 防双路开麦：推进启动序号（startRecorder 入口捕获 mySeq，返回时按差序放弃旧启动）
      segmentEpoch++
      lastPollAt = 0
      holdActive = false
      detectChunks = [] // 打断根治：进入清检测通道
      detectSent = 0
      detectGeneration++
      // 配置了唤醒词（且非 hold 模式）→ 先进 wake 待机态；否则直接聆听。
      setState(wakeEnabled ? 'wake' : 'listening')
      try {
        await startRecorder()
      } catch (error) {
        setState('idle')
        throw error
      }
    },
    async stop() {
      // Fix8：即使 active=false（授权挂起中被抢占）也要标记取消，让授权返回后释放。
      stopRequested = true
      // 根治 403：stop 立即置 active=false，阻止 handleAudio 在 stopRecorder 异步完成前继续发请求。
      const wasActive = active
      active = false
      if (!wasActive) {
        setState('idle')
        return
      }
      await stopRecorder()
      setState('idle')
    },
    forceSend() {
      // 至少 250ms 语音才强制发送（≥250ms 防误触，Q5）；标记 force 供 autoSend=false 兜底
      const speechS = segment.reduce((n, c) => n + c.length, 0) / SAMPLE_RATE
      if (speechActive && speechS >= 0.25) {
        forcePending = true
        lastPollAt = 0
        finalizeSegment()
      }
    },
    beginHeld() {
      if (!active || holdActive) return
      holdActive = true
      // 不在此置 forcePending：hold 期间 30s 滚段定稿应只累积（松手才发），
      // force 统一由 endHeld 松手时置位，避免按住 >30s 被提前发送。
      segmentEpoch++ // 作废迟到的 wake/旧段 partial
      wakeConsumed = false // 新段重新起算词头消费
      utteranceEndAt = null // P1-5：新按压段重新起算说完时刻
      segment = []
      segmentMs = 0
      speechMs = 0
      silenceMs = 0
      prePad = []
      uploadedSamples = 0 // Fix：hold 新段重置上传水位，防旧段水位污染
      detectChunks = [] // 打断根治：hold 按压期间走 segment 路径，清残留检测帧
      detectSent = 0
      detectGeneration++
      speechActive = true
      lastPollAt = 0
      setState('speech')
    },
    discardSegment() {
      // 语义与 P1-3「短语音弃段」一致：清本地段 + 作废迟到 partial + host 流重置。
      segmentEpoch++
      segment = []
      segmentMs = 0
      speechMs = 0
      silenceMs = 0
      wakeSilenceMs = 0 // issue #10：待机静音计时不跨打断残留
      wakeConsumed = false // 弃段即作废词头消费标记
      speechActive = false
      prePad = []
      uploadedSamples = 0
      detectChunks = [] // 打断根治：打断弃段同时清检测通道（残留帧已无意义）
      detectSent = 0
      detectGeneration++
      utteranceEndAt = null
      forcePending = false
      lastPollAt = 0
      // Fix：等待 host 流重置完成后再恢复状态（防新段使用旧流）
      return resetHostStream().then(() => {
        if (active) setState(wakeEnabled ? 'wake' : 'listening')
      })
    },
    endHeld(cancel = false) {
      if (!active || !holdActive) return
      holdActive = false
      if (cancel) {
        // 放弃本段（滑出取消 / Escape / blur 兜底）
        segmentEpoch++
        segment = []
        segmentMs = 0
        silenceMs = 0
        prePad = []
        speechActive = false
        forcePending = false // 对抗性审查 Fix：取消段不得泄漏 force 标记（否则下段静默绕过 autoSend=false）
        setState(wakeEnabled ? 'wake' : 'listening')
        return
      }
      // Fix：segment 为空时不设置 forcePending（防 finalizeSegment 早退后 force 标记泄漏到下段）
      if (segment.length > 0) {
        forcePending = true
        lastPollAt = 0
        finalizeSegment()
      } else {
        forcePending = false
        setState(wakeEnabled ? 'wake' : 'listening')
      }
    },
    onSegment(fn) {
      transcriptListeners.add(fn)
      return () => {
        transcriptListeners.delete(fn)
      }
    },
    onError(fn) {
      errorListeners.add(fn)
      return () => {
        errorListeners.delete(fn)
      }
    },
    onPartial(fn) {
      partialListeners.add(fn)
      return () => {
        partialListeners.delete(fn)
      }
    },
    onState(fn) {
      stateListeners.add(fn)
      fn(state)
      return () => {
        stateListeners.delete(fn)
      }
    },
    onLevel(fn) {
      levelListeners.add(fn)
      return () => {
        levelListeners.delete(fn)
      }
    },
    onTelemetry(fn) {
      telemetryListeners.add(fn)
      return () => {
        telemetryListeners.delete(fn)
      }
    },
  }
}
