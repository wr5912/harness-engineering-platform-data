/**
 * dsh-voice-hub client half：语音模式入口、采音引擎与状态条。
 *
 * 入口（Q12）：输入框工具排麦克风按钮（conversation.input.right）+ 全局
 * Ctrl+Shift+V；激活后输入框上方常驻状态条（conversation.input.dock）。
 * 全局单活（Q9）：host 为真相源 + 共用连接 mode 广播纠正多标签页漂移；切换会话/
 * 被抢占自动让出（Q11）。打字即退出（Q13 双通道不混入）。
 * 输入链路（§8.3）：持续聆听 -> 端点判定（host Silero VAD 优先，静音 1500ms 兜底）-> partial 轮询
 * 字幕预览 -> 定稿进草稿 + 自动提交；按住 Ctrl 强制立即发送。
 */
import * as React from 'react'
import { useEffect, useRef, useState } from 'react'
import { createAsrEngine, type AsrEngine, type AsrState, type EchoRefSource } from './asr.ts'
import { NlmsAec, estimateBulkDelay } from './aec.ts'
import { resampleLinear } from './resample.ts'
import { fixtureRecorder } from './fixture-recorder.ts'
import { t, type TKey } from './strings.ts'
import { DEFAULT_SEND_COMMANDS, matchesSendCommand } from './send-command.ts'
import { SherpaKwsEngine } from './kws/sherpa-kws-engine.ts'
import { splitWakeWords } from './wakeword.ts'

/**
 * 打断根治阶段二：isSpeech 连续 true 计数（模块级；全局单活架构下 createVoiceBus
 * 仅一个实例、语音模式同时至多一个会话在播，模块级与闭包级等价且无并发串扰）。
 * partial / 检测通道轮询墙钟节拍 100ms；达到 INT_CONFIRM_FRAMES 即判真实人声前沿。
 */
let isSpeechTrueCount = 0
/** 打断确认测量：VAD 首次判真时刻（播放中）；触发 hardBreak 时计算确认耗时。 */
let interruptFirstAt = 0
/** 连续「假」样本数（打断确认迟滞）：单拍假不衰减计数，连续 2 拍假才衰减——
 *  缓解 Silero VAD 音节边缘抖动导致的 confirmMs 飙高（566~2796ms 真机实测）。 */
let isSpeechFalseRun = 0
/** 403 重入冷却时刻（对抗审查 I3：无退避会与对端互踢振荡，打爆 /toggle）。 */
let lastReenterAt = 0
/** 打断灵敏度三档 → isSpeech 连续确认帧数（墙钟节拍 100ms/拍 + 上行往返 → 确认阶段约 0.3/0.2/0.1s；语义对齐旧能量持续时长档位）。 */
const INT_CONFIRM_FRAMES: Record<0 | 1 | 2, number> = { 0: 3, 1: 2, 2: 1 }
import { VoiceServiceSettingsPage } from './service-settings.tsx'
import { TYPERT_REMOTE } from '../lib/typert.remote-client.js'
import type { VoiceEvent, TtsChunkFrame } from './voice-remote.ts'

export const inject = ['slots', 'sessions', 'remote']

interface VoiceUiState {
  state: AsrState
  partial: string
  /** 麦克风端电平（采集侧 RMS，按 100ms 周期推）。 */
  levels: number[]
  /** 朗读端电平（播放侧 RMS，按 PCM 帧推；前端 SVG 双条波形用）。 */
  botLevels: number[]
  error: string | null
  /** 正在朗读的句子字幕（播放引擎写入）。 */
  playingCaption: string | null
  playing: boolean
  /** 模型下载进度（host asr-progress 事件写入）。 */
  model: { file: string; percent: number } | null
  /** TTS 不可达的暂时提示（host tts-error 事件写入，下一帧成功即清）。 */
  ttsNotice: string | null
  /** 本会话激活时读取的引导参数（bus 单例，跨组件重挂载稳定）。 */
  boot: VoiceBootConfig
  /** 便捷速记：交互模式（状态条与手势读取）。 */
  mode: 'toggle' | 'hold'
  /** P2-4 host 回合状态（共用连接 'turn'；状态条展示思考中/朗读中）。 */
  turn: 'idle' | 'listening' | 'finalizing' | 'agent-speaking'
  /** 打断根治阶段一：服务端 Silero VAD 帧级语音检测（partial 响应下行；可读存储，供下一阶段接入打断；undefined=无 VAD 信息）。 */
  isSpeech?: boolean
  /** 打断确认耗时（ms）：VAD 首次判真 → 确认帧数达标触发 hardBreak；真机标定 C-3 用。 */
  interruptConfirmMs?: number
  /** 回声诊断：估计 bulk delay（毫秒，未收敛=0）。 */
  echoDelayMs?: number
  /** 回声诊断：{ 地板 RMS, 当前残差 RMS }（标定 echoGateDb 用）。 */
  echoLevels?: { floorRms: number; residualRms: number }
  /** A1：浏览器原生回声消除是否生效（false 时外放易自打断，状态条提示）。 */
  aecOff?: boolean
  /** 批 7O（ADR-0006）：detect 模式第一级探测落 manual（原生 AEC 未生效）时的状态条提示标记。 */
  bargeInDetectFallback?: boolean
  /** 批 G 任务 2：空闲预警态标记（resetIdle 触发 9:30 预警 → true；用户活动 / clearIdle 复位 → false）。
   *  状态条据此展示「30 秒后自动退出」toast。 */
  idleWarn?: boolean
  /** 批 H 任务 4：一次性提示文案（状态条展示 5s 后自动清；与 idleTimeoutQuit toast 共用模式）。
   *  当前用于 autoResume 关 + 切回上次会话时引导用户开启自动恢复。 */
  notice?: string | null
  /** 延迟埋点链各阶段时刻（开发模式状态条展示；null = 未启用/已清空）。 */
  telemetry: Partial<Record<TelemetryStage, number>> | null
  /** 唤醒词（空 = 关）：wake 待机态状态条展示用。 */
  wakeWord: string
  wakeStatus: 'off' | 'loading' | 'on'
  /** 当前标签页接管的被动播报会话。 */
  readSessionId: string | null
  /** 当前标签页正在单次朗读的助手回复。 */
  manualReadSessionId: string | null
  manualReadMessageId: string | null
  /** 当前页面展示的会话，供审批提示在未开麦克风时播放。 */
  visibleSessionId: string | null
}

/**
 * 音频协议在 voice-remote.ts 共享维护；PCM 分块可在整句结束前起播。
 */
/** 播放引擎的整句帧（客户端按句拼帧后的产物；P1-2 Web Audio 队列的输入）。 */
interface PlayFrame {
  encoding?: 'pcm-s16le'
  sampleRate?: number
  sourceMessageId?: string
  sessionId: string
  seq: number
  /** 剥离 markdown 后的句子文本（实时字幕）。 */
  text: string
  /** 整句音频字节（MP3 或 WAV；自有 ArrayBuffer 缓冲，可直接入 Blob）。 */
  audio: Uint8Array<ArrayBuffer>
  /** 音频 MIME（audio/mpeg = Edge；audio/wav = 本地 VITS/Kokoro；降级 <audio> 路径用）。 */
  mime?: string
}

/**
 * 延迟埋点链阶段（P1-5）：utterance-end → endpoint-fired → submitted 由 ASR 引擎
 * 本地上抛；first-llm-token / first-sentence-text 由 host 共用连接 'latency' 事件下行；
 * first-tts-chunk 为首帧音频到达；first-audio-played 为真实起播。全部取浏览器端
 * 接收/发生时刻（localhost 同机同钟，段间差值即端到端耗时）。
 */
export type TelemetryStage =
  | 'utterance-end'
  | 'endpoint-fired'
  | 'submitted'
  | 'first-llm-token'
  | 'first-sentence-text'
  | 'first-tts-chunk'
  | 'first-audio-played'

/** 链顺序与状态条展示标签（每段耗时 = 本阶段时刻 − 上一阶段时刻）。 */
const TELEMETRY_VIEW: { stage: TelemetryStage; key: TKey }[] = [
  { stage: 'utterance-end', key: 'telUtteranceEnd' },
  { stage: 'endpoint-fired', key: 'telEndpoint' },
  { stage: 'submitted', key: 'telSubmitted' },
  { stage: 'first-llm-token', key: 'telFirstToken' },
  { stage: 'first-sentence-text', key: 'telFirstSentence' },
  { stage: 'first-tts-chunk', key: 'telFirstChunk' },
  { stage: 'first-audio-played', key: 'telFirstPlayed' },
]

/**
 * 开发模式开关：localStorage['dsh-voice-mode.telemetry'] === '1' 时状态条实时显示
 * 「说完→首音」链路各段耗时（P1-5 延迟验收的测量面）。关闭时零采集零展示
 * （host 'latency' 事件照常下行，客户端不理会）。
 */
/** 构建版本号（build.mjs 用 esbuild define 注入 git 短哈希）。 */
declare const __BUILD_TAG__: string

// 进入语音模式相关的调试信息统一带版本号，便于确认运行的是哪一版（构建时注入 git 哈希）。
const BUILD_TAG = __BUILD_TAG__

const TELEMETRY_FLAG = 'dsh-voice-mode.telemetry'
const telemetryEnabled =
  typeof localStorage !== 'undefined' && localStorage.getItem(TELEMETRY_FLAG) === '1'

// 无条件打一次构建版本（进入页面即见，不依赖 telemetry），确认加载的 bundle 版本。
console.log('[dsh-voice] 插件构建版本：' + BUILD_TAG)

/** 调试控制台日志：telemetry=1 时把打断判定链的关键决策/输入打到 console，
 *  格式 [dsh-voice] <event> {json}，便于复制回传排查。 */
const debugLog = (event: string, fields: Record<string, unknown> = {}): void => {
  if (!telemetryEnabled) return
  // 数字保留 4 位小数（浮点可读），其余原样。
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(fields)) {
    out[k] = typeof v === 'number' && !Number.isInteger(v) ? Number(v.toFixed(4)) : v
  }
  console.log('[dsh-voice] 语音诊断事件：', event, JSON.stringify(out))
}

/** 工具提示音上下文（toolBeep 设置项，默认关；进入语音模式的手势栈内预热）。 */
let beepCtx: AudioContext | null = null
function playToolBeep(): void {
  try {
    if (!beepCtx) beepCtx = new AudioContext()
    void beepCtx.resume?.()
    const ctx = beepCtx
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    gain.gain.setValueAtTime(0.08, ctx.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1)
    osc.connect(gain)
    gain.connect(ctx.destination)
    osc.start()
    osc.stop(ctx.currentTime + 0.1)
  } catch {
    // beep 失败静默
  }
}

interface VoiceBus {
  /** host 当前活跃语音会话（全局单活指针）。 */
  get activeSessionId(): string | null
  ui: VoiceUiState
  subscribe(fn: (b: { active: string | null; ui: VoiceUiState }) => void): () => void
  setUi(patch: Partial<VoiceUiState>): void
  enter(sessionId: string): Promise<{ ok: boolean; error?: string; preempted?: boolean }>
  exit(sessionId: string): Promise<void>
  setRead(sessionId: string, on: boolean): Promise<boolean>
  readOnce(sessionId: string, messageId: string, on: boolean): Promise<boolean>
  setVisibleSession(sessionId: string | null): void
  /** 音频分块帧到达（播放引擎消费前由客户端按句拼帧）。 */
  onAudioFrame(fn: (frame: TtsChunkFrame) => void): () => void
  /** 批 5：设置/清除 backchannel 让位窗口（hardBreak 路径清 0；onBackchannel 触发设 now+1500）。 */
  setBackchannelHold(untilMs: number): void
  /** 清播放队列 + 停当前句（本地 skip，打断第一层）。 */
  skipAudio(): void
  /** P3-2：回声消除源（参考窗口 + NLMS），供 ASR 引擎注入。 */
  echoForAsr(): EchoRefSource
  /** 原生 AEC 生效时旁路自研 NLMS（原生 AEC3 已消净，自研 delay=0 错位反而制造尖峰）。 */
  setEchoBypass(on: boolean): void
  /** 回声诊断：估计的 bulk delay（毫秒，未收敛=0）。 */
  echoDelayMs(): number
  /** P3-3：恢复 TTS 增益（无爆音斜坡；hardBreak 打断后调用，确保音量不残留压低态）。 */
  unduckAudio(): void
  /** 取消当前回合（keepInbox 保新消息，Q2 打断第二层）。 */
  cancelTurn(sessionId: string): void
  /** P1-5 开发埋点：ASR 引擎事件（utterance-end/endpoint-fired/submitted）入链。 */
  stampTelemetry(stage: TelemetryStage, at?: number): void
  /** P1-5 开发埋点：打断/退出/让出时清空当前链。 */
  resetTelemetry(): void
  /** P1-2：手势栈内预热播放 AudioContext（Safari 非手势栈新建会 suspended）。 */
  warmAudio(): void
  /** isPlaying 尾音截止墙钟：playing 或回声尾音宽限期内均视为「AI 正在朗读」。 */
  playingTailUntil(): number
}

export interface VoiceSlotActions {
  bus: VoiceBus
}

/** P3-2：回声参考采样率（16k mono，与采集一致）。 */
const SAMPLE_RATE_16K = 16000
/**
 * P3-2：扬声器→麦克风声学路径前导延迟。
 * 修复（耳机自回声）：固定 80ms 预移位使 NLMS 只能消除 >80ms 的长路径回声，
 * 耳机/近距耦合（5-10ms）落在窗口外回声全残留 → 被识别人声自动发送 + 打断误判。
 * 归零后由 NLMS 的 160ms 全窗口自适应学习任意路径延迟（合成模型：2~150ms 全路径一致消除）。
 */
const ECHO_DELAY_MS = 0
/** playing 从 true→false 后的回声尾音宽限（扬声器残响/硬件缓冲仍会被麦克风采到）。
 *  此窗口内 isPlaying 仍判 true，防「句播完瞬间的残响」漏入 ASR → 自聊/多重声音。 */
const ECHO_TAIL_MS = 400
const WAVE_BARS = 14
const SUBMIT_DELAY_MS = 600
/** 插件 HTTP 命名空间（与 host 侧 BASE_PATH 常量一致，固定不可配置）。 */
const BASE_PATH = '/voice-mode'

/** B2：每 tab 稳定唯一 ID（sessionStorage 跨刷新保持、关 tab 清除；host 据此探活 owner）。 */
function getTabId(): string {
  try {
    const KEY = 'dshvm-tabId'
    let id = sessionStorage.getItem(KEY)
    if (!id) {
      id =
        typeof crypto !== 'undefined' && 'randomUUID' in crypto
          ? crypto.randomUUID()
          : Math.random().toString(36).slice(2) + Date.now().toString(36)
      sessionStorage.setItem(KEY, id)
    }
    return id
  } catch {
    return Math.random().toString(36).slice(2) + Date.now().toString(36)
  }
}
/** 本 tab 的稳定标识（模块加载时生成一次）。 */
const TAB_ID = getTabId()

/** 解析快捷键字符串（如 Ctrl+Shift+V）→ 修饰键 + 主键；非法返回 null。 */
function parseShortcut(s: string): { ctrl: boolean; shift: boolean; alt: boolean; meta: boolean; key: string } | null {
  const parts = (s || '').split('+')
  const mods = { ctrl: false, shift: false, alt: false, meta: false }
  let key = ''
  for (const raw of parts) {
    const t = raw.trim().toLowerCase()
    if (t === 'ctrl' || t === 'control') mods.ctrl = true
    else if (t === 'shift') mods.shift = true
    else if (t === 'alt' || t === 'option') mods.alt = true
    else if (t === 'meta' || t === 'cmd' || t === 'command') mods.meta = true
    else if (t.length === 1 && /^[a-z0-9]$/.test(t)) {
      // M9：多主键（Ctrl+A+B）静默覆盖 → 拒绝；单主键且未重复才接受。
      if (key) return null
      key = t
    } else return null
  }
  if (!key) return null
  // M8：要求至少一个修饰键——裸字母（如 v）会被注册为全局快捷键，非编辑态按键即误切。
  if (!mods.ctrl && !mods.shift && !mods.alt && !mods.meta) return null
  return { ...mods, key }
}

/** I5：上次语音会话记忆（localStorage 持久，autoResume 切回时自动恢复）。 */
function getLastVoiceSession(): string | null {
  try {
    return localStorage.getItem('dshvm-last-voice')
  } catch {
    return null
  }
}
function setLastVoiceSession(id: string | null): void {
  try {
    if (id) localStorage.setItem('dshvm-last-voice', id)
    else localStorage.removeItem('dshvm-last-voice')
  } catch {
    // ignore（隐私模式等 localStorage 不可用）
  }
}

export async function apply(ctx: any): Promise<void> {
  try {
    const unmount = await ctx.remote.$mount(TYPERT_REMOTE)
    ctx.effect(() => unmount)
    ctx.inject(['remote.voiceMode'], applyVoiceClient)
  }
  catch (error) {
    console.error('[dsh-voice] 前端插件启动失败：', error)
    throw error
  }
}

function applyVoiceClient(ctx: any): void {
  const bus = createVoiceBus(undefined, ctx)

  // C3 加固：浏览器挂起 AudioContext 后，只有用户交互能可靠恢复播放（Safari/Chrome 的
  // 自动播放策略）。挂一次性手势监听——用户回到标签页点一下/按一下键即恢复朗读，
  // 避免「回到页面后 AI 回复无声、UI 却显示朗读中」。
  if (typeof document !== 'undefined') {
    const resumeAudio = (): void => bus.warmAudio()
    document.addEventListener('pointerdown', resumeAudio, { passive: true })
    document.addEventListener('keydown', resumeAudio, { passive: true })
  }

  ctx.slots.inject('conversation.input.activity', () =>
    ctx.slots.register(
      {
        name: 'conversation.input.activity',
        inject: (): VoiceSlotActions => ({ bus }),
      },
      MicButton,
    ),
  )

  ctx.slots.inject('conversation.input.dock', () =>
    ctx.slots.register(
      {
        name: 'conversation.input.dock',
        id: 'voice-mode-status',
        order: 10,
        inject: (): VoiceSlotActions => ({ bus }),
      },
      VoiceStatusBar,
    ),
  )

  ctx.slots.inject('conversation.session.header.utilities', () =>
    ctx.slots.register(
      { name: 'conversation.session.header.utilities', id: 'voice-mode-read', order: -1,
        inject: (): VoiceSlotActions => ({ bus }) },
      SpeakerButton,
    ),
  )

  ctx.slots.inject('conversation.chat.assistant-actions', () =>
    ctx.slots.register(
      { name: 'conversation.chat.assistant-actions', id: 'voice-mode-read-once', order: 5,
        inject: (): VoiceSlotActions => ({ bus }) },
      ReplySpeakerButton,
    ),
  )

  ctx.slots.inject('conversation.input.dock', () =>
    ctx.slots.register(
      { name: 'conversation.input.dock', id: 'voice-mode-approval', order: 11,
        inject: (): VoiceSlotActions => ({ bus }) },
      ApprovalWatcher,
    ),
  )

  ctx.slots.inject('shell.overlay', () =>
    ctx.slots.register(
      {
        name: 'shell.overlay',
        id: 'voice-mode-overlay',
        order: 100,
        inject: (): VoiceSlotActions => ({ bus }),
      },
      VoiceOverlay,
    ),
  )

  ctx.slots.inject('settings.section', () =>
    ctx.slots.register(
      { name: 'settings.section', id: 'voice-mode', order: 70, label: '语音设置' },
      VoiceServiceSettingsPage,
    ),
  )

  ctx.slots.inject('plugins.item', () =>
    ctx.slots.register(
      { name: 'plugins.item', id: 'voice-mode', order: 70, label: '语音摘要性播报' },
      ({ view }: { view: string }) => view === 'summary'
        ? <>配置自动播报的摘要模型、目标字数和提示词，以及语音识别与合成服务。</>
        : <VoiceServiceSettingsPage />,
    ),
  )
}

/**
 * 播放引擎（P1-2 Web Audio 队列）：句级 decodeAudioData → AudioBufferSourceNode
 * 以 start(max(now+lead, 上一句结束)) 链式调度（音频线程精度，句间缝隙 ≤50ms）；
 * GainNode 预留 ducking 挂点（P3 打断强化用）；decodeAudioData 失败（如极端帧/老
 * Safari）整段降级 <audio> 元素，保顺序播放。P1-5 起播埋点 = 首次调度发声时刻。
 */
function createAudioEngine(
  setUi: (patch: Partial<VoiceUiState>) => void,
  onPlayed?: (frame: PlayFrame) => void,
  onPlaybackRef?: (pcm: Float32Array, sampleRate: number, startWallMs: number) => void,
  /** Fix：全队列播完回调（参考池据此清空，防旧回合参考漂移）。 */
  onAllPlayed?: () => void,
): {
  push(frame: PlayFrame): void
  finish(sessionId: string, seq: number, failed?: boolean): void
  skip(): void
  /** 手势栈内预热 AudioContext（Safari 非手势栈新建会 suspended 静默）。 */
  warm(): void
  /** P3-3：恢复 TTS 增益（≥30ms 斜坡，无爆音；打断后调用）。 */
  unduck(): void
} {
  // --- 待播放：串行解码，decode 完成即调度（句序天然保持）。 ---
  const pending: PlayFrame[] = []
  // <audio> 降级路径（decodeAudioData 失败后整段使用，逻辑与原引擎一致）。
  const fallbackAudio = new Audio()
  let fallback = false
  let fallbackPlaying = false
  let ctx: AudioContext | null = null
  let duckGain: GainNode | null = null
  /** 上一句的调度结束时刻（context.currentTime 对齐；无缝衔接基准）。 */
  let nextEndAt = 0
  /** 当前已 start 的源（skip 时全部 stop）。 */
  const activeSrcs = new Set<AudioBufferSourceNode>()
  let decoding = false
  /** 字幕队列：随真实起播推进（多句连播时字幕不能领先音频一整句）。 */
  const captionQueue: { key: string; text: string }[] = []
  const openStreams = new Set<string>()
  const fallbackPcm = new Map<string, PlayFrame[]>()
  const sourceFrames = new Map<AudioBufferSourceNode, { frame: PlayFrame; endAt: number }>()
  const playbackTimers = new Set<ReturnType<typeof setTimeout>>()
  const announced = new Set<string>()
  const keyOf = (frame: { sessionId: string; seq: number }): string => `${frame.sessionId}:${frame.seq}`
  let streamKey: string | null = null
  const finished = (): void => {
    if (!activeSrcs.size && !pending.length && !openStreams.size && !fallbackPlaying) {
      setUi({ playing: false, playingCaption: null })
      onAllPlayed?.()
    }
  }

  const warm = (): void => {
    if (ctx) {
      void ctx.resume?.()
      return
    }
    try {
      const AC: typeof AudioContext =
        window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      ctx = new AC()
      duckGain = ctx.createGain()
      duckGain.gain.value = 1 // P3 ducking 挂点：打断时降增益、恢复斜坡
      duckGain.connect(ctx.destination)
      void ctx.resume?.()
    } catch {
      ctx = null // warm 失败：后续整段走 <audio> 降级
    }
  }

  const playFallback = (): void => {
    const frame = pending.shift() ?? null
    if (!frame) {
      fallbackPlaying = false
      finished()
      return
    }
    fallbackPlaying = true
    const url = URL.createObjectURL(new Blob([frame.audio], { type: frame.mime === 'audio/wav' ? 'audio/wav' : 'audio/mpeg' }))
    fallbackAudio.src = url
    fallbackAudio.onended = () => {
      URL.revokeObjectURL(url)
      playFallback()
    }
    fallbackAudio.onerror = () => {
      URL.revokeObjectURL(url)
      playFallback()
    }
    fallbackAudio.onplaying = () => {
      try {
        onPlayed?.(frame)
      } catch {
        // 埋点失败不影响播放
      }
      // AEC 参考完整性：降级 <audio> 播放也喂参考池（尽力解码，失败则依赖浏览器原生 AEC）。
      // 缺此路时外放/半开放耳机的 TTS 会被麦克风采到 → 回声被识别成新语音（复述回环）。
      try {
        if (ctx && frame.audio.length) {
          void ctx
            .decodeAudioData(frame.audio.buffer.slice(0))
            .then((buf) => {
              onPlaybackRef?.(buf.getChannelData(0), buf.sampleRate, performance.now())
            })
            .catch(() => {})
        }
      } catch {
        // 忽略：无 ctx（全面降级）时由浏览器原生 echoCancellation 兜底
      }
    }
    setUi({ playing: true, playingCaption: frame.text, ttsNotice: null })
    fixtureRecorder.mark('tts-sentence', frame.text)
    void fallbackAudio.play().catch(() => playFallback())
  }

  /** 解码串行队列：保持句序，decode 完成即无缝调度（音频线程精度）。 */
  const drainPending = (): void => {
    if (decoding || !ctx || !duckGain || pending.length === 0) return
    decoding = true
    void (async () => {
      try {
        while (pending.length > 0) {
          let index = 0
          if (streamKey) {
            index = pending.findIndex(frame => keyOf(frame) === streamKey)
            if (index < 0) {
              if (openStreams.has(streamKey)) return
              streamKey = null
              index = 0
            }
          }
          const frame = pending[index]
          if (frame.encoding) streamKey = keyOf(frame)
          // decodeAudioData 会 transfer 掉传入 buffer；传拷贝以保留原字节供降级路径用。
          let buf: AudioBuffer
          if (frame.encoding === 'pcm-s16le') {
            if (frame.sampleRate !== 24000 || frame.audio.length % 2) throw new Error('PCM 音频格式无效')
            buf = ctx!.createBuffer(1, frame.audio.length / 2, frame.sampleRate)
            const view = new DataView(frame.audio.buffer, frame.audio.byteOffset, frame.audio.byteLength)
            const channel = buf.getChannelData(0)
            for (let i = 0; i < channel.length; i++) channel[i] = view.getInt16(i * 2, true) / 32768
          } else buf = await ctx!.decodeAudioData(frame.audio.buffer.slice(0))
          // skip/打断防护（Q2 真静音）：解码期间框架被清空则放弃播放。
          if (pending.indexOf(frame) < 0) return
          pending.splice(pending.indexOf(frame), 1)
          const t0 = ctx!.currentTime
          const at = Math.max(t0 + 0.02, nextEndAt)
          const src = ctx!.createBufferSource()
          src.buffer = buf
          src.connect(duckGain!)
          activeSrcs.add(src)
          sourceFrames.set(src, { frame, endAt: at + buf.duration })
          src.onended = () => {
            if (!activeSrcs.delete(src)) return
            sourceFrames.delete(src)
            const key = keyOf(frame)
            if (!openStreams.has(key) && ![...sourceFrames.values()].some(item => keyOf(item.frame) === key)) announced.delete(key)
            // 字幕随真实起播推进：本句播完才切下一句（调度时刻不写，否则领先一整句）。
            captionQueue.shift()
            // 全队列播完才收门面状态（以在播源数为准：多句连播时 pending 会先空）。
            if (captionQueue.length > 0) setUi({ playingCaption: captionQueue[0].text })
            finished()
          }
          src.start(at)
          nextEndAt = at + buf.duration
          // P3-2：把播放 PCM（decodeAudioData 输出的 buffer 采样率）+ 调度墙钟
          // 回传给回声参考池（采集侧经 windowAt 对齐取参考，前导 ECHO_DELAY_MS）。
          try {
            // L2：参考时间戳补 AudioContext outputLatency——声音实际出 DAC 在 at+outputLatency，
            // 之前只记 at 导致参考比回声早一拍（delay 估计常失败 → 0）。确定性对齐，
            // 不依赖混合信号上的互相关。
            const outLat = ctx!.outputLatency ?? 0
            const wallMs = performance.now() + (at + outLat - ctx!.currentTime) * 1000
            onPlaybackRef?.(buf.getChannelData(0), buf.sampleRate, wallMs)
          } catch {
            // 参考捕获失败不影响播放
          }
          const key = keyOf(frame)
          const announce = (): void => {
            if (!activeSrcs.has(src)) return
            const delay = (at + (ctx!.outputLatency ?? 0) - ctx!.currentTime) * 1000
            if (ctx!.state !== 'running' || delay > 1) {
              const timer = setTimeout(() => { playbackTimers.delete(timer); announce() }, ctx!.state === 'running' ? Math.max(1, delay) : 100)
              playbackTimers.add(timer)
              return
            }
            if (!announced.has(key)) {
              announced.add(key)
              try { onPlayed?.(frame) } catch { /* 埋点不影响播放。 */ }
              fixtureRecorder.mark('tts-sentence', frame.text)
            }
          }
          announce()
          captionQueue.push({ key, text: frame.text })
          setUi({ playing: true, playingCaption: captionQueue[0].text, ttsNotice: null })
        }
      } catch {
        // 解码失败：停掉 Web Audio 在途源（避免与 <audio> 混播），整段降级（保句序）。
        for (const src of activeSrcs) {
          try {
            src.stop()
          } catch {
            // ignore
          }
        }
        activeSrcs.clear()
        sourceFrames.clear()
        captionQueue.length = 0
        fallback = true
        playFallback()
      } finally {
        decoding = false
      }
    })()
  }

  return {
    push(frame) {
      // C3 静默播放根治：浏览器会在后台标签页/长时间静音后挂起 AudioContext——此时播放
      // 被正常调度但**无声**（UI 仍显示「朗读中」、字幕照走），真机表现为「AI 回复偶尔
      // 不朗读」。每次入队先尝试 resume（用户已与页面交互过，粘性激活下可即时生效）。
      warm()
      if (frame.encoding) openStreams.add(keyOf(frame))
      if (fallback || !ctx) {
        if (frame.encoding) {
          const key = keyOf(frame)
          const chunks = fallbackPcm.get(key) ?? []
          chunks.push(frame)
          fallbackPcm.set(key, chunks)
          return
        }
        pending.push(frame)
        // 已在播则等 onended/onerror 链续播（与原引擎 paused 守卫同语义）。
        if (fallbackAudio.paused) playFallback()
        return
      }
      pending.push(frame)
      drainPending()
    },
    finish(sessionId, seq, failed = false) {
      const key = keyOf({ sessionId, seq })
      openStreams.delete(key)
      const chunks = fallbackPcm.get(key)
      fallbackPcm.delete(key)
      if (failed) {
        for (let i = pending.length - 1; i >= 0; i--) if (keyOf(pending[i]) === key) pending.splice(i, 1)
        for (const [src, item] of sourceFrames) if (keyOf(item.frame) === key) {
          activeSrcs.delete(src)
          sourceFrames.delete(src)
          try { src.stop() } catch { /* 已结束。 */ }
        }
        for (let i = captionQueue.length - 1; i >= 0; i--) if (captionQueue[i].key === key) captionQueue.splice(i, 1)
        nextEndAt = Math.max(ctx?.currentTime ?? 0, ...[...sourceFrames.values()].map(item => item.endAt))
      } else if (chunks?.length) {
        const size = chunks.reduce((sum, frame) => sum + frame.audio.length, 0)
        const wav = new Uint8Array(44 + size)
        const view = new DataView(wav.buffer)
        for (const [offset, value] of [[0, 'RIFF'], [8, 'WAVEfmt '], [36, 'data']] as const) for (let i = 0; i < value.length; i++) wav[offset + i] = value.charCodeAt(i)
        view.setUint32(4, 36 + size, true); view.setUint32(16, 16, true)
        view.setUint16(20, 1, true); view.setUint16(22, 1, true)
        view.setUint32(24, 24000, true); view.setUint32(28, 48000, true)
        view.setUint16(32, 2, true); view.setUint16(34, 16, true); view.setUint32(40, size, true)
        let offset = 44
        for (const frame of chunks) { wav.set(frame.audio, offset); offset += frame.audio.length }
        pending.push({ ...chunks[0], encoding: undefined, audio: wav, mime: 'audio/wav' })
        if (fallbackAudio.paused) playFallback()
      }
      if (![...sourceFrames.values()].some(item => keyOf(item.frame) === key) && !pending.some(frame => keyOf(frame) === key)) announced.delete(key)
      drainPending()
      finished()
    },
    skip() {
      pending.length = 0
      streamKey = null
      openStreams.clear()
      fallbackPcm.clear()
      announced.clear()
      sourceFrames.clear()
      for (const timer of playbackTimers) clearTimeout(timer)
      playbackTimers.clear()
      nextEndAt = 0 // P1-2/I1：打断后清调度基准，下句从 now 起播（防空窗）
      fallbackPlaying = false
      fallbackAudio.pause()
      fallbackAudio.onended = null
      fallbackAudio.onerror = null
      for (const src of activeSrcs) {
        try {
          src.stop()
        } catch {
          // ignore
        }
      }
      activeSrcs.clear()
      captionQueue.length = 0
      setUi({ playing: false, playingCaption: null })
    },
    warm,
    unduck() {
      if (!ctx || !duckGain) return
      const now = ctx.currentTime
      duckGain.gain.cancelScheduledValues(now)
      duckGain.gain.setTargetAtTime(1, now, 0.035) // ≥30ms 斜坡恢复，无爆音
    },
  }
}

function createVoiceBus(basePath: string = BASE_PATH, ctx?: any): VoiceBus {
  let activeSessionId: string | null = null
  const DEFAULT_BOOT: VoiceBootConfig = {
    basePath: BASE_PATH,
    silenceMs: 1500,
    interruptLevel: 0,
    idleTimeoutMinutes: 5,
    autoSend: false,
    autoResume: false,
    mode: 'toggle',
    // 批 7O（ADR-0006）：默认 detect（与 src/index.ts VOICE_SETTINGS_DEFAULTS 对齐）。
    bargeInMode: 'detect',
    echoGateDb: 6,
    shortcut: 'Ctrl+Shift+V',
    wakeWord: '',
    alwaysListen: false,
    sendCommands: [...DEFAULT_SEND_COMMANDS],
    toolBeep: false,
    captionFontSize: 0,
    captionMaxWidth: 1,
    backchannelYield: true,
    yieldMs: 1500,
    // 批 B：5 ASR 字段默认值，与 src/index.ts VOICE_SETTINGS_DEFAULTS 对齐（plan §12 批 B 周全修复）。
    senseITN: true,
    senseVoice: true,
  }
  const ui: VoiceUiState = {
    state: 'idle',
    partial: '',
    levels: [],
    botLevels: [],
    error: null,
    playingCaption: null,
    playing: false,
    model: null,
    ttsNotice: null,
    boot: DEFAULT_BOOT,
    mode: 'toggle',
    telemetry: null,
    turn: 'idle',
    wakeWord: '',
    wakeStatus: 'off',
    readSessionId: null,
    manualReadSessionId: null,
    manualReadMessageId: null,
    visibleSessionId: null,
    // 批 H 任务 4：autoResume 引导提示（一次会话内一次）。
    notice: null,
  }
  const summaryReceivedAt = new Map<string, number>()
  const minimumEpoch = new Map<string, number>()
  const listeners = new Set<(b: { active: string | null; ui: VoiceUiState }) => void>()
  const audioListeners = new Set<(frame: TtsChunkFrame) => void>()
  let manualSynthesisDone = false
  let manualAudioSeen = false
  let manualPlaybackEnded = false
  /** playing 从 true→false 的墙钟时刻（回声尾音宽限起点，见 ECHO_TAIL_MS）。 */
  let playingEndAt = 0
  /** 批 5 / ADR-0008 Phase 1：backchannel 让位窗口截止时间戳（ms）。
   *  onBackchannel 触发时 setBackchannelHold(now + 1500)；hold 期间 TTS 帧在 audioListeners 回调内丢弃（字幕同帧丢）；
   *  hardBreak 路径清 0（真打断优先）；hold 到期后正常播放恢复。 */
  let backchannelHoldUntil = 0

  // --- P1-5 延迟埋点链（开发模式）：一轮「说完→首音」的时间戳收拢。 ---
  const telemetryStages: Partial<Record<TelemetryStage, number>> = {}
  const stampTelemetry = (stage: TelemetryStage, at?: number): void => {
    if (!telemetryEnabled) return
    if (stage === 'utterance-end') {
      // 新一轮语音：上一轮的链作废（打断/连续多句均重新起算）。
      for (const k of Object.keys(telemetryStages)) delete telemetryStages[k as TelemetryStage]
    }
    if (telemetryStages[stage] === undefined) {
      telemetryStages[stage] = at ?? Date.now()
      ui.telemetry = { ...telemetryStages }
      notify()
    }
  }
  const resetTelemetry = (): void => {
    if (!telemetryEnabled) return
    for (const k of Object.keys(telemetryStages)) delete telemetryStages[k as TelemetryStage]
    ui.telemetry = null
    ui.interruptConfirmMs = undefined
    notify()
  }

  // --- P3-2 回声参考池（16k mono）：播放引擎回传 PCM + 调度墙钟，
  // 采集侧按墙钟（减 ECHO_DELAY_MS 前导）取对应对齐的 TTS 参考做 NLMS。 ---
  const refChunks: Float32Array[] = []
  let refTotal = 0
  let refStartWall = 0
  let refActive = false
  // P0-UX 双条 SVG 波形：AI 朗读端 PCM 推 robotLevels (WAVE_BARS 元素)
  // 解码后的 PCM 是 Float32Array(单声道);对每 16ms 帧(256 样本 @ 16kHz)算 RMS,推入 botLevels 环形
  const pushBotLevels = (pcmSrc: Float32Array, srcRate: number): void => {
    // 重采样到 16k(参考采样率)便于帧对齐;若原已 16k 则等价
    const pcm = srcRate === SAMPLE_RATE_16K ? pcmSrc : resampleLinear(pcmSrc, srcRate, SAMPLE_RATE_16K)
    const FRAME = 256 // ~16ms @ 16kHz
    const total = Math.floor(pcm.length / FRAME)
    if (total === 0) return
    const start = Math.max(0, WAVE_BARS - total) // 滑窗到末尾
    const merged = ui.botLevels.slice(0, start)
    for (let i = 0; i < total; i++) {
      let s = 0
      for (let j = 0; j < FRAME; j++) s += pcm[i * FRAME + j] * pcm[i * FRAME + j]
      const rms = Math.sqrt(s / FRAME) / 0.25 // 归一到 [0, 1];与 asr.ts:110 LEVEL_CEILING 同值
      merged.push(Math.max(0, Math.min(1, rms)))
    }
    Object.assign(ui, { botLevels: merged })
    notify()
  }
  const pushRef = (pcmSrc: Float32Array, srcRate: number, startWallMs: number): void => {
    const pcm = resampleLinear(pcmSrc, srcRate, SAMPLE_RATE_16K)
    if (!refActive) {
      refActive = true
      refStartWall = startWallMs
      refChunks.length = 0
      refTotal = 0
    }
    const tailWall = refStartWall + (refTotal / SAMPLE_RATE_16K) * 1000
    const gapMs = startWallMs - tailWall
    if (gapMs > 250) {
      // I1：播放间断（打断/句间隙 >250ms）→ 重置为「新回合」，缺口即静音。
      // 修复：必须更新 refStartWall 并保持 refActive=true，当前块作为新回合首块入库。
      // 原实现设 refActive=false，导致 refWindowAt 返回零数组（AEC 透传，回声不消除），
      // 且下一个 pushRef 又清掉刚入库的首块——句间隙后新句回声完全漏入 → 自聊。
      refChunks.length = 0
      refTotal = 0
      refStartWall = startWallMs
    } else if (gapMs > 1) {
      const padN = Math.floor((gapMs / 1000) * SAMPLE_RATE_16K)
      refChunks.push(new Float32Array(padN))
      refTotal += padN
    }
    refChunks.push(pcm)
    refTotal += pcm.length
    // 上限滚动（防无界累积）：保留最近 60s。
    const maxTotal = SAMPLE_RATE_16K * 60
    while (refTotal - (refChunks[0]?.length ?? 0) > maxTotal) {
      refTotal -= refChunks.shift()!.length
    }
  }
  const refWindowAt = (tWallMs: number, n: number): Float32Array => {
    const out = new Float32Array(n)
    if (!refActive || refTotal === 0) return out
    const idx = Math.floor((((tWallMs - ECHO_DELAY_MS) - refStartWall) / 1000) * SAMPLE_RATE_16K)
    if (idx < 0 || idx >= refTotal) return out
    let acc = 0
    let outOff = 0
    for (const c of refChunks) {
      if (outOff >= n) break
      if (idx >= acc + c.length) {
        acc += c.length
        continue
      }
      const start = Math.max(0, idx - acc)
      const cnt = Math.min(c.length - start, n - outOff)
      out.set(c.subarray(start, start + cnt), outOff)
      outOff += cnt
      acc += c.length
    }
    return out
  }
  // A2：bulk delay 估计 + 参考平移 + 短滤波器（1024 taps=64ms）。
  // 8192 taps 靠长滤波器自行建模 bulk delay，收敛极慢（0~300ms 几乎不消回声）；
  // 先用 estimateBulkDelay 量出 bulk delay（互相关），把参考平移 D 样本后再交给短滤波器
  // 只建模残余房间冲激响应——早期 ERLE 从 0dB 提到 ~11dB（打断确认窗关键）。
  const aec = new NlmsAec({ filterLength: 1024, delay: 0 })
  /** A2：估计出的 bulk delay（样本，指数平滑）。 */
  let refDelaySamples = 0
  /** A2：估计用历史（raw ref 与 mic，各 ~1s；周期估计后清空）。 */
  let estMic: number[] = []
  let estRef: number[] = []
  const EST_CAP = SAMPLE_RATE_16K // 1s
  let lastEstimateAt = 0

  /** 原生 AEC 生效 → 旁路自研 NLMS（实测：原生已把 resid 消到 0.0016，自研 delay=0
   *  错位减法反而制造 0.11 瞬态尖峰导致自打断）。原生 AEC 未生效时才走自研 NLMS。 */
  let echoBypass = false
  const echoSource: EchoRefSource = {
    process: (mic, ref) => {
      if (echoBypass) return mic
      const now = performance.now()
      // 对抗审查 Important#2：仅播放期累积估计历史——非播放期 mic=人声、ref=静音，
      // 相关无意义，会把已收敛的 delay 拉偏/清空（每句回复前 2s 失去参考平移）。
      if (ui.playing) {
        for (let i = 0; i < mic.length; i++) estMic.push(mic[i])
        for (let i = 0; i < ref.length; i++) estRef.push(ref[i])
        if (estMic.length > EST_CAP) {
          const drop = estMic.length - EST_CAP
          estMic.splice(0, drop)
          estRef.splice(0, drop)
        }
        // 周期估计 bulk delay（每 2s；需 ≥0.5s 历史）。
        if (now - lastEstimateAt > 2000 && estMic.length > SAMPLE_RATE_16K * 0.5) {
          lastEstimateAt = now
          const est = estimateBulkDelay(
            Float32Array.from(estMic),
            Float32Array.from(estRef),
            { sampleRate: SAMPLE_RATE_16K, maxLag: Math.floor(0.25 * SAMPLE_RATE_16K) },
          )
          // 置信门控（peak>0.5 才采信）+ 指数平滑（防跳变）。
          // 低置信保留上次值：声学路径会话内稳定，清零会让后续播放失去参考平移；
          // 新路径会由下一次高置信估计覆盖。
          if (est.peak > 0.5) {
            refDelaySamples = refDelaySamples === 0 ? est.lag : Math.round(refDelaySamples * 0.8 + est.lag * 0.2)
          }
          estMic.length = 0
          estRef.length = 0
        }
      }
      // 平移参考（从 refChunks 取 D 样本前的原始参考）。
      let refForAec = ref
      if (refDelaySamples > 0 && refActive && refTotal > refDelaySamples) {
        const shiftMs = (refDelaySamples / SAMPLE_RATE_16K) * 1000
        refForAec = refWindowAt(now - shiftMs, ref.length)
      }
      return aec.process(mic, refForAec)
    },
    windowAt: refWindowAt,
    // A2.5 双讲冻结：用户说话时暂停 NLMS 自适应。
    setFrozen: (frozen) => aec.setFrozen(frozen),
  }

  // 播放引擎与 bus 的生命周期相同（apply 闭包单例）；setUi 闭包延迟解引用，
  // 事件回调触发时 notify 已就绪。onPlayed = P1-5 真实起播埋点；
  // onPlaybackRef = P3-2 回声参考回传。
  const engine = createAudioEngine(
    (patch) => {
      Object.assign(ui, patch)
      notify()
    },
    (frame) => {
      stampTelemetry('first-audio-played')
      if (frame.sourceMessageId) {
        const receivedAt = summaryReceivedAt.get(frame.sourceMessageId)
        debugLog('summary-audio-played', { sourceMessageId: frame.sourceMessageId,
          summaryToAudioMs: receivedAt === undefined ? null : performance.now() - receivedAt })
        summaryReceivedAt.delete(frame.sourceMessageId)
      }
    },
    (pcm, sampleRate, wallMs) => {
      pushRef(pcm, sampleRate, wallMs)
      // P0-UX 双条 SVG 波形:同时算 RMS 推 botLevels(独立于回声参考池)
      pushBotLevels(pcm, sampleRate)
    },
    // Fix：自然播完（无 TTS 在播）即清参考池——AEC 不再拿旧回合参考适配新语音。
    () => {
      refActive = false
      refChunks.length = 0
      refTotal = 0
      manualPlaybackEnded = true
      if (manualSynthesisDone && ui.manualReadMessageId) {
        ui.manualReadSessionId = null
        ui.manualReadMessageId = null
        notify()
      }
    },
  )

  const notify = (): void => {
    for (const fn of listeners) {
      try {
        fn({ active: activeSessionId, ui: { ...ui, levels: [...ui.levels], botLevels: [...ui.botLevels] } })
      } catch {
        // listener errors must not kill the loop
      }
    }
  }

  const clearManualRead = (): void => {
    ui.manualReadSessionId = null
    ui.manualReadMessageId = null
    manualSynthesisDone = false
    manualAudioSeen = false
    manualPlaybackEnded = false
    notify()
  }

  const handleVoiceEvent = (frame: VoiceEvent): void => {
    if (frame.type === 'speech-summary') {
      if (frame.targetTabId !== TAB_ID || (frame.sessionId !== activeSessionId && frame.sessionId !== ui.readSessionId)) return
      ui.playingCaption = frame.text
      ui.ttsNotice = null
      summaryReceivedAt.set(frame.sourceMessageId, performance.now())
      debugLog('speech-summary', { sourceMessageId: frame.sourceMessageId, generationMs: frame.generationMs,
        queueWaitMs: frame.queueWaitMs, reasoningMode: frame.reasoningMode, reasoningEffort: frame.reasoningEffort,
        reasoningObserved: frame.reasoningObserved, reasoningTokens: frame.reasoningTokens, firstTextMs: frame.firstTextMs })
      notify()
      return
    }
    switch (frame.event) {
      case 'mode': {
      try {
        const data = frame.data as { active?: string | null; ownerTabId?: string | null }
        const active = data.active ?? null
        const ownerTabId = data.ownerTabId ?? null
        // B1 修复：activeSessionId 语义 = 「本 tab 正在跑的语音会话」（owner），只在本地
        // enter/exit 设置，绝不从全局 mode 广播「收养」——否则多 tab 每个 tab 都把
        // activeSessionId 同步成同一值，同一句 TTS 在 N 个 tab 叠加播放、字幕浮层重复。
        // 此处仅做「被抢占」检测：我是 owner 且（全局 active 已切走 或 owner tab 已换成
        // 别的 tab）→ 让出。ownerTabId 判定补上「同会话双 tab」场景（对抗审查 I1：
        // active 不变时旧 owner 无法从 active 字段感知被接管，会双播 + 双麦克风）。
        const preempted =
          active !== activeSessionId || (ownerTabId !== null && activeSessionId !== null && ownerTabId !== TAB_ID)
        if (activeSessionId !== null && preempted) {
          const prev = activeSessionId
          activeSessionId = null
          // 模式被让出/抢占：本地播放立即静音（Q2 之停 TTS）。
          // 双重奏根治：无条件 doSkipAudio(prev)——停播 + 清拼帧缓冲（防 prev 未 final
          // 的缓冲句与新会话同序号句混帧）+ 对 prev 设拒绝线（activeSessionId 已切走）。
          if (ui.turn !== 'idle') ui.turn = 'idle' // P2-4：让出复位回合状态
          if (ui.manualReadSessionId !== prev) doSkipAudio(prev)
          // P1-5：跨会话让出/抢占时清空未完成的埋点链。
          resetTelemetry()
          notify()
        }
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'audio': {
      try {
        const audioFrame = frame.data as unknown as TtsChunkFrame
        audioFrame.sessionId = audioFrame.sessionId ?? ''
        for (const fn of audioListeners) {
          try {
            fn(audioFrame)
          } catch {
            // ignore
          }
        }
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'read-mode': {
      try {
        const data = frame.data as { sessionId?: string | null; tabId?: string | null }
        const next = data.tabId === TAB_ID ? data.sessionId ?? null : null
        if (ui.readSessionId && ui.readSessionId !== next && activeSessionId !== ui.readSessionId && ui.manualReadSessionId !== ui.readSessionId) doSkipAudio(ui.readSessionId)
        ui.readSessionId = next
        notify()
      } catch { /* malformed event */ }
    
        break
      }
      case 'read-once-start': {
      try {
        const p = frame.data as { sessionId: string; messageId: string; tabId: string }
        if (p.tabId !== TAB_ID) return
        doSkipAudio(p.sessionId)
        ui.manualReadSessionId = p.sessionId
        ui.manualReadMessageId = p.messageId
        backchannelHoldUntil = 0
        manualSynthesisDone = false
        manualAudioSeen = false
        manualPlaybackEnded = false
        notify()
      } catch { /* malformed event */ }
    
        break
      }
      case 'read-once-complete': {
      try {
        const p = frame.data as { sessionId: string; messageId: string; tabId: string }
        if (p.tabId !== TAB_ID || ui.manualReadSessionId !== p.sessionId || ui.manualReadMessageId !== p.messageId) return
        manualSynthesisDone = true
        if (!manualAudioSeen || manualPlaybackEnded) clearManualRead()
      } catch { /* malformed event */ }
    
        break
      }
      case 'read-once-stop': {
      try {
        const p = frame.data as { sessionId: string; messageId: string; tabId: string }
        if (p.tabId !== TAB_ID || ui.manualReadSessionId !== p.sessionId || ui.manualReadMessageId !== p.messageId) return
        doSkipAudio(p.sessionId)
        clearManualRead()
      } catch { /* malformed event */ }
    
        break
      }
      case 'turn': {
      try {
        const ev = frame.data as { sessionId?: string; state?: VoiceUiState['turn'] }
        if (ev.sessionId === activeSessionId && ev.state) {
          ui.turn = ev.state
          notify()
        }
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'latency': {
      try {
        const ev = frame.data as { sessionId?: string; stage?: string }
        if (ev.sessionId === activeSessionId || ev.sessionId === ui.readSessionId) {
          if (ev.stage === 'summary-source') debugLog('summary-source', frame.data)
          else if (TELEMETRY_VIEW.some(item => item.stage === ev.stage)) stampTelemetry(ev.stage as TelemetryStage)
        }
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'asr-progress': {
      try {
        const p = frame.data as { file?: string; percent?: number }
        ui.model = { file: p.file ?? '', percent: p.percent ?? 0 }
        notify()
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'asr-ready': {
      if (ui.model) {
        ui.model = null
        notify()
      }
    
        break
      }
      case 'asr-error': {
      try {
        const p = frame.data as { file?: string }
        ui.error = t('modelDownloadFail').replace('{file}', p.file ?? '')
        ui.model = null
        notify()
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'asr-service-warning': {
      try {
        const data = frame.data as { message?: string }
        ui.error = '实时识别服务暂不可用，停顿后将使用批量转写。'
        debugLog('asr-service-warning', { detail: data.message ?? '' })
        notify()
      } catch { /* malformed event */ }
    
        break
      }
      case 'asr-service-restored': {
      if (ui.error?.startsWith('实时识别服务暂不可用') || ui.error?.startsWith('语音识别服务不可用')) {
        ui.error = null
        notify()
      }
    
        break
      }
      case 'asr-service-error': {
      try {
        const data = frame.data as { message?: string }
        ui.error = '语音识别服务不可用，请检查流式与批量识别地址后重试。草稿已保留。'
        debugLog('asr-service-error', { detail: data.message ?? '' })
        notify()
      } catch { /* malformed event */ }
    
        break
      }
      case 'tts-skip': {
      try {
        const p = frame.data as { sessionId?: string; text?: string }
        if (p.sessionId !== activeSessionId && p.sessionId !== ui.readSessionId && p.sessionId !== ui.visibleSessionId) return
        ui.ttsNotice = t('ttsSkipNotice')
        notify()
        debugLog('tts-skip', { text: (p.text ?? '').slice(0, 40) })
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'tts-error': {
      try {
        const p = frame.data as { sessionId?: string }
        if (p.sessionId === activeSessionId || p.sessionId === ui.readSessionId || p.sessionId === ui.visibleSessionId) {
          // 批 H 任务 1：TTS 失败时除状态条 ttsNotice 持续提示，再弹一次 3s error toast
          // （与 idleTimeoutQuit 共用模式：3 秒后清，且仅清与本提示相同的 error，避免冲掉用户输入
          // 中或别的并发错误）。ttsNotice 保留直到下次成功播音。
          const failMsg = t('ttsNoticeFail')
          ui.ttsNotice = failMsg
          ui.error = failMsg
          notify()
          setTimeout(() => {
            if (ui.error === failMsg) {
              ui.error = null
              notify()
            }
          }, 3000)
        }
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'tool': {
      try {
        const p = frame.data as { sessionId?: string }
        if (p.sessionId === activeSessionId && ui.boot.toolBeep === true) playToolBeep()
      } catch {
        // ignore malformed frame
      }
    
        break
      }
      case 'summary-error': {
        const data = frame.data as { sessionId: string; targetTabId: string; reason?: string }
        if (data.targetTabId === TAB_ID && (data.sessionId === activeSessionId || data.sessionId === ui.readSessionId)) {
          ui.ttsNotice = data.reason?.includes('超时') ? '摘要生成或排队超时，本次播报已跳过。' : '摘要生成失败，本次播报已跳过。'
          notify()
        }
        break
      }
      case 'speech-reset': {
        const data = frame.data as { sessionId: string; epoch?: number }
        if (data.epoch !== undefined) minimumEpoch.set(data.sessionId, data.epoch)
        if (data.sessionId === activeSessionId || data.sessionId === ui.readSessionId || data.sessionId === ui.manualReadSessionId || data.sessionId === ui.visibleSessionId) doSkipAudio(data.sessionId)
        break
      }
    }
  }
  queueMicrotask(() => {
    const stream = ctx.remote.$stream({
      name: 'voice summary and audio',
      open: (signal: AbortSignal) => {
        rejectSeqUpTo.clear()
        lastFinalSeq.clear()
        minimumEpoch.clear()
        frameBuffers.clear()
        return ctx.remote.voiceMode.follow(TAB_ID, signal)
      },
      ended: () => new Error('语音事件流已结束'),
      carrierFailed: () => {
        for (const sid of new Set([activeSessionId, ui.readSessionId, ui.manualReadSessionId])) if (sid) doSkipAudio(sid)
        ui.ttsNotice = '语音连接已断开，在途播报已取消。'
        notify()
      },
    })
    ctx.effect(() => () => stream.dispose())
    void (async () => {
      for await (const frame of stream) { handleVoiceEvent(frame.value); frame.accept() }
    })().catch((error) => { console.error('[dsh-voice] 语音订阅失败：', error); ui.ttsNotice = '语音连接不可用，请重新启用插件。'; notify() })
  })
  // 每会话独立校验分块；PCM 即收即播，MP3/WAV 保持整句解码。
  const rejectSeqUpTo = new Map<string, number>()
  const lastFinalSeq = new Map<string, number>()
  const frameBuffers = new Map<string, { sentenceId: number; epoch?: number; chunks: Uint8Array[]; bytes: number; count: number; pcm: boolean }>()
  audioListeners.add((frame) => {
    if (frame.targetTabId !== TAB_ID || (frame.sessionId !== activeSessionId && frame.sessionId !== ui.readSessionId && frame.sessionId !== ui.visibleSessionId && frame.sessionId !== ui.manualReadSessionId)) return
    if (frame.epoch !== undefined) {
      const minimum = minimumEpoch.get(frame.sessionId) ?? -1
      if (frame.epoch < minimum) return
      if (frame.epoch > minimum) {
        minimumEpoch.set(frame.sessionId, frame.epoch)
        rejectSeqUpTo.delete(frame.sessionId)
        lastFinalSeq.delete(frame.sessionId)
        frameBuffers.delete(frame.sessionId)
      }
    }
    const rejectLine = rejectSeqUpTo.get(frame.sessionId)
    if (rejectLine !== undefined && frame.sentenceId <= rejectLine) return
    // 让位按完整句边界解除，不能按任意两个 PCM 网络分块解除。
    if (backchannelHoldUntil && Date.now() < backchannelHoldUntil) {
      if (frame.final) backchannelHoldUntil = 0
      return
    }
    stampTelemetry('first-tts-chunk')
    if (frame.chunkId === 0) debugLog('summary-first-audio-chunk', { sourceMessageId: frame.sourceMessageId,
      queueWaitMs: frame.queueWaitMs, firstAudioMs: frame.firstAudioMs })
    let buffer = frameBuffers.get(frame.sessionId)
    if (!buffer || buffer.sentenceId !== frame.sentenceId || buffer.epoch !== frame.epoch) {
      buffer = { sentenceId: frame.sentenceId, epoch: frame.epoch, chunks: [], bytes: 0, count: 0, pcm: false }
      frameBuffers.set(frame.sessionId, buffer)
    }
    const drop = (): void => {
      engine.finish(frame.sessionId, frame.sentenceId, true)
      frameBuffers.delete(frame.sessionId)
      rejectSeqUpTo.set(frame.sessionId, Math.max(rejectSeqUpTo.get(frame.sessionId) ?? -1, frame.sentenceId))
      debugLog('tts-drop-sentence', { sessionId: frame.sessionId, sentenceId: frame.sentenceId, got: frame.chunkId, have: buffer!.count })
    }
    if (frame.failed || frame.chunkId !== buffer.count) { drop(); return }
    if (frame.final) {
      frameBuffers.delete(frame.sessionId)
      lastFinalSeq.set(frame.sessionId, frame.sentenceId)
      if (buffer.pcm) { engine.finish(frame.sessionId, frame.sentenceId); return }
      const audio = new Uint8Array(buffer.bytes)
      let offset = 0
      for (const chunk of buffer.chunks) { audio.set(chunk, offset); offset += chunk.length }
      const isMp3 = audio[0] === 0xff
      const isWav = audio.length >= 4 && audio[0] === 0x52 && audio[1] === 0x49 && audio[2] === 0x46 && audio[3] === 0x46
      if (!isMp3 && !isWav) return
      if (ui.manualReadSessionId === frame.sessionId) { manualAudioSeen = true; manualPlaybackEnded = false }
      engine.push({ sessionId: frame.sessionId, seq: frame.sentenceId, text: frame.text ?? '', audio, mime: frame.mime,
        sourceMessageId: frame.sourceMessageId })
      return
    }
    let bytes: Uint8Array<ArrayBuffer>
    try {
      const bin = atob(frame.audio)
      bytes = Uint8Array.from(bin, value => value.charCodeAt(0))
    } catch { drop(); return }
    const pcm = frame.encoding === 'pcm-s16le'
    if (buffer.count && buffer.pcm !== pcm) { drop(); return }
    if (pcm) {
      if (frame.sampleRate !== 24000 || !bytes.length || bytes.length % 2) { drop(); return }
      buffer.pcm = true
      if (ui.manualReadSessionId === frame.sessionId) { manualAudioSeen = true; manualPlaybackEnded = false }
      engine.push({ sessionId: frame.sessionId, seq: frame.sentenceId, text: frame.text ?? '', audio: bytes,
        encoding: frame.encoding, sampleRate: frame.sampleRate, sourceMessageId: frame.sourceMessageId })
    } else {
      buffer.chunks.push(bytes)
      buffer.bytes += bytes.length
    }
    buffer.count++
  })

  /** 双重奏根治：停播 + 记拒绝线（skip 时在途/已入队句的最大 sentenceId，其后 ≤ 线帧丢弃）。
   *  sidArg：模式让出/抢占时传被让出会话 id（此时 activeSessionId 已切到新会话）。 */
  const doSkipAudio = (sidArg?: string | null): void => {
    const sid = sidArg ?? activeSessionId
    if (sid) {
      rejectSeqUpTo.set(sid, Math.max(lastFinalSeq.get(sid) ?? -1, frameBuffers.get(sid)?.sentenceId ?? -1))
    }
    if (sid) frameBuffers.delete(sid)
    summaryReceivedAt.clear()
    // P3-2：打断即播放停——回声参考归零（防旧回合参考污染）。
    refActive = false
    refChunks.length = 0
    refTotal = 0
    engine.skip()
    // skip 是硬停（stop/pause 立即静音），无自然播完的残响——清除 ECHO_TAIL 宽限起点，
    // 否则 skip 后 400ms 内开口的 VAD 入段会被 isPlaying 误拦（丢首 400ms 语音）。
    playingEndAt = 0
  }

  return {
    get activeSessionId() {
      return activeSessionId
    },
    ui,
    setVisibleSession(sessionId) {
      const previous = ui.visibleSessionId
      if (previous && previous !== sessionId) {
        doSkipAudio(previous)
        if (activeSessionId === previous) void this.exit(previous)
        if (ui.readSessionId === previous) {
          ui.readSessionId = null
          void this.setRead(previous, false)
        }
        if (ui.manualReadSessionId === previous && ui.manualReadMessageId) {
          void this.readOnce(previous, ui.manualReadMessageId, false)
        }
      }
      ui.visibleSessionId = sessionId
      notify()
    },
    async setRead(sessionId, on) {
      try {
        const res = await fetch(new URL(`${basePath.slice(1)}/read-toggle`, document.baseURI), {
          method: 'POST', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ sessionId, on, tabId: TAB_ID }),
        })
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const data = await res.json() as { sessionId?: string | null; tabId?: string | null }
        ui.readSessionId = data.tabId === TAB_ID ? data.sessionId ?? null : null
        notify()
        return ui.readSessionId === sessionId
      } catch (error) {
        ui.error = '自动播报切换失败，请检查插件服务后重试。'
        debugLog('read-toggle-error', { detail: String(error) })
        notify()
        return false
      }
    },
    async readOnce(sessionId, messageId, on) {
      try {
        const res = await fetch(new URL(`${basePath.slice(1)}/read-once`, document.baseURI), {
          method: 'POST', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ sessionId, messageId, tabId: TAB_ID, on }),
        })
        if (!res.ok) {
          const data = await res.json().catch(() => ({})) as { error?: string }
          throw new Error(data.error ?? `HTTP ${res.status}`)
        }
        return true
      } catch (error) {
        ui.error = `朗读这条回复失败：${error instanceof Error ? error.message : '请检查语音服务'}`
        notify()
        return false
      }
    },
    subscribe(fn) {
      listeners.add(fn)
      fn({ active: activeSessionId, ui: { ...ui, levels: [...ui.levels] } })
      return () => {
        listeners.delete(fn)
      }
    },
    setUi(patch) {
      // 记录 playing 降沿（true→false），供 isPlaying 回声尾音宽限判定。
      if (patch.playing === false && ui.playing === true) playingEndAt = Date.now()
      Object.assign(ui, patch)
      notify()
    },
    /** isPlaying 尾音截止墙钟：playing 或尾音宽限期内均视为「AI 正在朗读」。 */
    playingTailUntil() {
      // 对抗审查 Minor#5：尾音窗随估计 bulk delay 扩展（回声到达麦克风比本地停播
      // 晚 D 样本；固定 400ms 在 250ms 延迟路径下不足，残响会漏进 ASR/检测通道）。
      return playingEndAt + ECHO_TAIL_MS + (refDelaySamples / SAMPLE_RATE_16K) * 1000
    },
    async enter(sessionId) {
      try {
        const res = await fetch(new URL(`${basePath.slice(1)}/toggle`, document.baseURI), {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ sessionId, on: true, tabId: TAB_ID }),
        })
        const out = (await res.json()) as { active?: string | null; error?: string }
        // B1 修复：仅当本 tab 真正成为活跃会话才认领 owner；否则保持非 owner（null），
        // 防止多 tab 下「out.active 是别的会话」时本 tab 误收养别人会话 → 重复播放。
        activeSessionId = out.active === sessionId ? sessionId : null
        notify()
        if (!res.ok) return {
          ok: false,
          error: out.error === 'voice mode disabled'
            ? out.error
            : `进入语音模式失败：HTTP（请求状态）${res.status}，请检查会话和插件服务。`,
        }
        // I5：记住本次语音会话（autoResume 切回时自动恢复）。
        if (out.active === sessionId) setLastVoiceSession(sessionId)
        // 双重奏根治：拒绝线保留（host toggle 用 cancel 保 seq 连续递增）——
        // 重入/403 恢复后新句 seq 必然 > 线（旧帧 ≤ 线仍被拒），不清线消除
        // 「exit→enter 在途旧帧重入」窗口。
        // M5：区分「被抢占」（另一会话已活跃）与「真失败」——抢占时不误闪失败提示。
        return {
          ok: out.active === sessionId,
          preempted: out.active !== null && out.active !== sessionId,
          error: out.active === sessionId ? undefined : t('enterFail'),
        }
      } catch {
        return { ok: false, error: t('enterFail') }
      }
    },
    async exit(sessionId) {
      resetTelemetry()
      ui.turn = 'idle' // P2-4：退出复位回合状态
      // 双重奏根治：退出即停 TTS，拒绝线保留（host toggle off 用 cancel 停推且 seq 连续，
      // 重入后新句 seq > 线、旧帧 ≤ 线仍被拒）。
      doSkipAudio()
      try {
        const res = await fetch(new URL(`${basePath.slice(1)}/toggle`, document.baseURI), {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ sessionId, on: false, tabId: TAB_ID }),
        })
        await res.json()
        // B1 修复：退出后本 tab 不再是 owner；全局 active 可能是别的 tab 的会话，
        // 不能收养（否则本 tab 会重复播放别人会话的音频）。
        activeSessionId = null
        notify()
      } catch {
        // 共用连接 广播最终会纠正
      }
    },
    onAudioFrame(fn) {
      audioListeners.add(fn)
      return () => {
        audioListeners.delete(fn)
      }
    },
    setBackchannelHold(untilMs) {
      backchannelHoldUntil = untilMs
    },
    skipAudio() {
      doSkipAudio()
    },
    echoForAsr() {
      return echoSource
    },
    setEchoBypass(on) {
      echoBypass = on
    },
    echoDelayMs() {
      return (refDelaySamples / SAMPLE_RATE_16K) * 1000
    },
    unduckAudio() {
      engine.unduck()
    },
    cancelTurn(sessionId) {
      try {
        // 打断第二层：取消当前回合（官方 session.cancel 无参；Host 保留队列中的新消息）。
        ctx?.sessions?.binding?.(sessionId)?.session.cancel?.()
      } catch {
        // cancel 失败不抛到录音循环
      }
    },
    stampTelemetry,
    resetTelemetry,
    warmAudio() {
      engine.warm()
    },
  }
}

interface MicProps extends VoiceSlotActions {
  sessionId?: string
  useSession?: <T>(sel: (s: any) => T) => T
  useInput?: <T>(sel: (s: any) => T) => T
  inputActions?: { submit?: () => void; setDraft?: (text: string) => void }
}

/** host /config 的运行时引导参数（客户端每次进入语音模式重新拉取）。 */
interface VoiceBootConfig {
  basePath: string
  silenceMs: number
  interruptLevel: 0 | 1 | 2
  idleTimeoutMinutes: number
  autoSend: boolean
  /** 切换回上次语音会话时自动恢复（默认关）。 */
  autoResume: boolean
  mode: 'toggle' | 'hold'
  /** 打断方式：detect 自动探测（默认）；auto 自动（VAD 开口打断）；manual 手动（外放推荐，回声不误触发自打断）。 */
  bargeInMode: 'auto' | 'manual' | 'detect'
  /** 回声门控阈值（dB，默认 6）。 */
  echoGateDb: number
  /** 进入/退出语音模式的快捷键（如 Ctrl+Shift+V；空 = 禁用）。 */
  shortcut: string
  /** 唤醒词（空 = 关；asr.ts 检测入口，当前宿主侧保留接口）。 */
  wakeWord: string
  alwaysListen: boolean
  /** 多个完整短句，识别到任一项就提交已有草稿。 */
  sendCommands: string[]
  /** 工具调用提示音（默认关）。 */
  toolBeep: boolean
  /** 批 3：字幕字号档位（0=12/1=14/2=18/3=24 px；默认 0）。 */
  captionFontSize: 0 | 1 | 2 | 3
  /** 批 3：字幕宽度档位（0=50vw/1=70vw/2=90vw；默认 1）。 */
  captionMaxWidth: 0 | 1 | 2
  /** 批 5 / ADR-0008 Phase 1：让位语义 backchannel 开关（默认 true = 朗读期说「嗯/对」自动让位）。 */
  backchannelYield: boolean
  /** 批 G 任务 3：让位窗口时长（ms，500-3000，默认 1500）。onBackchannel 命中后 TTS 丢帧持续时间。 */
  yieldMs: number
  /** 批 B：ITN（逆文本规范化：口语数字 → 书面数字；默认 true）。 */
  senseITN: boolean
  /** 批 B：SenseVoice 引擎开关（默认 true = 启用 SenseVoice 模型，否则回退 FunASR）。 */
  senseVoice: boolean
}

let styleInjected = false

function useVoiceCss(): void {
  useEffect(() => {
    if (styleInjected) return
    styleInjected = true
    const el = document.createElement('style')
    el.textContent = `
@keyframes dshvm-fadein { from { opacity: 0; transform: translateY(4px) } to { opacity: 1; transform: none } }
@keyframes dshvm-eq { 0%, 100% { transform: scaleY(0.35) } 50% { transform: scaleY(1) } }
@keyframes dshvm-spin { to { transform: rotate(360deg) } }
.dshvm-bar { width: 3px; border-radius: 99px; transition: height 0.08s linear, opacity 0.08s linear }
/* 麦克风按钮所在的宿主容器也禁选：手指偏大时长按可能命中按钮外侧的容器留白，
   浏览器就近选中「语音」标签文字。 */
:has(> [data-dshvm="mic"]) { -webkit-user-select: none; user-select: none; -webkit-touch-callout: none }
/* DSH 的提交按钮在空草稿时禁用；此时由紧邻它的麦克风占据操作位。 */
div:has(> div > [data-slot="conversation.input.activity"] [data-dshvm="mic"][data-dshvm-draft="empty"]) > button:last-child:disabled { display: none }
/* 按住说话期间整页禁选（!important 压过宿主样式）：安卓/桌面在长按或按住微拖时
   会从按钮附近开始选区，出现蓝色高亮和选择手柄，导致「按住说话」不可用。 */
html.dshvm-holding, html.dshvm-holding * {
  -webkit-user-select: none !important;
  user-select: none !important;
  -webkit-touch-callout: none !important;
}
/* 批 3：字幕中文长词/URL 换行（外层 maxHeight:30vh + overflow:hidden 控制高度不溢出）。 */
.dshvm-caption { word-break: break-word; overflow-wrap: anywhere; }
`
    document.head.appendChild(el)
  }, [])
}

export function MicButton({
  bus,
  sessionId,
  useSession,
  useInput,
  inputActions,
}: MicProps): React.ReactElement {
  // local: 'off' | 'pending' | 'on'（bus.active === sessionId 时有效）
  const [local, setLocal] = useState<'off' | 'pending' | 'on'>('off')
  const localRef = useRef<'off' | 'pending' | 'on'>('off')
  const sidRef = useRef<string | undefined>(sessionId)
  const engineRef = useRef<AsrEngine | null>(null)
  const wakeRef = useRef<{ engine: SherpaKwsEngine; stream: MediaStream } | null>(null)
  const wakeEpochRef = useRef(0)
  const wakeStartingRef = useRef(false)
  const wakePlaybackRef = useRef(false)
  const actionsRef = useRef(inputActions)
  const partialDraftRef = useRef<{ base: string; preview: string } | null>(null)
  const submitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  /** 累积模式「静音到点才发」的延迟发送计时（区别于 submitTimerRef 的提交重试计时）。 */
  const autoSendTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const idleTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  /** 批 G 任务 2：空闲退出前 30 秒提示的预警定时器（到点 setUi({idleWarn:true})）。 */
  const idleWarnTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  /** 批 G 任务 2：当前是否处于「30 秒后退出」预警态（用于 clearIdle 时复位 bus.ui.idleWarn）。 */
  const idleWarnActiveRef = useRef(false)
  /** 批 G 任务 2：空闲退出错误提示的自动清除定时器（3 秒后清 error）。 */
  const idleClearErrorRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const runningRef = useRef(false)
  /** 组件存活守卫：enterMode 异步流程（getUserMedia 权限框）期间卸载时中止收尾。 */
  const mountedRef = useRef(true)
  /** hold 模式 Ctrl 按住说话中（600ms 阈值后才置真）。 */
  const holdCtrlRef = useRef(false)
  /** 手动打断（bargeInMode=manual）时 toggle 模式按住 Ctrl 接管中。 */
  const manualHoldRef = useRef(false)
  /** 手动打断入口：enterMode 内定义 hardBreak 后写入，供手势直接调用（外放可靠打断）。 */
  const breakRef = useRef<(() => Promise<void>) | null>(null)
  /** M2：隐藏 tab 时已暂停收音（可见时恢复）；隐私——避免后台持续录音。 */
  const pausedForHiddenRef = useRef(false)
  /** 引导参数读 bus.ui.boot（bus 为单例，组件重挂载不丢；事件时读实时值）。 */
  const bootNow = (): VoiceBootConfig =>
    bus.ui.boot ?? {
      basePath: '/voice-mode',
      silenceMs: 1500,
      interruptLevel: 0,
      idleTimeoutMinutes: 5,
      autoSend: false,
      autoResume: false,
      mode: 'toggle',
      // 批 7O（ADR-0006）：bootNow 兜底默认与 VOICE_SETTINGS_DEFAULTS 对齐为 detect。
      bargeInMode: 'detect',
      echoGateDb: 6,
      shortcut: 'Ctrl+Shift+V',
      wakeWord: '',
      alwaysListen: false,
      sendCommands: [...DEFAULT_SEND_COMMANDS],
      toolBeep: false,
      captionFontSize: 0,
      captionMaxWidth: 1,
      backchannelYield: true,
      yieldMs: 1500,
      // 批 B：5 ASR 字段默认值，与 src/index.ts VOICE_SETTINGS_DEFAULTS 对齐（plan §12 批 B 周全修复）。
      senseITN: true,
      senseVoice: true,
    }

  useVoiceCss()

  // bus.ui 镜像（仅模式/自动发送变化才触发重渲染；电平高频更新不打扰）。
  const [, bumpUi] = useState(0)
  useEffect(
    () =>
      bus.subscribe(() => {
        bumpUi((t) => t + 1)
        const playing = bus.ui.playing
        if (playing !== wakePlaybackRef.current) {
          wakePlaybackRef.current = playing
          if (playing) wakeRef.current?.engine.pause()
          else wakeRef.current?.engine.resume()
        }
      }),
    [bus],
  )

  const setLocalMode = (m: 'off' | 'pending' | 'on'): void => {
    localRef.current = m
    setLocal(m)
  }

  /** 每次进入语音模式重新拉取 /config（设置改动即时生效），失败用当前 bus.boot 兜底。
   *  批 B：fetchConfig 白名单补 5 ASR 字段透传（plan §12 批 B 周全修复）；
   *  host-only 字段 cacheDir / allowLan / audioMime / ttsEngine / modelHost 不透传（对抗性审查 B3 决定）——
   *  这些字段 host 内部使用，client 不消费，透传暴露抽象边界 + 增加传输体积。 */
  const fetchConfig = async (): Promise<VoiceBootConfig> => {
    try {
      const res = await fetch(new URL(`${BASE_PATH.slice(1)}/config`, document.baseURI))
      if (!res.ok) return bootNow()
      const c = (await res.json()) as Partial<VoiceBootConfig>
      const cur = bootNow()
      const next: VoiceBootConfig = {
        basePath: c.basePath ?? cur.basePath,
        silenceMs: c.silenceMs ?? cur.silenceMs,
        interruptLevel: c.interruptLevel ?? cur.interruptLevel,
        idleTimeoutMinutes: c.idleTimeoutMinutes ?? cur.idleTimeoutMinutes,
        autoSend: c.autoSend ?? cur.autoSend,
        autoResume: c.autoResume === true,
        mode: c.mode === 'hold' ? 'hold' : 'toggle',
        bargeInMode: c.bargeInMode === 'manual' ? 'manual' : c.bargeInMode === 'detect' ? 'detect' : 'auto',
        echoGateDb: typeof c.echoGateDb === 'number' ? Math.min(12, Math.max(3, c.echoGateDb)) : cur.echoGateDb,
        shortcut: typeof c.shortcut === 'string' ? c.shortcut : cur.shortcut,
        wakeWord: typeof c.wakeWord === 'string' ? c.wakeWord : cur.wakeWord,
        alwaysListen: c.alwaysListen === true,
        sendCommands: Array.isArray(c.sendCommands) ? c.sendCommands.filter((item): item is string => typeof item === 'string') : cur.sendCommands,
        toolBeep: c.toolBeep === true,
        // 批 3：fetchConfig 是白名单拼接（plan §5.2 措辞「通用透传」与此处源码不符——见 commit message）
        captionFontSize: c.captionFontSize === 1 || c.captionFontSize === 2 || c.captionFontSize === 3 ? c.captionFontSize : 0,
        captionMaxWidth: c.captionMaxWidth === 0 || c.captionMaxWidth === 2 ? c.captionMaxWidth : 1,
        // 批 5：同模式（plan §7.2 表漏列 fetchConfig 字段透传，类批 3 captionFontSize 集成层补丁）
        backchannelYield: c.backchannelYield !== false,
        // 批 G 任务 3：让位窗口时长（500-3000ms）；类型校验严格 + 默认值兜底。
        yieldMs: typeof c.yieldMs === 'number' && c.yieldMs >= 500 && c.yieldMs <= 3000 ? c.yieldMs : 1500,
        // 批 B：5 ASR 字段透传（host /config handler 在 c2120d9 已透传 4 字段，本批补 senseVoice + 客户端白名单对齐）。
        // 类型校验严格 + 默认值兜底，与 src/index.ts VOICE_SETTINGS_DEFAULTS 对齐（plan §12 批 B 周全修复）。
        senseITN: c.senseITN === false ? false : true,
        senseVoice: c.senseVoice === false ? false : true,
      }
      bus.setUi({ boot: next, mode: next.mode, wakeWord: next.wakeWord })
      return next
    } catch {
      return bootNow()
    }
  }

  const stopWakeStandby = (transfer = false): MediaStream | null => {
    wakeEpochRef.current++
    wakeStartingRef.current = false
    const wake = wakeRef.current
    wakeRef.current = null
    wake?.engine.dispose()
    if (!transfer) wake?.stream.getTracks().forEach((track) => track.stop())
    if (bus.ui.wakeStatus !== 'off') bus.setUi({ wakeStatus: 'off' })
    return transfer ? wake?.stream ?? null : null
  }

  const startWakeStandby = async (knownConfig?: VoiceBootConfig): Promise<void> => {
    if (wakeRef.current || wakeStartingRef.current || !mountedRef.current || document.hidden || localRef.current !== 'off') return
    const cfg = knownConfig ?? await fetchConfig()
    const wakeWords = splitWakeWords(cfg.wakeWord)
    if (!cfg.alwaysListen || !wakeWords.length || cfg.mode !== 'toggle') return
    if (wakeRef.current || wakeStartingRef.current || !mountedRef.current || document.hidden || localRef.current !== 'off') return
    const epoch = ++wakeEpochRef.current
    wakeStartingRef.current = true
    bus.setUi({ wakeStatus: 'loading', error: null })
    let stream: MediaStream | null = null
    let engine: SherpaKwsEngine | null = null
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      })
      if (epoch !== wakeEpochRef.current || document.hidden || localRef.current !== 'off') {
        stream.getTracks().forEach((track) => track.stop())
        return
      }
      engine = new SherpaKwsEngine({ keywords: wakeWords, assetsPath: new URL(`${BASE_PATH.slice(1)}/kws/`, document.baseURI).href })
      wakeRef.current = { engine, stream }
      engine.onKeyword(() => {
        if (epoch !== wakeEpochRef.current || localRef.current !== 'off') return
        const microphone = stopWakeStandby(true)
        void enterMode(microphone)
      })
      engine.onError((detail) => {
        debugLog('wake-engine-error', { detail })
        if (epoch !== wakeEpochRef.current) return
        stopWakeStandby()
        bus.setUi({ error: '本地唤醒已停止，请检查唤醒模型资源；仍可点击麦克风输入。' })
      })
      await engine.load(stream)
      if (epoch !== wakeEpochRef.current || document.hidden || localRef.current !== 'off') return
      wakePlaybackRef.current = bus.ui.playing
      if (!bus.ui.playing) engine.resume()
      bus.setUi({ wakeStatus: 'on', error: null })
    } catch (error) {
      if (epoch !== wakeEpochRef.current) return
      debugLog('wake-start-error', { detail: String(error) })
      stopWakeStandby()
      bus.setUi({ error: error instanceof DOMException && error.name === 'NotAllowedError'
        ? '常开唤醒需要麦克风权限；允许后刷新聊天页，或点击麦克风直接输入。'
        : '本地唤醒启动失败，请检查麦克风和唤醒模型；仍可点击麦克风输入。' })
    } finally {
      if (epoch === wakeEpochRef.current) wakeStartingRef.current = false
    }
  }

  const clearIdle = (): void => {
    if (idleTimerRef.current) {
      clearTimeout(idleTimerRef.current)
      idleTimerRef.current = null
    }
    if (idleWarnTimerRef.current) {
      clearTimeout(idleWarnTimerRef.current)
      idleWarnTimerRef.current = null
    }
    if (idleClearErrorRef.current) {
      clearTimeout(idleClearErrorRef.current)
      idleClearErrorRef.current = null
    }
    // 批 G 任务 2：清除「30 秒后自动退出」提示（重新进入语音模式或用户活动后复位）。
    if (idleWarnActiveRef.current) {
      idleWarnActiveRef.current = false
      bus.setUi({ idleWarn: false })
    }
  }
  const resetIdle = (): void => {
    clearIdle()
    const idleMs = (bootNow().idleTimeoutMinutes > 0 ? bootNow().idleTimeoutMinutes : 10) * 60 * 1000
    // 批 G 任务 2：9:30 弹 toast「30 秒后自动退出」——总时长 ≤ 30s 时跳过预警（避免直接退出又立刻闪提示）。
    if (idleMs > 30_000) {
      idleWarnTimerRef.current = setTimeout(() => {
        idleWarnTimerRef.current = null
        idleWarnActiveRef.current = true
        bus.setUi({ idleWarn: true })
      }, idleMs - 30_000)
    }
    idleTimerRef.current = setTimeout(() => {
      idleTimerRef.current = null
      const sid = sidRef.current
      if (localRef.current === 'on' && sid) {
        // 批 G 任务 2：空闲退出时显示「空闲超时已自动退出（设置里可调时长）」3 秒后清。
        // 不打断已有的 error（让用户先看到错误）；仅当 error 为空时覆写。
        bus.setUi({
          error: bus.ui.error ?? t('idleTimeoutQuit'),
        })
        const prevClearError = idleClearErrorRef.current
        if (prevClearError) clearTimeout(prevClearError)
        idleClearErrorRef.current = setTimeout(() => {
          idleClearErrorRef.current = null
          if (bus.ui.error === t('idleTimeoutQuit')) bus.setUi({ error: null })
        }, 3000)
        void exitModeRef.current('idle')
      }
    }, idleMs)
  }

  // host 广播：被抢占/他会话让出 -> 自动退出（Q11）
  useEffect(() => {
    return bus.subscribe(() => {
      const sid = sidRef.current
      if (localRef.current !== 'on') return
      if (bus.activeSessionId !== sid) {
        setLocalMode('off')
        clearIdle()
        cancelPendingSubmit()
        cancelAutoSend()
        clearBreakTimer()
        setHolding(false) // 对抗审查 Important#2：被抢占退出时复位录音态红色
        isSpeechTrueCount = 0 // 打断根治：任何 host 驱动退出（状态条退出/被抢占/跨 tab 让出）都复位计数
        breakRef.current = null
        manualHoldRef.current = false
        holdCtrlRef.current = false // 复位 Ctrl 按住态（防抢占后残留致下次手势错乱）
        const engine = engineRef.current
        engineRef.current = null
        // Fix：先置 null 防重入，再异步 stop（stop 内部会阻止 handleAudio）
        if (engine) void engine.stop()
        bus.resetTelemetry() // P1-5：与 exitMode 同口径清埋点
        bus.setUi({ state: 'idle', partial: '', levels: [], botLevels: [], error: null, model: null, ttsNotice: null, isSpeech: undefined })
      }
    })
  }, [bus])

  /** 取消草稿提交（打字打断提交窗口）。 */
  const cancelPendingSubmit = (): void => {
    if (submitTimerRef.current) {
      clearInterval(submitTimerRef.current) // Fix：setInterval 需要 clearInterval，不是 clearTimeout
      submitTimerRef.current = null
    }
  }

  /** 取消「静音到点才发」的延迟发送计时（用户再开口 / 退出 / 被抢占时）。 */
  const cancelAutoSend = (): void => {
    if (autoSendTimerRef.current) {
      clearTimeout(autoSendTimerRef.current)
      autoSendTimerRef.current = null
    }
  }

  /** 提交当前草稿（带 3 次有界重试；提交成功草稿被清、或用户改写则停止重试）。
   *  expectedText：调用方已知的草稿文本。force 路径在 setDraft 后立即调用，draftRef 尚未
   *  re-render 更新（读旧值会误判空草稿而漏发），故由调用方显式传入；定时器路径省略则读 draftRef。 */
  const submitDraftNow = (expectedText?: string): void => {
    cancelPendingSubmit()
    const actions = actionsRef.current
    const submitFn = actions?.submit
    if (typeof submitFn !== 'function') return
    const draftSnapshot = (expectedText ?? draftRef.current).trim()
    if (!draftSnapshot) return
    const doSubmit = (): void => {
      try {
        const r: any = submitFn()
        // 兼容 Promise 型 submit
        if (r && typeof r.then === 'function') {
          r.catch(() => {
            bus.setUi({ error: t('sendFailKept') })
          })
        }
      } catch {
        bus.setUi({ error: t('sendFailKept') })
      }
    }
    doSubmit()
    let retryCount = 0
    submitTimerRef.current = setInterval(() => {
      retryCount++
      const phase = phaseRef.current
      // 已提交（草稿被清成空）/ 用户改写 / 进入提交态 → 停止重试
      if (retryCount > 3 || phase === 'submitting' || phase === 'adjudicating' || draftRef.current.trim() !== draftSnapshot) {
        cancelPendingSubmit()
        return
      }
      doSubmit()
    }, 500)
  }

  /** 累积模式：静音到「发送阈值」（断句已等一个 silenceMs，再额外等一个）才发；
   *  期间再开口由 onState('speech') → cancelAutoSend 取消，继续累积。 */
  const scheduleAutoSend = (): void => {
    cancelAutoSend()
    const delay = bootNow().silenceMs
    autoSendTimerRef.current = setTimeout(() => {
      autoSendTimerRef.current = null
      const eng = engineRef.current
      // 用户仍在说话（30s 滚段后新段已开）→ 不发，文字留草稿，下一段定稿会重新调度。
      if (eng && (eng.state === 'speech' || eng.holding)) return
      // 到点前 AI 已开播 / 自动发送被关 → 不发（文字已留在草稿）。
      if (bus.ui.playing) return
      if (bootNow().autoSend === false) return
      submitDraftNow()
    }, delay)
  }

  const exitMode = async (_reason: 'manual' | 'idle' | 'typing'): Promise<void> => {
    if (localRef.current === 'off') return
    setLocalMode('off')
    clearIdle()
    cancelPendingSubmit()
    cancelAutoSend()
    isSpeechTrueCount = 0 // 打断根治：退出重置 isSpeech 计数（防残留）
    fixtureRecorder.save('exit') // fixture 录制：退出即落盘（未开录时为 no-op）
    breakRef.current = null // 手动打断入口：退出即失效
    manualHoldRef.current = false
    clearBreakTimer()
    setHolding(false) // 对抗审查 Important#2：退出复位录音态红色
    const engine = engineRef.current
    engineRef.current = null
    if (engine) await engine.stop() // Fix：等待 stop 完成，确保 handleAudio 停止
    bus.resetTelemetry() // P1-5：退出清空埋点链
    // Minor#3：清 VAD 徽标（manual 模式冻结不复位会跨会话残留）。
    bus.setUi({ state: 'idle', partial: '', levels: [], error: null, model: null, ttsNotice: null, isSpeech: undefined })
    const sid = sidRef.current
    if (sid) await bus.exit(sid) // Fix：等待 host 退出完成，防 ASR 请求 403
    void startWakeStandby()
  }

  const enterMode = async (microphone?: MediaStream | null): Promise<void> => {
    const sid = sidRef.current
    if (!sid || localRef.current !== 'off') {
      microphone?.getTracks().forEach((track) => track.stop())
      return
    }
    const sharedMicrophone = microphone ?? stopWakeStandby(true)
    // 健壮性：每次进入语音模式重置 isSpeech 计数（模块级变量跨 enterMode 持久，
    // 残留计数会让新会话首帧误判「连续 2 次 true」而误打断）。
    isSpeechTrueCount = 0
    setLocalMode('pending')
    try {
      const entered = await bus.enter(sid)
      if (!mountedRef.current) {
        // 权限框/网络期间组件已卸载：释放刚 arm 的 host 会话，不继续建引擎（隐私级泄漏）。
        if (entered.ok) void bus.exit(sid)
        sharedMicrophone?.getTracks().forEach((track) => track.stop())
        return
      }
      if (!entered.ok) {
        sharedMicrophone?.getTracks().forEach((track) => track.stop())
        setLocalMode('off')
        // M5：被抢占（另一会话已活跃）时静默跟随 mode 广播，不误闪「进入失败」。
        if (!entered.preempted) {
          bus.setUi({
            error:
              entered.error === 'voice mode disabled'
                ? t('disabled')
                : entered.error ?? t('enterFail'),
          })
        }
        return
      }
      // 每次进入重新拉取 host 引导参数（静音/打断档位/自动发送/空闲超时/模式）
      const cfg = await fetchConfig()
      const basePath = cfg.basePath
      const silenceMs = cfg.silenceMs
      const interruptLevel = cfg.interruptLevel
      const confirmFrames = INT_CONFIRM_FRAMES[interruptLevel] ?? 2
      // 批 7O（ADR-0006）：detect 模式下由 onAecState（第一级探测）在 getUserMedia 后
      // 改写为 'auto'/'manual'；auto/manual 显式取值保持不变。
      let bargeInMode = cfg.bargeInMode
      debugLog('enter', {
        build: BUILD_TAG,
        mode: cfg.mode,
        bargeInMode,
        echoGateDb: cfg.echoGateDb,
        interruptLevel,
        silenceMs,
        sessionId: sid,
      })
      // 打断根治阶段二：hardBreak 由 isSpeech 连续前沿触发（RMS 快路径 + duck 探针
      // 移除后提炼为独立函数；行为保持不变）：
      // 1) 本地播放队列清空 + host TTS 队列 epoch++（静音）
      // 2) 有 running 回合则 session.cancel({keepInbox:true})（取消生成、保新消息）
      // 3) 半截标注由「转录区新消息续入」自然呈现（Q8 标注见 §8.5 收尾）
      const hardBreak = async (): Promise<void> => {
        // 立即停播 + 恢复音量：不等待慢操作（discardSegment 最多 5s、cancel 最多 3s）。
        bus.skipAudio()
        bus.unduckAudio()
        // 批 5：真打断优先——清 backchannel 让位窗口，避免 1.5s 丢帧阻塞用户新回合播放。
        bus.setBackchannelHold(0)
        // 立即取消当前回合（不等 cancelP/discardSegment）：否则其 3~5s 窗口内用户开口的
        // 新回合会被迟到的 cancelTurn 误取消（打断+说话竞态）。
        if (runningRef.current && sidRef.current) {
          bus.cancelTurn(sidRef.current!)
        }
        // 双重奏根治：cancel 立即发出（不等 discardSegment）→ host epoch++ 停推，
        // 缩短「skip 后旧回合帧继续到达」的窗口（在途旧帧由 client 拒绝线兜底丢弃）。
        const cancelP = fetch(new URL(`${BASE_PATH.slice(1)}/cancel`, document.baseURI), {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          // hold 按压中保留 host ASR 段（松手定稿续传前半句，防吃句）。
          body: JSON.stringify({ sessionId: sidRef.current, keepAsr: engineRef.current?.holding === true }),
          signal: AbortSignal.timeout(3000),
        }).catch(() => {
          // cancel 路由不可达：本地已静音
        })
        // 异步清理：丢弃残余段（防残缺文本 autoSend）+ host 静音 + 取消回合。
        // hold 按压中（含 toggle 模式按住 Ctrl）不丢弃：本段是用户明确要说的内容，
        // 打断只停 AI——否则按住说的前半句会被吃掉。
        if (engineRef.current && !engineRef.current.holding) await engineRef.current.discardSegment()
        await cancelP
        bus.setUi({ partial: '…' })
      }
      // 手动打断入口：显式手势（按住麦克风/Ctrl）在播放中调用，回声无关、100% 可靠。
      breakRef.current = hardBreak
      const engine = createAsrEngine(
        {
          silenceMs,
          basePath,
          microphone: sharedMicrophone ?? undefined,
          mode: cfg.mode,
          // 点麦克风和本地 KWS 命中都已表达录入意图，不再要求重复说唤醒词。
          wakeWord: '',
          hasPendingDraft: () => cfg.sendCommands.length > 0 && draftRef.current.trim() !== '',
          echoGateDb: cfg.echoGateDb,
          // 批 7N（ADR-0006）：打断方式透传——manual 时 handleAudio 仅在 holdActive 期间入流。
          bargeInMode: cfg.bargeInMode,
          echo: bus.echoForAsr(),
          // 回声尾音宽限：playing 或尾音窗口内均视为朗读中，防句播完瞬间的残响漏入 ASR。
          isPlaying: () => bus.ui.playing || Date.now() < bus.playingTailUntil(),
          // 打断根治阶段二：服务端 Silero VAD 帧级检测下行 → 驱动打断（替代 RMS 能量快
          // 路径）。连续 confirmFrames 次 true（墙钟节拍 100ms/拍，三档确认约 0.3/0.2/0.1s）
          // 判真实人声前沿；仅 AI 朗读中（bus.ui.playing）触发 hardBreak，
          // 防 TTS 回声被 VAD 误判为语音而自打断。
          onIsSpeech: (speech) => {
            fixtureRecorder.noteIsSpeech(speech)
            // 手动打断模式（外放推荐）：不依赖 VAD 自动打断——外放回声会被 Silero VAD
            // 误判为语音导致自打断静音；打断改由显式手势触发。也不更新 isSpeech 徽标，
            // 避免回声造成「一直检测到语音」的假象。
            if (bargeInMode === 'manual') return
            // 打断检测只在 AI 朗读中有意义：非播放期清零计数。否则「用户说自己的话
            // 期间累积的计数」会在 AI 开播瞬间残留 ≥confirmFrames → confirmMs=0 立即
            // 误打断（实测「频繁打断」根因）。
            if (!bus.ui.playing) {
              isSpeechTrueCount = 0
              interruptFirstAt = 0
              bus.setUi({ isSpeech: speech, echoDelayMs: bus.echoDelayMs(), echoLevels: engineRef.current?.echoLevels() })
              return
            }
            // 调试：VAD 前沿变化 + 判定链关键态（仅 telemetry=1）。
            if (speech === true && isSpeechTrueCount === 0) {
              const lv = engineRef.current?.echoLevels()
              debugLog('vad-speech-start', {
                playing: bus.ui.playing,
                delayMs: Math.round(bus.echoDelayMs()),
                floor: lv?.floorRms,
                resid: lv?.residualRms,
                peak: lv?.peakRms,
              })
            }
            if (speech === true) {
              isSpeechFalseRun = 0
              isSpeechTrueCount++
              if (isSpeechTrueCount === 1) interruptFirstAt = Date.now()
              if (isSpeechTrueCount >= confirmFrames) {
                // A2.5 回声门控：残差未明显高于回声地板 → 判回声，不打断（防外放回声自打断）。
                // 仅自动模式到此处（manual 模式已提前 return）。
                if (engineRef.current && !engineRef.current.aboveEchoFloor(cfg.echoGateDb ?? 6)) {
                  const lv = engineRef.current?.echoLevels()
                  debugLog('echo-gate-reject', {
                    gateDb: cfg.echoGateDb ?? 6,
                    floor: lv?.floorRms,
                    resid: lv?.residualRms,
                    peak: lv?.peakRms,
                    confirmFrames,
                  })
                  isSpeechTrueCount = 0
                  interruptFirstAt = 0
                  return
                }
                // 打断确认耗时 = VAD 首次判真 → 触发（真机标定 C-3 数据）。
                const confirmMs = interruptFirstAt > 0 ? Date.now() - interruptFirstAt : 0
                const lv = engineRef.current?.echoLevels()
                debugLog('interrupt-trigger', {
                  confirmMs,
                  floor: lv?.floorRms,
                  resid: lv?.residualRms,
                  peak: lv?.peakRms,
                  delayMs: Math.round(bus.echoDelayMs()),
                })
                interruptFirstAt = 0
                isSpeechTrueCount = 0 // 重置计数防重复触发
                fixtureRecorder.mark('interrupt', `confirmMs=${confirmMs}`)
                resetIdle()
                bus.resetTelemetry() // P1-5：打断 = 上一轮回复作废，链清空
                bus.setUi({ interruptConfirmMs: confirmMs })
                void hardBreak()
              }
            } else {
              // 迟滞衰减而非清零：单拍「假」（音节边缘/轻声闪烁）不衰减，连续 2 拍假才减 1，
              // 连续静音才归零。比「每拍 -1」更抗抖动，confirmMs 不再飙到 1~2.7s（真机实测）。
              isSpeechFalseRun++
              if (isSpeechFalseRun >= 2) {
                isSpeechFalseRun = 0
                isSpeechTrueCount = Math.max(0, isSpeechTrueCount - 1)
                if (isSpeechTrueCount === 0) interruptFirstAt = 0
              }
            }
            // 仍存 ui 供状态条展示；回声诊断每拍推送（真机标定数据）。
            bus.setUi({ isSpeech: speech, echoDelayMs: bus.echoDelayMs(), echoLevels: engineRef.current?.echoLevels() })
          },
          onSessionExpired: async () => {
            // I4：仅当本 tab 仍处语音模式（local=on）才反抢；已被让出/退出时跟随 mode 广播
            // 静默退出，防多 tab 下 403→重入→403 乒乓抖振（TTS 反复被掐）。
            if (localRef.current !== 'on') return false
            // I3：2s 重入冷却——无退避时两个 local=on 的 tab 每拍 403 都反抢，
            // 互踢振荡直到某一方 mode 广播先落地；冷却把反抢频率压到 0.5Hz。
            if (Date.now() - lastReenterAt < 2000) return false
            lastReenterAt = Date.now()
            // 403 恢复：host 端活跃会话已变更（如被抢占/让出），尝试重新进入。
            bus.setUi({ error: t('sessionExpired') })
            const reentered = await bus.enter(sid)
            if (!reentered.ok) {
              bus.setUi({ error: t('sessionExpiredFail') })
            } else {
              bus.setUi({ error: null })
            }
            return reentered.ok
          },
          // A1：原生 AEC 生效状态 → 状态条提示（外放且原生 AEC 失效时引导用耳机/手动打断）。
          onAecState: (on) => {
            debugLog('aec-state', { nativeEchoCancellation: on })
            bus.setEchoBypass(on) // 原生 AEC 生效时旁路自研 NLMS（防错位尖峰）
            bus.setUi({ aecOff: !on })
            fixtureRecorder.mark('native-aec', on ? 'on（自研 NLMS 旁路）' : 'off（自研 NLMS 生效）')
            // 批 7O（ADR-0006）第一级自动探测：detect 模式据原生 AEC 实际状态落运行时打断方式。
            //   false → 落 manual（不自打断）+ 状态条提示；true → auto。auto/manual 显式取值不探测。
            if (cfg.bargeInMode === 'detect') {
              bargeInMode = on ? 'auto' : 'manual'
              // 改写 boot 供手势（Ctrl 按住打断）读实时生效的打断方式；非 detect 不触碰 boot。
              bus.setUi({ boot: { ...bus.ui.boot, bargeInMode }, bargeInDetectFallback: !on })
            }
          },
          // 批 5 / ADR-0008 Phase 1：backchannel 命中回调——
          //   立即 skipAudio 终止当前朗读 + 置 cfg.yieldMs hold 窗口，期间 TTS 帧丢（字幕同帧丢）。
          //   关 backchannelYield = 不挂回调，行为等同改造前（I10 豁免由 §7.0 ADR-0008 接受）。
          onBackchannel: cfg.backchannelYield
            ? () => {
                bus.skipAudio()
                bus.setBackchannelHold(Date.now() + (cfg.yieldMs ?? 1500))
              }
            : undefined,
          // 批 F：传 backchannelYield 给 ASR 引擎，让 asr.ts:379 守卫短路 matchBackchannel。
          backchannelYield: cfg.backchannelYield,
        },
        sid,
      )
      bus.setUi({ mode: cfg.mode })
      engineRef.current = engine
      // fixture 录制（ADR-0004，默认关闭；localStorage['dsh-voice-mode.record']=meta|full）
      fixtureRecorder.begin({
        build: BUILD_TAG,
        mode: cfg.mode,
        bargeInMode,
        echoGateDb: cfg.echoGateDb,
        interruptLevel,
      })
      // P1-5 延迟埋点链：ASR 侧三枚时间戳（说完/端点/定稿上传）入链。
      engine.onTelemetry((e) => bus.stampTelemetry(e.stage, e.at))
      // P1-2：播放引擎 AudioContext 需手势栈预热（decode/start 才不会被静音）。
      bus.warmAudio()
      // 工具提示音上下文预热：进入语音模式处于用户手势栈（点麦克风），
      // 此处创建并 resume——Safari/iOS 非手势栈新建的 AudioContext 会 suspended 静默。
      try {
        if (!beepCtx) beepCtx = new AudioContext()
        void beepCtx.resume?.()
      } catch {
        // 预热失败不阻塞（toolBeep 首次播放时仍会尝试）
      }

      engine.onState((s) => {
        bus.setUi({ state: s })
        if (s === 'speech') cancelAutoSend() // 再开口：取消延迟发送，继续累积
        if (s === 'idle') resetIdle()
      })
      engine.onError((key) => {
        bus.setUi({ error: t(key as 'recognitionFail') })
      })
      engine.onLevel((l) => {
        // 波形：14 根滚动条
        const cur = bus.ui.levels
        const next = cur.length < WAVE_BARS ? [...cur, l] : [...cur.slice(1), l]
        bus.setUi({ levels: next })
      })
      engine.onPartial((text) => {
        bus.setUi({ partial: text })
        // 待唤醒阶段只显示识别诊断；命令阶段才把实时文字写入输入框。
        if (bus.ui.state === 'wake' || !text.trim()) return
        const actions = actionsRef.current
        if (typeof actions?.setDraft !== 'function') return
        const previous = partialDraftRef.current
        const current = draftRef.current
        const base = previous && current === previous.preview ? previous.base : current
        const preview = base ? `${base} ${text.trim()}` : text.trim()
        if (preview !== current) {
          actions.setDraft(preview)
          draftRef.current = preview
        }
        partialDraftRef.current = { base, preview }
      })
      engine.onSegment((text, meta) => {
        // 定稿进草稿（可编辑 Q13）。发送语义：累积模式——连续多段拼成一条消息，
        // 静音到「发送阈值」（断句后再额外静音一个 silenceMs）或按住 Ctrl / hold 松手才发，
        // 不再每段定稿立即发送（长句碎片化/丢字的根因）。
        resetIdle()
        bus.setUi({ partial: '' }) // 定稿即清实时字幕（防旧 partial 遮蔽思考/朗读状态条）
        const actions = actionsRef.current
        const trimmed = text.trim()
        const previous = partialDraftRef.current
        const curText = previous && draftRef.current === previous.preview ? previous.base : draftRef.current
        partialDraftRef.current = null
        if (!trimmed) return
        const sendCommand = matchesSendCommand(trimmed, cfg.sendCommands)
        // 待唤醒态的普通转写仍只作预览；有草稿时仅完整的发送命令可越过唤醒门。
        if (meta?.wakeStandby && !sendCommand) return
        // 独立的语音确认命令只提交已有草稿，不把命令词写进输入框。
        // 无草稿时保持空输入，避免误发一条「发送」。
        if (sendCommand) {
          cancelAutoSend()
          if (previous && draftRef.current === previous.preview) {
            actions?.setDraft?.(curText)
            draftRef.current = curText
          }
          if (curText.trim()) setTimeout(() => submitDraftNow(curText), 0)
          else bus.setUi({ error: '没有待发送的文字' })
          return
        }
        // 追加式写入：保留已有草稿内容（绝对不改第一真文）：
        let nextDraft = trimmed
        try {
          nextDraft = curText ? `${curText} ${trimmed}` : trimmed
          if (typeof actions?.setDraft === 'function') actions.setDraft(nextDraft)
          else if (typeof (actions as any)?.setDraft === 'function') (actions as any).setDraft(nextDraft)
          draftRef.current = nextDraft
        } catch {
          try {
            actions?.setDraft?.(trimmed)
          } catch {
            // 提交失败：文字已留在草稿（Q16）
          }
        }
        // 按住 Ctrl / hold 松手只结束当前语音段，文字仍需用户点击发送或说确认命令。
        if (meta?.force) {
          cancelAutoSend()
          return
        }
        // hold 模式按住期间的非强制定稿（30s 滚段）：只累积进草稿，绝不自动发送（松手才发）。
        if (bootNow().mode === 'hold') return
        // AI 自聊修复：TTS 在播（bus.ui.playing）时不得自动发送非强制段——
        // 因 TTS 回声定稿后若无 gate 会经 onSegment 发出，进入 AI 回复→TTS→回声 → 自循环。
        if (bus.ui.playing) return
        // 自动提交门控：设置关闭时只留草稿，等待用户编辑/发送。
        if (bootNow().autoSend === false) return
        // 累积模式：静音到点才发（期间再开口 → onState('speech') → cancelAutoSend 继续累积）。
        scheduleAutoSend()
      })
      bus.setUi({ state: 'idle', partial: '', levels: [], botLevels: [], error: null, model: null, ttsNotice: null })
      if (!mountedRef.current) {
        engineRef.current = null
        void bus.exit(sid)
        return
      }
      await engine.start()
      if (!mountedRef.current) {
        engineRef.current = null
        await engine.stop()
        void bus.exit(sid)
        return
      }
      // 抢占守卫：getUserMedia/start 窗口内若被另一 tab 接管（activeSessionId 已变），
      // 订阅已置 off + 停麦；此处不得再置 on，否则按钮绿「语音中」但无引擎无麦（卡死态）。
      if (bus.activeSessionId !== sid) {
        engineRef.current = null
        await engine.stop()
        return
      }
      setLocalMode('on')
      resetIdle()
    } catch (e) {
      sharedMicrophone?.getTracks().forEach((track) => track.stop())
      // getUserMedia 被拒等：留在 off，红点提示（Q16）
      setLocalMode('off')
      const msg =
        e instanceof DOMException
          ? e.name === 'NotAllowedError'
            ? t('micDenied')
            : t('micUnavailable')
          : t('startFail').replace('{err}', '请检查浏览器麦克风权限与语音服务连接')
      bus.setUi({ error: msg })
      const sid2 = sidRef.current
      if (sid2) void bus.exit(sid2)
      void startWakeStandby()
    }
  }

  /** 点击防抖：2 秒内重复的进/出请求只响应第一次（避免撞 /toggle 限流 429）。 */
  const toggleGuardRef = useRef(0)
  const toggle = (): void => {
    const now = Date.now()
    if (now - toggleGuardRef.current < 2000) return
    toggleGuardRef.current = now
    if (localRef.current === 'on') void exitModeRef.current('manual')
    else if (localRef.current === 'off') void enterMode()
  }
  const toggleRef = useRef(toggle)
  toggleRef.current = toggle
  const exitModeRef = useRef(exitMode)
  exitModeRef.current = exitMode

  useEffect(() => {
    actionsRef.current = inputActions
  }, [inputActions])
  useEffect(() => {
    sidRef.current = sessionId
  }, [sessionId])
  useEffect(() => {
    const onConfigSaved = (): void => {
      stopWakeStandby()
      void startWakeStandby()
    }
    window.addEventListener('dshvm-config-saved', onConfigSaved)
    return () => window.removeEventListener('dshvm-config-saved', onConfigSaved)
  }, [])
  // I5：autoResume——切回上次语音会话时自动恢复（默认关；需麦克风权限已授予，失败静默降级）。
  // 按 sessionId 触发（而非仅 mount 一次）：组件跨会话持久时「切回上次会话」才有机会命中。
  const autoResumeTriedForRef = useRef<string | null>(null)
  /** 批 H 任务 4：autoResume 引导提示的清空计时器句柄（per-sid 切换会话时复位）。 */
  const autoResumeHintTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(() => {
    const sid = sessionId
    if (!sid || sid === autoResumeTriedForRef.current) return
    autoResumeTriedForRef.current = sid
    // M6/对抗审查 I4：全新页面加载时 ui.boot 还是默认值（fetchConfig 只在
    // enterMode 调用），直接读 bootNow().autoResume 恒 false → autoResume 永不触发。
    // 先拉真实引导配置再判定（fetchConfig 同时把 boot 写入 bus）。
    void (async () => {
      const cfg = await fetchConfig()
      if (cfg.alwaysListen) {
        void startWakeStandby(cfg)
        return
      }
      // 批 H 任务 4：autoResume 关 + 切回上次会话 → 状态条一次性提示（5s 后清）。
      // 与 idleTimeoutQuit toast 共用模式：仅当 notice 仍是本次提示文案才清，避免冲掉用户新提示。
      if (!cfg.autoResume) {
        if (getLastVoiceSession() === sid) {
          const hint = t('autoResumeHint')
          if (autoResumeHintTimerRef.current) clearTimeout(autoResumeHintTimerRef.current)
          bus.setUi({ notice: hint })
          autoResumeHintTimerRef.current = setTimeout(() => {
            autoResumeHintTimerRef.current = null
            if (bus.ui.notice === hint) bus.setUi({ notice: null })
          }, 5000)
        }
        return
      }
      if (getLastVoiceSession() !== sid) return
      if (bus.activeSessionId !== null) return // 已有别的会话在语音模式，不抢
      if (localRef.current !== 'off') return // 已在（或正在进入）语音模式，不重复
      await enterMode().catch(() => {
        // 无手势 getUserMedia 可能失败（Safari/iOS），静默降级为手动点麦克风。
        setLocalMode('off')
      })
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId])
  // 宿主 selector hook 必须组件顶层调用（不能在 effect 内——React #321）。
  const runningSel = useSession
    ? useSession((s: any) => (s === undefined ? undefined : s.running))
    : undefined
  useEffect(() => {
    runningRef.current = runningSel === true
  }, [runningSel])

  // 会话切换让出（组件卸载兜底）
  useEffect(() => {
    mountedRef.current = true
    return () => {
      mountedRef.current = false // 中止在途 enterMode（权限框期间卸载）
      stopWakeStandby()
      clearIdle()
      cancelPendingSubmit()
      cancelAutoSend()
      isSpeechTrueCount = 0 // 打断根治：卸载重置 isSpeech 计数（防残留）
      // 批 H 任务 4：autoResume 引导提示定时器兜底清理。
      if (autoResumeHintTimerRef.current) {
        clearTimeout(autoResumeHintTimerRef.current)
        autoResumeHintTimerRef.current = null
      }
      const sid = sidRef.current
      // 过渡态（pending）也需清理：enterMode 期间卸载时 host 可能已 arm 本会话，
      // 不发 toggle-off 会残留录音/占用（隐私级）。engine 可能尚未创建，用可选链。
      if ((localRef.current === 'on' || localRef.current === 'pending') && sid) {
        void engineRef.current?.stop()
        void fetch(new URL(`${BASE_PATH.slice(1)}/toggle`, document.baseURI), {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ sessionId: sid, on: false, tabId: TAB_ID }),
          keepalive: true,
        }).catch(() => {
          // best-effort
        })
      }
    }
  }, [])

  // 快捷键：Ctrl+Shift+V 切换模式；单独 Ctrl 按模式分支——toggle：强制发送；
  // hold：按住即录、松开即发（≥600ms 阈值 + 他键/失焦作废，防 Ctrl+Shift+V 误触）。
  useEffect(() => {
    let ctrlTimer: ReturnType<typeof setTimeout> | null = null
    /** I1：Ctrl 按住起点墙钟 + 按住期间是否按过其它键（防 Ctrl+组合误触发）。 */
    let ctrlHoldStart = 0
    let otherKeyDuringCtrl = false
    const cancelCtrl = (): void => {
      if (ctrlTimer) {
        clearTimeout(ctrlTimer)
        ctrlTimer = null
      }
      if (holdCtrlRef.current) {
        holdCtrlRef.current = false
        setHolding(false)
        engineRef.current?.endHeld(false)
      }
      if (manualHoldRef.current) {
        manualHoldRef.current = false
        setHolding(false)
        engineRef.current?.endHeld(false)
      }
    }
    const onKeyDown = (e: KeyboardEvent): void => {
      // 可配置快捷键（默认 Ctrl+Shift+V；解析失败/空 = 禁用快捷键）。
      const combo = parseShortcut(bootNow().shortcut)
      // M10：Shift 下 e.key 变符号（如 Shift+1 → '!'），用 e.code 归一化
      // （KeyV→v / Digit1→1）兜底，否则 Ctrl+Shift+数字类配置静默失效。
      const codeKey = e.code.replace('Key', '').replace('Digit', '').toLowerCase()
      if (
        combo &&
        !e.repeat &&
        (e.key.toLowerCase() === combo.key || codeKey === combo.key) &&
        e.ctrlKey === combo.ctrl &&
        e.shiftKey === combo.shift &&
        e.altKey === combo.alt &&
        e.metaKey === combo.meta
      ) {
        // I2：编辑态（输入框/contenteditable）或输入法合成中，快捷键可能是「粘贴纯文本」等，
        // 不劫持——交给浏览器；语音切换在非输入上下文照常（输入框里用麦克风按钮）。
        const el = e.target
        const editable =
          el instanceof HTMLElement && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT' || el.isContentEditable)
        if (!editable && !e.isComposing) {
          e.preventDefault()
          cancelCtrl()
          toggleRef.current()
        }
        return
      }
      const eng = engineRef.current
      if (e.key === 'Control' && !e.shiftKey && !e.altKey && !e.metaKey && !e.repeat && eng) {
        // 单独 Ctrl 按下：记录起点；hold 模式起 600ms 定时器，toggle 模式延迟到 keyup 判定。
        ctrlHoldStart = Date.now()
        otherKeyDuringCtrl = false
        if (bootNow().mode === 'hold') {
          // hold：600ms 阈值后视为按住说话（避免组合快捷键按下时序误触发）
          ctrlTimer = setTimeout(() => {
            ctrlTimer = null
            holdCtrlRef.current = true
            setHolding(true)
            eng.beginHeld()
          }, 600)
        } else if (bootNow().bargeInMode === 'manual' && bus.ui.playing) {
          // 手动打断（外放）：按住 Ctrl 立即停 AI + 接管收音（不依赖 VAD，回声无关）。
          manualHoldRef.current = true
          setHolding(true)
          eng.beginHeld()
          void breakRef.current?.()
        }
        return
      }
      // I1：Ctrl 按住期间按下任何其它键 → 标记并作废 hold 定时器（防 Ctrl+C/V/W 误触发）。
      if (ctrlHoldStart > 0 && e.key !== 'Control') {
        otherKeyDuringCtrl = true
        if (ctrlTimer) {
          clearTimeout(ctrlTimer)
          ctrlTimer = null
        }
      }
    }
    const onKeyUp = (e: KeyboardEvent): void => {
      if (e.key !== 'Control') return
      // I1：toggle 模式 forceSend 延迟到松开，要求「无其它键 + 按住 ≥250ms」
      // （原 keydown 立即 forceSend 会让 Ctrl+C/V/W 等组合误发半句）。
      if (
        bootNow().mode !== 'hold' &&
        !manualHoldRef.current &&
        !otherKeyDuringCtrl &&
        ctrlHoldStart > 0 &&
        Date.now() - ctrlHoldStart >= 250
      ) {
        engineRef.current?.forceSend()
      }
      cancelCtrl()
      ctrlHoldStart = 0
      otherKeyDuringCtrl = false
    }
    const onBlur = (): void => {
      // 失焦即取消：blur 收不到 keyup 时不能把"按住"留在收音态（AGENTS 契约）。
      cancelCtrl()
      ctrlHoldStart = 0
      otherKeyDuringCtrl = false
      if (localRef.current === 'on' && bootNow().mode === 'hold') engineRef.current?.endHeld(true)
    }
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('keyup', onKeyUp)
    window.addEventListener('blur', onBlur)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
      window.removeEventListener('blur', onBlur)
      cancelCtrl()
    }
  }, [])

  // 打字退出（Q13）：受控 textarea 的程序化 setDraft 不派发原生 input 事件。
  useEffect(() => {
    const onInput = (e: Event): void => {
      const t = e.target as HTMLElement | null
      if (!(t instanceof HTMLTextAreaElement)) return
      if (localRef.current !== 'on') return
      void exitModeRef.current('typing')
    }
    window.addEventListener('input', onInput, true)
    return () => window.removeEventListener('input', onInput, true)
  }, [])

  // hold 模式收尾兜底：Escape 放弃当前段；切走标签页/隐藏文档时取消（防持续收音）。
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent): void => {
      if (e.key !== 'Escape') return
      if (localRef.current !== 'on' || bootNow().mode !== 'hold') return
      engineRef.current?.endHeld(true)
      holdCtrlRef.current = false
      setHolding(false)
      bus.setUi({ partial: '' })
    }
    const onVisibility = (): void => {
      if (document.hidden) {
        stopWakeStandby()
        if (localRef.current === 'on' && engineRef.current) {
          // M2：隐藏 tab 暂停收音（隐私），可见时恢复。toggle 与 hold 都关麦——hold 之前只
          // endHeld 不 stop，麦克风后台常开（隐私缺口）。
          if (bootNow().mode === 'hold') {
            engineRef.current?.endHeld(true)
            holdCtrlRef.current = false
            setHolding(false)
          }
          pausedForHiddenRef.current = true
          void engineRef.current.stop()
        }
      } else if (pausedForHiddenRef.current && localRef.current === 'on') {
        pausedForHiddenRef.current = false
        void engineRef.current?.start().catch(() => {
          // 无手势恢复失败（Safari/iOS）→ 静默降级为退出，用户重新点麦克风。
          setLocalMode('off')
        })
      } else if (localRef.current === 'off') {
        void startWakeStandby()
      }
    }
    window.addEventListener('keydown', onKeyDown)
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [bus])

  // 模式状态即 bus.active 归属（pending 期间等待 host 确认）
  useEffect(() => {
    return bus.subscribe(() => {
      const sid = sidRef.current
      if (localRef.current === 'pending' || localRef.current === 'on') {
        if (bus.activeSessionId === sid) {
          setLocalMode('on')
        } else if (localRef.current === 'pending') {
          setLocalMode('off')
        }
      }
    })
  }, [bus])

  const on = local === 'on'
  const wakeStandby = !on && local === 'off' && bus.ui.wakeStatus === 'on' && sessionId === bus.ui.visibleSessionId
  const wakeLoading = !on && local === 'off' && bus.ui.wakeStatus === 'loading' && sessionId === bus.ui.visibleSessionId
  const busy = bus.ui.state === 'transcribing' || bus.ui.state === 'loading-model'
  const holdMode = bootNow().mode === 'hold'
  // 当前草稿：官方 InputActions 无 getDraft（仅 setDraft/submit），草稿与机器
  // phase 的事实源为 useInput 标准 prop；值变化即重渲染，draftRef/phaseRef 在
  // 事件回调里读最新值（phase 用于提交重试门控：避免把「提交在途」当失败重发）。
  const liveDraft = useInput ? useInput((s: any) => (s?.draft as string) ?? '') : ''
  const draftRef = useRef('')
  draftRef.current = liveDraft
  const livePhase = useInput ? useInput((s: any) => (s?.phase as string) ?? '') : ''
  const phaseRef = useRef('')
  phaseRef.current = livePhase
  /** 按住说话中（录音态视觉反馈）。 */
  const [holding, setHolding] = useState(false)
  const label = on
    ? busy
      ? t('recognizing')
      : holdMode
        ? holding
          ? t('releaseToSend')
          : t('holdToTalk')
        : bus.ui.state === 'wake'
          ? t('sayWake').replace('{wake}', bus.ui.wakeWord || t('wakeWord'))
          : t('voiceDetected')
    : local === 'pending'
      ? t('entering')
      : t('voiceBtn')

  // hold 手势（仅 hold 模式激活后有效）：按下即录；<250ms 视为短按退出；
  // 按住中途向上滑出 ≥40px 放弃本段；松手定稿发送。click 一律不切换
  // （Blocker-1：pointerup 合成的 click 会自毁退出）。
  const holdPtrRef = useRef<{ t: number; y: number; id: number } | null>(null)
  /** toggle 模式播放中按住（长按打断 + 接管）。 */
  const toggleHoldRef = useRef(false)
  /** 长按打断松手后抑制合成 click 的时间戳（防误触发 tap-to-exit）。 */
  const suppressClickUntilRef = useRef(0)
  /** 长按打断定时器：按住 ≥250ms 才真正打断（对抗审查 Blocker——打断不能挂在
   *  pointerdown 上，否则短按退出也会取消正在生成的回复）。 */
  const breakTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const clearBreakTimer = (): void => {
    if (breakTimerRef.current !== null) {
      clearTimeout(breakTimerRef.current)
      breakTimerRef.current = null
    }
  }
  /** 按住期间的整页禁选守卫（null = 未加锁）。 */
  const selectGuardRef = useRef<(() => void) | null>(null)
  const unlockSelection = (): void => {
    const off = selectGuardRef.current
    if (!off) return
    selectGuardRef.current = null
    off()
    // 清掉长按已经产生的高亮（禁选样式无效的内核上仍会先选中一次）
    try {
      window.getSelection()?.removeAllRanges()
    } catch {
      /* 忽略：个别内核在无选区时抛错 */
    }
  }
  /** 按下即锁：CSS 禁选 + selectstart 拦截，覆盖桌面拖选与移动端长按取词。 */
  const lockSelection = (): void => {
    if (selectGuardRef.current) return
    const root = document.documentElement
    root.classList.add('dshvm-holding')
    try {
      window.getSelection()?.removeAllRanges()
    } catch {
      /* 忽略 */
    }
    const stopSelect = (ev: Event): void => ev.preventDefault()
    const release = (): void => unlockSelection()
    document.addEventListener('selectstart', stopSelect, true)
    // 长按菜单可能派发在按钮以外的节点上，按钮自身的 onContextMenu 拦不住。
    document.addEventListener('contextmenu', stopSelect, true)
    // 兜底：指针在按钮外抬起/被系统取消时，按钮自身的 pointerup 不会到达。
    window.addEventListener('pointerup', release, true)
    window.addEventListener('pointercancel', release, true)
    selectGuardRef.current = () => {
      root.classList.remove('dshvm-holding')
      document.removeEventListener('selectstart', stopSelect, true)
      document.removeEventListener('contextmenu', stopSelect, true)
      window.removeEventListener('pointerup', release, true)
      window.removeEventListener('pointercancel', release, true)
    }
  }
  useEffect(() => unlockSelection, [])

  /** 按钮 DOM：给 touchstart 挂**非被动**原生监听（React 的 onTouchStart 是 passive，
   *  里面 preventDefault 无效）。preventDefault 掉 touchstart 是唯一能压住安卓/iOS
   *  内核长按菜单（复制/全选/翻译）的手段——禁选 CSS 在这些内核上会被无视。
   *  仅 hold 模式生效：hold 全程由 pointer 事件驱动，不依赖合成 click；
   *  toggle 模式靠 click 进出，不能拦（否则点不动）。 */
  const btnRef = useRef<HTMLButtonElement | null>(null)
  useEffect(() => {
    const el = btnRef.current
    if (!el) return
    const onTouchStart = (ev: TouchEvent): void => {
      if (bootNow().mode !== 'hold') return
      if (ev.cancelable) ev.preventDefault()
    }
    el.addEventListener('touchstart', onTouchStart, { passive: false })
    return () => el.removeEventListener('touchstart', onTouchStart)
  }, [])

  const onPointerDown = (e: React.PointerEvent): void => {
    lockSelection()
    holdPtrRef.current = { t: Date.now(), y: e.clientY, id: e.pointerId }
    ;(e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId)
    if (bootNow().mode === 'hold') {
      // hold 模式全程 pointer 驱动：on=按住说话，off=短按进入；click 事件不参与
      if (localRef.current === 'on') {
        setHolding(true)
        const eng = engineRef.current
        eng?.beginHeld() // 立即接管收音（按住的前 250ms 语音不丢）
        if (eng && bootNow().bargeInMode === 'manual' && bus.ui.playing) {
          // 手动打断（外放）：按住 ≥250ms 才停 AI（短按 = tap-to-exit，不得取消回复）。
          breakTimerRef.current = setTimeout(() => {
            breakTimerRef.current = null
            if (holdPtrRef.current && bus.ui.playing) void breakRef.current?.()
          }, 250)
        }
      }
    } else if (localRef.current === 'on' && bus.ui.playing) {
      // toggle 模式（持续聆听）：播放中按住 = 长按打断 + 接管收音（与 hold 手势统一）；
      // 打断同样延迟到 ≥250ms，短按退出不取消回复。
      toggleHoldRef.current = true
      setHolding(true)
      const eng = engineRef.current
      eng?.beginHeld()
      breakTimerRef.current = setTimeout(() => {
        breakTimerRef.current = null
        if (holdPtrRef.current && bus.ui.playing) void breakRef.current?.()
      }, 250)
    }
  }
  const onPointerMove = (e: React.PointerEvent): void => {
    const p = holdPtrRef.current
    if (!p || p.id !== e.pointerId) return
    // 向上滑出 ≥40px → 放弃本段（保留在语音模式）
    if (p.y - e.clientY >= 40) {
      holdPtrRef.current = null
      toggleHoldRef.current = false
      clearBreakTimer()
      setHolding(false)
      engineRef.current?.endHeld(true)
      bus.setUi({ partial: '' })
      // 对抗审查 Important#1：滑出后的 trailing click 会走 toggle→exit 误退出；
      // 抑制该合成 click（与长按松手同机制）。
      suppressClickUntilRef.current = Date.now() + 500
    }
  }
  const onPointerUp = (e: React.PointerEvent): void => {
    const p = holdPtrRef.current
    holdPtrRef.current = null
    clearBreakTimer() // 松手即取消未到阈值的打断（短按不得取消回复）
    setHolding(false)
    if (!p || p.id !== e.pointerId) return
    const ms = Date.now() - p.t
    if (bootNow().mode !== 'hold') {
      // toggle 模式：播放中长按打断 → 松开发送 + 抑制合成 click；短按交给 click（退出）。
      if (toggleHoldRef.current) {
        toggleHoldRef.current = false
        if (ms >= 250) {
          suppressClickUntilRef.current = Date.now() + 500
          engineRef.current?.endHeld(false)
        } else {
          engineRef.current?.endHeld(true) // 短按取消录音，click 会退出
        }
      }
      return
    }
    if (ms < 250) {
      // 短按：on → 退出语音模式（tap-to-exit）；off → 进入（hold 模式全程 pointer 驱动）
      // 同受 2 秒点击防抖保护（快速连点只响应第一次）。
      const now = Date.now()
      if (now - toggleGuardRef.current < 2000) return
      toggleGuardRef.current = now
      if (localRef.current === 'on') {
        engineRef.current?.endHeld(true)
        void exitModeRef.current('manual')
      } else {
        void enterMode()
      }
      return
    }
    if (localRef.current === 'on') engineRef.current?.endHeld(false)
  }
  const onPointerCancel = (): void => {
    holdPtrRef.current = null
    toggleHoldRef.current = false
    clearBreakTimer()
    setHolding(false)
    engineRef.current?.endHeld(true)
  }

  return (
    <button
      onClick={(e: React.MouseEvent) => {
        // toggle 模式长按打断松手后，抑制合成的 click（防误触发 tap-to-exit）。
        if (Date.now() < suppressClickUntilRef.current) return
        if (holdMode) {
          // pointer/触摸合成的 click 一律忽略（tap 进入/退出走 pointer 路径，
          // 否则 tap-exit 的 trailing click 会再次触发 toggle 重进 —— Blocker-1 反面）
          if (e.detail !== 0) return
          // 键盘/Space/Enter 激活（detail === 0）保持 a11y 可用
        }
        toggle()
      }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerCancel}
      onContextMenu={(e) => e.preventDefault()} // 防长按/右键弹出「复制」菜单
      ref={btnRef}
      data-dshvm="mic"
      data-dshvm-wake={wakeStandby ? 'on' : wakeLoading ? 'loading' : 'off'}
      data-dshvm-draft={liveDraft.trim() ? 'text' : 'empty'}
      aria-label={on ? t('ariaActive') : wakeStandby ? '常开唤醒待机中，点击直接语音输入' : t('ariaEnter')}
      aria-description={wakeStandby ? '说出已配置的任一唤醒词，或点击直接语音输入' : label}
      aria-pressed={on}
      title={
        on
          ? holdMode
            ? t('titleHold')
            : t('titleToggle')
          : wakeStandby ? '常开唤醒待机中；点击直接语音输入' : wakeLoading ? '正在启动常开唤醒' : t('titleEnter')
      }
      style={{
        border: holding
          ? '1px solid rgba(248, 81, 73, 0.6)'
          : on
            ? holdMode
              ? '1px solid rgba(88, 166, 255, 0.45)'
              : '1px solid rgba(63, 185, 80, 0.45)'
            : wakeStandby
              ? '1px solid rgba(63, 185, 80, 0.7)'
              : wakeLoading
                ? '1px solid rgba(88, 166, 255, 0.45)'
            : '1px solid transparent',
        background: holding
          ? 'rgba(248, 81, 73, 0.2)'
          : on
            ? holdMode
              ? 'rgba(88, 166, 255, 0.16)'
              : 'rgba(63, 185, 80, 0.16)'
            : wakeStandby
              ? 'rgba(63, 185, 80, 0.16)'
              : local === 'pending' || wakeLoading
              ? 'rgba(88, 166, 255, 0.14)'
              : 'color-mix(in srgb, currentColor 7%, transparent)',
        cursor: 'pointer',
        width: 36,
        height: 36,
        padding: 0,
        borderRadius: 999,
        display: !on && local !== 'pending' && liveDraft.trim() ? 'none' : 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flex: 'none',
        color: holding ? 'var(--dsw-alias-state-error-primary)' : on || wakeStandby ? 'var(--dsw-alias-brand-primary)' : 'var(--dsw-alias-label-primary)',
        // 批 H 任务 3：toggle 模式「语音中」绿字加深（#3fb950 → #2ea043）+ fontWeight:600 双保险，
        // 浅色主题下与浅绿底 (rgba 63,185,80,.16) 对比度 ≥ 4.5:1（WCAG AA 文本级）。
        fontWeight: on && !holdMode ? 600 : undefined,
        transition: 'background 0.15s ease, color 0.2s ease, border-color 0.15s ease',
        touchAction: 'none', // 触摸设备上让 pointer 事件独占（滑出取消可用）
        userSelect: 'none',
        WebkitUserSelect: 'none', // iOS Safari 前缀，防长按选中文字
        WebkitTouchCallout: 'none', // iOS 长按弹出「拷贝/选择」菜单
      }}
    >
      <svg viewBox="0 0 24 24" width={20} height={20} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="9" y="2" width="6" height="12" rx="3" fill={wakeStandby ? 'currentColor' : 'none'} stroke={wakeStandby ? 'none' : 'currentColor'} />
        <path d="M5 10v1a7 7 0 0 0 14 0v-1M12 18v4M8 22h8" />
        {wakeStandby && <>
          <path data-dshvm-wake-glyph="on" d="M3 7.5c-1.3 2.5-1.3 6.5 0 9" />
          <path data-dshvm-wake-glyph="on" d="M21 7.5c1.3 2.5 1.3 6.5 0 9" />
        </>}
      </svg>
    </button>
  )
}

/** 输入框上方的常驻状态条（仅模式激活时显示）。 */
interface StatusBarProps extends VoiceSlotActions {
  sessionId?: string
}

/** 会话顶部的后续回复自动播报开关；与麦克风状态独立。 */
export function SpeakerButton({ bus, sessionId }: StatusBarProps): React.ReactElement {
  const [snapshot, setSnapshot] = useState(() => ({ active: bus.activeSessionId, ui: bus.ui }))
  useEffect(() => bus.subscribe(setSnapshot), [bus])
  if (!sessionId) return <></>
  const enabled = snapshot.ui.readSessionId === sessionId
  return (
    <button type="button" data-dshvm="speaker" aria-label={enabled ? '关闭后续回复自动播报' : '开启后续回复自动播报'}
      aria-pressed={enabled} title={enabled ? '后续回复将自动播报' : '自动播报已关闭；仍可逐条朗读'}
      onClick={() => { bus.warmAudio(); void bus.setRead(sessionId, !enabled) }}
      style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32,
        border: 0, borderRadius: 999, cursor: 'pointer', color: enabled ? 'var(--dsw-alias-brand-primary)' : 'var(--dsw-alias-label-primary)',
        background: enabled ? 'color-mix(in srgb, currentColor 8%, transparent)' : 'transparent' }}>
      <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M11.5 5.5 7 9H4.5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1H7l4.5 3.5v-13Z" />
        {enabled
          ? <><path d="M15.5 9a4.5 4.5 0 0 1 0 6" /><path d="M18 6.5a8 8 0 0 1 0 11" /></>
          : <><path d="m16.5 9.5 5 5" /><path d="m21.5 9.5-5 5" /></>}
      </svg>
    </button>
  )
}

/** 每条已完成回复的单次朗读按钮，放在复制按钮旁边。 */
export function ReplySpeakerButton({ bus, sessionId, messageId }: StatusBarProps & { messageId?: string }): React.ReactElement {
  const [reading, setReading] = useState(() => ({ sessionId: bus.ui.manualReadSessionId, messageId: bus.ui.manualReadMessageId }))
  const [pending, setPending] = useState(false)
  useEffect(() => bus.subscribe(({ ui }) => {
    setReading((prev) => prev.sessionId === ui.manualReadSessionId && prev.messageId === ui.manualReadMessageId
      ? prev : { sessionId: ui.manualReadSessionId, messageId: ui.manualReadMessageId })
  }), [bus])
  if (!sessionId || !messageId) return <></>
  const active = reading.sessionId === sessionId && reading.messageId === messageId
  return (
    <button type="button" data-dshvm="reply-speaker" data-dshvm-message-id={messageId}
      aria-label={active ? '停止朗读这条回复' : '朗读这条回复'} aria-pressed={active}
      title={active ? '停止朗读这条回复' : '朗读这条回复'} disabled={pending}
      onClick={() => {
        bus.warmAudio()
        setPending(true)
        void bus.readOnce(sessionId, messageId, !active).finally(() => setPending(false))
      }}
      style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28,
        padding: 0, border: 0, borderRadius: 6, background: 'transparent', cursor: 'pointer',
        color: active ? 'var(--dsw-alias-brand-primary)' : 'var(--dsw-alias-label-secondary)' }}>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        {active
          ? <rect x="7" y="7" width="10" height="10" rx="1.5" />
          : <><path d="M11.5 5.5 7 9H4.5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1H7l4.5 3.5v-13Z" /><path d="M15.5 9a4.5 4.5 0 0 1 0 6" /><path d="M18 6.5a8 8 0 0 1 0 11" /></>}
      </svg>
    </button>
  )
}

/** 使用 DSH 自身待交互事件，重复 key 由 Host 去重。 */
export function ApprovalWatcher({ bus, sessionId, useSessionStatus }: StatusBarProps & {
  useSessionStatus: <T>(selector: (snapshot: ReadonlyMap<string, { pendingInteraction?: { key: string; kind: string; toolName?: string } }>) => T) => T
}): React.ReactElement {
  const item = useSessionStatus(snapshot => sessionId ? snapshot.get(sessionId)?.pendingInteraction : undefined)
  useEffect(() => {
    if (!sessionId) return
    bus.setVisibleSession(sessionId)
    return () => { if (bus.ui.visibleSessionId === sessionId) bus.setVisibleSession(null) }
  }, [bus, sessionId])
  useEffect(() => {
    if (!sessionId || !item) return
      void fetch(new URL(`${BASE_PATH.slice(1)}/announce`, document.baseURI), {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ sessionId, tabId: TAB_ID, key: item.key, kind: item.kind, toolName: item.toolName }),
      }).then((res) => {
        if (!res.ok && res.status !== 400) bus.setUi({ error: `审批语音提示失败：HTTP（请求状态）${res.status}，请检查插件服务。` })
      }).catch((error) => { debugLog('approval-announce-error', { detail: String(error) }); bus.setUi({ error: '审批语音提示失败，请检查插件服务。' }) })
  }, [bus, sessionId, item?.key, item?.kind, item?.toolName])
  return <></>
}

export function VoiceStatusBar({ bus, sessionId }: StatusBarProps): React.ReactElement {
  const [b, setB] = useState(() => ({ active: bus.activeSessionId, ui: bus.ui }))
  // P1-UX 状态条计时器：会话活跃期间按秒递增；会话切走 / 卸载时清零
  const [elapsedSec, setElapsedSec] = useState(0)

  useEffect(() => {
    return bus.subscribe(setB)
  }, [bus])

  useEffect(() => {
    if (b.active !== sessionId) {
      setElapsedSec(0)
      return
    }
    const id = setInterval(() => setElapsedSec((s) => s + 1), 1000)
    return () => clearInterval(id)
  }, [b.active, sessionId])

  const isActive = b.active === sessionId
  if (!isActive) {
    if (sessionId !== b.ui.visibleSessionId || (b.ui.readSessionId !== sessionId && !b.ui.error && !b.ui.ttsNotice && !b.ui.playing && b.ui.wakeStatus === 'off')) return <></>
    return <div role="status" aria-live="polite" style={{ boxSizing: 'border-box', width: '100%', maxWidth: 'var(--dsh-composer-card-max-width)', marginInline: 'auto', padding: '6px 10px', fontSize: 12, color: b.ui.error ? 'var(--dsw-alias-state-error-primary)' : 'var(--dsw-alias-label-secondary)' }}>
      {b.ui.error ?? b.ui.ttsNotice ?? (b.ui.playing ? '正在播报…' : b.ui.wakeStatus === 'loading' ? '正在加载本地唤醒模型…' : b.ui.wakeStatus === 'on' ? `常开唤醒中 · 说「${splitWakeWords(b.ui.wakeWord).join('」或「')}」开始；点击麦克风可直接输入` : '后续回复自动播报已开启')}
    </div>
  }

  const stateText =
    b.ui.state === 'loading-model'
      ? t('loadingModel')
      : b.ui.state === 'transcribing'
        ? t('recognizing')
        : b.ui.state === 'wake'
          ? t('sayWake').replace('{wake}', b.ui.wakeWord || t('wakeWord'))
          : b.ui.state === 'speech'
            ? b.ui.mode === 'hold'
              ? t('holdDots')
              : t('listening')
            : b.ui.playing // Fix：TTS 播放時顯示「朗讀中…」，防用戶誤以為系統無響應
              ? t('reading')
              : b.ui.turn === 'agent-speaking'
                ? t('thinking')
                : b.ui.mode === 'hold'
                  ? t('barHold')
                  : t('barListening')

  const bars = Array.from({ length: WAVE_BARS }, (_, i) => b.ui.levels[i] ?? 0)
  // P0-UX 双条 SVG 波形：第二组柱形表示 AI 朗读端电平
  const botBars = Array.from({ length: WAVE_BARS }, (_, i) => b.ui.botLevels[i] ?? 0)

  // P1-5 延迟埋点链展示（开发模式）：各相邻阶段耗时 + 说完→首音合计。
  const telParts: string[] = []
  const fmt = (ms: number): string => (ms >= 1000 ? `${(ms / 1000).toFixed(2)}s` : `${Math.round(ms)}ms`)
  const tel = b.ui.telemetry
  if (tel) {
    for (let i = 1; i < TELEMETRY_VIEW.length; i++) {
      const cur = tel[TELEMETRY_VIEW[i].stage]
      const prev = tel[TELEMETRY_VIEW[i - 1].stage]
      if (cur === undefined || prev === undefined) continue
      telParts.push(`${t(TELEMETRY_VIEW[i].key)} ${fmt(cur - prev)}`)
    }
    const begin = tel['utterance-end']
    const end = tel['first-audio-played']
    if (begin !== undefined && end !== undefined) telParts.push(`${t('telTotal')} ${fmt(end - begin)}`)
  }
  // 打断确认耗时（打断后独立展示；埋点链已被打断清空，此处单列）。
  if (b.ui.interruptConfirmMs !== undefined) {
    telParts.push(`${t('interruptConfirm')} ${fmt(b.ui.interruptConfirmMs)}`)
  }
  // 回声诊断（开发模式标定数据）：bulk delay / 回声地板 RMS / 当前残差 RMS。
  // 仅 telemetry 开启时显示——默认关，避免把 AEC 标定数据暴露给普通用户。
  if (telemetryEnabled && b.ui.echoLevels) {
    const el = b.ui.echoLevels
    telParts.push(
      `AEC delay=${Math.round(b.ui.echoDelayMs ?? 0)}ms floor=${el.floorRms.toFixed(4)} resid=${el.residualRms.toFixed(4)}`,
    )
  }

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box',
        width: '100%',
        maxWidth: 'var(--dsh-composer-card-max-width)',
        marginInline: 'auto',
        gap: 2,
        padding: '6px 12px',
        borderRadius: 10,
        fontSize: 12,
        fontFamily: 'system-ui, sans-serif',
        color: '#3fb950',
        background: 'rgba(63, 185, 80, 0.08)',
        border: '1px solid rgba(63, 185, 80, 0.25)',
        animation: 'dshvm-fadein 0.2s ease',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {/* P0-UX 双条 SVG 波形：先 AI 朗读端(蓝)，后麦克风采集端(绿)；视觉左→右读"AI→我" */}
        {botBars.some((v) => v > 0) && (
          <span
            title={t('botLevelsHint')}
            style={{
              display: 'inline-flex',
              alignItems: 'flex-end',
              gap: 2,
              height: 14,
              flexShrink: 0,
            }}
          >
            {botBars.map((v, i) => (
              <span
                key={i}
                className="dshvm-bar-bot"
                style={{
                  height: `${3 + v * 12}px`,
                  background: '#58a6ff',
                  opacity: 0.4 + v * 0.6,
                }}
              />
            ))}
          </span>
        )}
        <span style={{ display: 'inline-flex', alignItems: 'flex-end', gap: 2, height: 14, flexShrink: 0 }}>
          {bars.map((v, i) => (
            <span
              key={i}
              className="dshvm-bar"
              style={{
                height: `${3 + v * 12}px`,
                background: '#3fb950',
                opacity: 0.4 + v * 0.6,
              }}
            />
          ))}
        </span>
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flexGrow: 1 }}>
          {b.ui.error
            ? b.ui.error
            : b.ui.notice
              ? b.ui.notice
              : b.ui.idleWarn
                ? t('idleWarn30s')
                : b.ui.state === 'loading-model' || b.ui.model
                ? b.ui.model
                  ? `${t('loadingModel')} ${b.ui.model.file} ${b.ui.model.percent}%`
                  : stateText
                : b.ui.playing || b.ui.turn === 'agent-speaking'
                  ? stateText // 朗读/思考中优先显示状态，不显示用户旧的 partial（防遮蔽 thinking/reading）
                  : b.ui.state === 'wake' && b.ui.partial
                  ? `${stateText} · ${b.ui.partial}` // wake 待机：提示 + 实时转写并存（issue #10 问题 2，唤醒成败可自查）
                  : b.ui.partial
                    ? b.ui.partial
                    : b.ui.ttsNotice
                      ? b.ui.ttsNotice
                      : stateText}
        </span>
        {b.ui.isSpeech === true && (
          <span
            title={t('vadDetected')}
            style={{
              flexShrink: 0,
              padding: '0 6px',
              borderRadius: 8,
              fontSize: 10,
              lineHeight: '16px',
              color: '#ffa657',
              background: 'rgba(255, 166, 87, 0.15)',
              border: '1px solid rgba(255, 166, 87, 0.35)',
            }}
          >
            {t('vadDetected')}
          </span>
        )}
        {/* P1-UX 状态条计时器：会话时长（mm:ss），活跃期间按秒递增 */}
        {elapsedSec > 0 && (
          <span
            title={t('elapsedHint')}
            style={{
              flexShrink: 0,
              padding: '0 6px',
              borderRadius: 8,
              fontSize: 10,
              lineHeight: '16px',
              color: '#8b949e',
              fontVariantNumeric: 'tabular-nums',
              fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
            }}
          >
            {String(Math.floor(elapsedSec / 60)).padStart(2, '0')}:{String(elapsedSec % 60).padStart(2, '0')}
          </span>
        )}
        {b.ui.aecOff === true && (
          <span
            title={b.ui.bargeInDetectFallback ? t('bargeInDetectFallback') : t('aecOffHint')}
            style={{
              flexShrink: 0,
              padding: '0 6px',
              borderRadius: 8,
              fontSize: 10,
              lineHeight: '16px',
              color: '#ffa657',
              background: 'rgba(255, 166, 87, 0.15)',
              border: '1px solid rgba(255, 166, 87, 0.35)',
            }}
          >
            {b.ui.bargeInDetectFallback ? t('bargeInDetectFallback') : t('aecOff')}
          </span>
        )}
        <button
          onClick={() => {
            void bus.exit(sessionId!)
          }}
          style={{
            border: 'none',
            background: 'transparent',
            color: '#8b949e',
            cursor: 'pointer',
            fontSize: 12,
            flexShrink: 0,
          }}
        >
          {t('exit')}
        </button>
      </div>
      {telParts.length > 0 && (
        <div
          style={{
            fontSize: 11,
            color: '#8b949e',
            fontVariantNumeric: 'tabular-nums',
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
            whiteSpace: 'nowrap',
            overflowX: 'auto',
          }}
        >
          {telParts.join(' · ')}
        </div>
      )}
    </div>
  )
}

/** 右下角朗读浮层（Q6 朗读字幕 + playing 状态 + 跳过）。 */
interface OverlayProps extends VoiceSlotActions {
  sessionId?: string
}

export function VoiceOverlay({ bus }: OverlayProps): React.ReactElement {
  const [b, setB] = useState(() => ({ active: bus.activeSessionId, ui: bus.ui }))

  useEffect(() => {
    return bus.subscribe(setB)
  }, [bus])

  // 播放引擎只推当前语音会话的帧（模式隔离）；有朗读才显示浮层。
  if (!b.ui.playing) return <></>

  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        position: 'fixed',
        right: 16,
        bottom: 96, // 上移，避免盖住底部输入框/麦克风按钮
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '8px 14px',
        borderRadius: 999,
        // 批 3：4 档字号（0/1/2/3 → 12/14/18/24 px）。默认 0=12px 与现状字节等价。
        fontSize: [12, 14, 18, 24][b.ui.boot?.captionFontSize ?? 0],
        fontFamily: 'system-ui, sans-serif',
        // 批 G 任务 5：浮层默认 'auto'——触屏需要命中内部「跳过」按钮；外层无 cursor:
        // default 由按钮自身 cursor:pointer 表达，文本区不显 pointer。
        // touchAction: 'manipulation' 阻止双击放大与连续点击 300ms 延迟（保留手势语义）。
        pointerEvents: 'auto',
        touchAction: 'manipulation',
        cursor: 'default',
        // 批 H 任务 2：背景与文字走 dsw-alias 主题变量（与 settings-form.tsx:32 / :35 一致），
        // 浅色主题下不再硬编码深色，a11y 与可读性同步提升。
        background: 'var(--dsw-alias-bg-layer-3)',
        backdropFilter: 'blur(14px)',
        WebkitBackdropFilter: 'blur(14px)',
        border: '1px solid rgba(255, 255, 255, 0.08)',
        boxShadow: '0 8px 28px rgba(0, 0, 0, 0.4)',
        color: 'var(--dsw-alias-label-primary)',
        // 批 3：3 档宽度（0/1/2 → 50vw/70vw/90vw）。默认 1=70vw。
        maxWidth: ['50vw', '70vw', '90vw'][b.ui.boot?.captionMaxWidth ?? 1],
        // 批 3：浮层最大高度（24px 多行时不盖输入框）。maxHeight 30vh + overflow hidden。
        maxHeight: '30vh',
        overflow: 'hidden',
        animation: 'dshvm-fadein 0.25s ease',
      }}
    >
      <span style={{ display: 'inline-flex', alignItems: 'flex-end', gap: 2, height: 12, flexShrink: 0 }}>
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            style={{
              width: 3,
              height: '100%',
              borderRadius: 99,
              background: '#2ea043',
              transformOrigin: 'bottom',
              animation: `dshvm-eq 0.85s ease-in-out ${i * 0.18}s infinite`,
            }}
          />
        ))}
      </span>
      <span
        key={b.ui.playingCaption ?? 'idle'}
        className="dshvm-caption"
        style={{
          // 批 3：换行（中文长 URL 等场景）。注：whiteSpace:normal + overflowWrap:anywhere 与 ellipsis 互斥（nowrap 才需要 ellipsis），
          //   接受换行后 ellipsis 失效——计划 §5.2 已显式声明。
          whiteSpace: 'normal',
          overflowWrap: 'anywhere',
          wordBreak: 'break-word',
          flex: 1,
          minWidth: 0,
        }}
      >
        {b.ui.playingCaption ?? t('reading')}
      </span>
      <button
        onClick={() => bus.skipAudio()}
        aria-label={t('skipReading')}
        style={{
          border: 'none',
          background: 'rgba(255, 255, 255, 0.14)',
          color: '#fff',
          borderRadius: 999,
          padding: '3px 12px',
          fontSize: 11,
          cursor: 'pointer',
          flexShrink: 0,
          pointerEvents: 'auto', // 仅此按钮可点
        }}
      >
        {t('skip')}
      </button>
    </div>
  )
}
